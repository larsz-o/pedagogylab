# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [8.4.3] - 2026-11-16
### Added
- Join the admin shell, so switching to and from other Jetpack dashboards skips the page load when the admin shell flag is on. [#54829]

### Changed
- Admin shell: Declare the page title and subtitle shown while the dashboard opens, when the admin shell flag is on. [#54945]
- Remove the strip dependency in favor of an inline helper. [#54936]
- Update package dependencies. [#54703]

## [8.4.2] - 2026-11-09
### Changed
- Update dependencies. [#54609]

## [8.4.1] - 2026-11-04
### Changed
- Update package dependencies. [#54391] [#54512]

## [8.4.0] - 2026-11-02
### Changed
- Update package dependencies. [#53869]

### Removed
- Search Dashboard: Remove the AI Agent Access toggle. [#53734]

## [8.3.5] - 2026-10-28
### Changed
- Update package dependencies. [#54118]

## [8.3.4] - 2026-10-26
### Changed
- Update package dependencies. [#53951]

### Fixed
- Dashboard: Activate free Search in place from "Start for free" instead of falling back to the $0 checkout. [#53397]
- Instant Search: Open the filters panel below the results header on small screens, so the Filters toggle stays visible. [#53474]

## [8.3.3] - 2026-10-19
### Changed
- Update dependencies. [#53618]
- Update package dependencies. [#53004] [#53806]

## [8.3.2] - 2026-10-12
### Changed
- Update dependencies. [#53250]

### Fixed
- Avoid requesting the Search plan in offline mode. [#53241]

## [8.3.1] - 2026-10-12
### Changed
- Update dependencies.

## [8.3.0] - 2026-10-05
### Changed
- Activate the free Search plan from the dashboard instead of sending you through a $0 checkout. [#52655]
- Update package dependencies. [#52999]

### Fixed
- AI Answer: Show the disabled notice when the host turns off AI, and hide the block from the inserter whenever Jetpack AI is off. [#51971]
- Dashboard: Start the experience switch and Restore default confirmations on Cancel, so pressing Enter no longer switches the search experience or deletes a customized template. [#53033]

## [8.2.1] - 2026-09-29
### Fixed
- Dashboard: Show the connection error at the top of the page on every tab. [#52820]

## [8.2.0] - 2026-09-28
### Changed
- Show the dashboard in the new rounded admin page frame. [#52506]
- Use the shared wp-build-polyfills helper to order the screen-ID alias around wp-build's generated enqueue check. [#52583]

### Fixed
- AI Answers: Keep the preview hidden when answers are turned off. [#52753]
- AI Answers: Turn off answers when the `jetpack_ai_enabled` filter returns false. [#52748]
- Blocks: Stop offering Search blocks in the Overlay search sidebar's widget inserter, and flag any already there. [#52670]
- Footer: Hide Products and Help links when My Jetpack is unavailable. [#52557]
- Show Jetpack in-dashboard messages on every Search tab, not just Overview. [#52641]
- Site Chat: Require a paid Search plan to enable and display chat. [#52386]

## [8.1.3] - 2026-09-21
### Changed
- No Results block: Show each empty-state message as it will appear to visitors while editing, and tell the messages apart by name when browsing the page structure. [#51530]
- Update package dependencies. [#52187]

## [8.1.2] - 2026-09-15
### Changed
- Hide the Search sidebar item when the Search module is not active. [#52156]
- Update package dependencies. [#52297]

### Fixed
- Instant Search: Fix a leaked scroll handler that could trigger stray page loads after several searches. [#51913]
- Prevent a malformed WordPress.com request on unregistered sites that could record a spurious connection error. [#52264]

## [8.1.1] - 2026-09-09
### Changed
- Sidebar: Sort Jetpack menu items alphabetically, pinning My Jetpack to the top and external links and Settings to the bottom. [#52003]

## [8.1.0] - 2026-09-08
### Changed
- AI Answers: Apply the site-wide Jetpack AI switch on self-hosted sites. [#51909]
- Dashboard: Drop the Preview label from AI Answers. [#51891]
- Update package dependencies. [#51701]
- Update react-redux to 9.3.0 and redux to 5.0.1. [#51912]

### Fixed
- Instant Search: Fix a crash on mount when the localized widget configuration is missing or incomplete, which could leave the whole page blank. [#51511]

## [8.0.0] - 2026-09-01
### Changed
- AI Answers: Follow the Jetpack AI master switch in the search overlay and the AI Answer block — live on WordPress.com Simple, internal testing environments elsewhere ahead of release. [#50884]
- AI Answers: Report the saved choice and the site-wide AI state in settings, disable the controls while AI is off, and honor the host AI opt-out in the AI Answer block. Require Instant Search to enable AI Answers. The master-state reporting follows the rollout: live on WordPress.com Simple, internal testing environments elsewhere. [#51538]
- Update package dependencies. [#51303] [#51802]

### Removed
- Minimum supported PHP version is now 7.4. [#51515]

### Fixed
- Only load the Jetpack plugin compatibility layer when the Jetpack plugin is actually present. [#49066]

## [7.4.1] - 2026-08-20
### Changed
- Update package dependencies. [#51399]

### Fixed
- Classic Search: Don't override a query already restricted by `post__in` once its search term has been cleared. [#51284]
- Input block: Fix the editor settings panel not being translated. [#51322]

## [7.4.0] - 2026-08-13
### Added
- Search Blocks: Add a No Results block so empty states can contain links, images, buttons, and other blocks instead of plain text. Continue rendering existing Results List messages while deprecating their settings. [#51164]

### Changed
- Update package dependencies. [#50509] [#51008]

### Fixed
- Search: Avoid a brief "No results found" flash before a search starts. [#50925]
- Search: Apply highlighting, query filtering, custom results, and cross-site search settings consistently across Embedded, Overlay Blocks, and Theme search experiences. [#50920]

## [7.3.3] - 2026-08-03
### Changed
- Rename the Reader Chat setting to Site Chat, and describe it as answering visitor questions about the site. [#50854]

### Fixed
- Blocks: Avoid parsing post content for filter blocks when none are present, preventing out-of-memory errors on large posts. [#50895]
- Blocks: Fix `is_search()` being called before the main query runs during block render, which caused a `_doing_it_wrong()` notice. [#51001]
- Check supports_instant_search, not the Atomic-unreliable supports_search, when deciding whether a site already has the Search product -- fixes Start for free/Get Search silently skipping checkout on Atomic sites that have a bundled classic-search entitlement. [#50843]
- Inline Search: Insert the corrected-query notice as text so search terms are not parsed as HTML. [#51001]
- Stop printing the theme-token-sampler script once the Search module is disabled. [#50896]

## [7.3.2] - 2026-07-27
### Added
- Add highlightPhraseOnly and highlightFilterStopwords Instant Search options for highlight API params. [#50738]

### Changed
- Update package dependencies. [#50751] [#50753]

### Fixed
- Blocks: Resize result images through Photon in the Embedded search layout to improve performance. [#50710]
- Fix uncaught error when a malformed query string parameter (invalid percent-encoding) crashed Instant Search initialization. [#50806]

## [7.3.1] - 2026-07-22
### Changed
- Internal updates.

## [7.3.0] - 2026-07-20
### Added
- Add a results-per-page setting to the Search Results block, falling back to the site's Reading setting when unset. [#50652]

### Changed
- Update package dependencies. [#50529]

### Fixed
- Fix checkout for unregistered sites getting stuck or redirected to the site selector instead of completing the purchase. [#50474]
- Fix the Search upsell page's product-availability check not returning its promise, which caused checkout to always run even when the site already had the Search product. [#50474]
- Overlay/embedded templates: Keep the Collapsible Filters panel in sync with the sidebar Filters block, locking it read-only in the editor when both coexist. [#50653]
- Overlay/embedded templates: Mark where a new filter belongs when adding it to the Filters (or Product Filters) block in the editor. [#50655]

## [7.2.8] - 2026-07-13
### Changed
- Update package dependencies. [#49272]
- Update WPDS design tokens to the @wordpress/theme 0.16/0.17 names (see https://github.com/WordPress/gutenberg/blob/trunk/packages/theme/CHANGELOG.md#0160-2026-06-24 ). [#49272]

## [7.2.7] - 2026-07-06
### Changed
- Update package dependencies. [#50097] [#50183] [#50212]

## [7.2.6] - 2026-06-29
### Changed
- Internal updates.

## [7.2.5] - 2026-06-25
### Changed
- Defer Search REST controller instantiation so it is only built when its REST routes are requested. [#49803]
- Update package dependencies. [#49831]

### Fixed
- Search Blocks: Fix deep-link searches (?s=) rendering no results or filter buckets. [#49944]
- Search Blocks: Fix result and filter lists rendering after results load. [#49876]

## [7.2.4] - 2026-06-22
### Changed
- Update package dependencies. [#49631] [#49691] [#49757]

### Fixed
- Search blocks: Use the default editor color for block icons. [#49756]

## [7.2.3] - 2026-06-15
### Changed
- Internal updates.

## [7.2.2] - 2026-06-10
### Changed
- Update package dependencies. [#49273] [#49492]

## [7.2.1] - 2026-06-08
### Changed
- Update dependencies. [#49354]

## [7.2.0] - 2026-06-01
### Added
- Search Blocks: Add a Width control (px / %) to the Search Input Block inspector. [#49210]
- Search Blocks: Add a WooCommerce Product Search Page pattern. [#49270]
- Search Blocks: Fire the TrainTracks render/interact analytics events from the blocks search path (embedded and overlay). [#49253]
- Search Blocks: Render product results and filters from a dedicated product overlay template on WooCommerce product searches. [#49262]

### Changed
- AI Agent Access: Show the opt-in toggle on public sites. [#49103]
- General: Exclude the search-blocks AGENTS.md and CLAUDE.md contributor docs from the production build. [#49269]
- Search Blocks: Collapse the filter sidebar at narrow widths on the `jetpack-search` and `jetpack-search-product-results` page templates. [#49181]
- Search Blocks: Default the checkbox-filter Custom Taxonomy label to the taxonomy's display name. [#49187]
- Search Blocks: Derive the Blog Search Page pattern from the shared search layout template. [#49270]
- Search Blocks: Drive the sidebar/popover responsive flip from a container query against the columns row. [#49227]
- Search Blocks: Drop the dedicated Search Layout wrapper block. [#49261]
- Search Blocks: Drop the filters-popover responsive display mode. [#49252]
- Search Blocks: Drop the stale embedded→inline fallback for non-block themes. [#49142]
- Search Blocks: Drop the `jetpack-search/clear-filters` block from the default content of the `filters`, `filters-popover`, and `filters-product` containers, the two bundled patterns (`blog-search`, `compact-search`), and the three page templates (`jetpack-search.html`, `jetpack-search-overlay.html`, `jetpack-search-product-results.html`). [#49182]
- Search Blocks: Hide the image column in the expanded Results List layout for results that have no image. [#49225]
- Search Blocks: Polish the no-results, error, and filters-empty messages with a consistent muted-scale typography across the overlay. [#49213]
- Search Blocks: Sample the active theme's body color and background at page load and feed them to the overlay card, filters popover, sort menu, and search-input suggestions surfaces. [#49212]
- Search Blocks: Stretch the filters sidebar to the full row height. [#49254]
- Search Blocks: Unify rating-star color contract and align suggestions / price-slider surfaces with the 3-tier theme-token fallback chain. [#49208]
- Search Blocks: Use the price slider variation of filter-wc-price in the product-results template. [#49217]
- Search Blocks: Focus the search input and place the caret at the end on search page render with existing query. [#49215]
- Search Blocks: Collapse the Overlay filter sidebar below 992px and dock a filters-popover trigger next to Sort By. [#49177]
- Search Blocks: Derive the Overlay card elevation shadow from the theme ink so it lifts off the scrim on dark themes. [#49265]
- Search Blocks: Separate the Overlay modal card from the dim scrim on dark themes. [#49207]
- Update package dependencies. [#48404]

### Removed
- Search Blocks: Remove the standalone "Post Type Scope" (filter-post-type) block. [#49209]
- Search Blocks: Remove the automatic switch to the Product layout for product-scoped searches, along with the per-block "Auto-switch to Product view" toggle. [#49257]

### Fixed
- Search Blocks: Make blocks-powered Overlay card wide on viewports ≥992px. [#49143]
- Search Blocks: Honor the legacy --background / --foreground theme color tokens in blocks-powered Overlay shell. [#49138]
- Search Blocks: Do not dismiss the blocks-powered Overlay on clicking a search suggestion. [#49137]
- Search Blocks: Strip the search/filter params from the URL and reload when closing the blocks-powered Overlay. [#49145]
- Search Blocks: Run the initial search when deep-linking to `/?s=` (empty value) on the blocks-powered Overlay instead of latching the "Searching…" skeleton on forever. [#49151]
- Search Blocks: Drop nested same-namespace `data-wp-interactive` on active-filters and filter-checkbox when rendered inside the collapsible filters popover. [#49185]
- Search Blocks: Render a solid background in filters-popover panel and results-sort menu on themes that don't define `--wp--preset--color--base`. [#49180]
- Search Blocks: Fix results-header text collapsing into vertical columns when the filters popover is open. [#49287]
- Search Blocks: Fix the visible seam in the blocks-powered Overlay's header underline at the close-button boundary, and bind the close button's hover surface to the resolved theme tokens. [#49179]
- Search Blocks: Give active-filter pills a theme-tracking keyboard focus ring. [#49259]
- Search Blocks: Keep view-module URLs same-origin so blocks load on Multisite mapped domains, www-vs-non-www mismatches, and CDN setups without CORS headers. [#49141]
- Search Blocks: Register singleton template CPTs synchronously when init() is invoked from inside an init action. [#49144]
- Search Blocks: Render active-filter pills as theme-tracking outline chips (matching the filter chips) instead of solid buttons. [#49255]
- Search Blocks: Render the product-results body (filters-product, results-list layout=product, WC-only filters) on classic themes when "Use Jetpack Search for product search results" is enabled. [#49176]
- Search Blocks: Route the Restore Default action through jetpack/v4. [#49150]
- Search Blocks: Show the loading skeleton during the initial client-side search. [#49264]
- Search Blocks: Strip the scalar `post_type` alias when closing the blocks Overlay. [#49275]
- Search Blocks: Surface the "No filters available" empty state in the embedded and overlay templates. [#49146]
- Search Blocks: Restore header hairline + button-hover affordances on themes without --wp--preset--color--base / --contrast tokens in Overlay. [#49184]

## [7.1.0] - 2026-05-25
### Added
- Experience Selector: Add a new "Overlay search" card backed by the experimental blocks-powered overlay; the legacy preact Overlay is renamed to "Overlay search (legacy)" when the new card is visible. [#48994]
- Experience Selector: Release the blocks-powered Overlay as an experimental option, surfaced as an "Overlay search (blocks)" card with a Beta badge alongside the preact Overlay. [#49118]
- Search Blocks: Add a "Post types" setting to the Search Input block so authors can scope a search to specific post types directly on the input. [#49078]
- Search Blocks: Add an opt-in "Load on scroll" mode to the Load More block. [#49046]
- Search Blocks: Add classic-theme support to the Embedded search experience, with an "Edit search template" link that opens the bundled template in the block editor. [#49117]
- Search Blocks: Show a "No filters available" empty state in the Filters and Product Filters containers when a search returns no facets. [#49089]
- Search Blocks overlay: Add an "Edit the Search overlay" entry point in the Jetpack Search dashboard that opens the experimental overlay template in the block editor. A "Restore default" link reverts to the bundled template. [#49028]

### Changed
- Internal: Recognize `kind: 'static'` flag in `filterConfig` entries to improve selections via `?filter_id=value` URL params. [#49038]
- Search Blocks: Add a small top gap between the Search Input header and the first row of results inside the blocks-powered Overlay. [#49120]
- Search Blocks: Add horizontal gutters and a content-width cap to the Embedded search page on classic themes. Honors `--wp--style--global--wide-size` when a classic theme ships `theme.json`. [#49127]
- Search Blocks: Default the "Clear Filters" button to the Compact style in the Filters and Product Filters compositions. [#49087]
- Search Blocks: Enable the Interactivity-API Search blocks by default. The `jetpack_search_blocks_enabled` filter is retained as a kill-switch. [#49037]
- Search Blocks: Add an opt-in responsive `displayMode` to the Filters popover — inline filters on wider screens that collapse to the popover trigger on narrow ones. [#49045]
- Search Blocks: Gate the AI Answer block behind a paid Search plan. [#49033]
- Search Blocks: Skip the server-side search query in the Embedded and blocks Overlay experiences, where results are fetched client-side. [#49074]
- Search Blocks: Require WooCommerce 6.5 or newer for the WooCommerce-only filter blocks to register. [#49091]
- Search Blocks: Register the WooCommerce filter blocks (product attribute, price, rating, and stock-status) based on WooCommerce's active state instead of force-disabling them; the `jetpack_search_woocommerce_blocks_enabled` filter still overrides the gate. [#49085]
- Search Dashboard: Rename the "Plan & Usage" tab to "Overview". [#49041]
- Search Dashboard: Route tabs via the URL hash (`#/<slug>`) instead of the `?tab=<slug>` query parameter. Existing `?tab=<slug>` URLs are normalized on mount. [#49042]

### Fixed
- Instant Search: Scope the search suggestions dropdown to the overlay box input, stopping it from leaking onto the WP Admin bar search. [#49090]
- Search Blocks: Hide the Load More button while the "Loading…" indicator is showing. [#49044]
- Search Blocks: Overlay shell honors theme color tokens, so the modal stays readable on dark block themes. [#49125]
- Search Blocks: Render the active theme's header/footer template parts on the search page instead of the hardcoded `header` / `footer` slugs. [#49026]
- Search Blocks: Render the Search Input suggestions panel cleanly on top of the results and filters area in the blocks-powered Overlay. [#49124]
- Search Blocks: Auto-open on initial page load when the URL contains `?s=` or `?q=`. [#49073]
- Search Dashboard: Gate Reader Chat controls by Search plan support and usage status, and show a Preview badge beside the Reader Chat toggle. [#48890]
- Search Dashboard: Improve Overview tab responsiveness at tablet widths. [#49128]
- Search dashboard: Mirror the `jetpack_search_blocks_enabled` server default in the React initial state so the Experience Selector renders on stock sites. [#49116]
- Search Dashboard: Route sites without instant search support (including Atomic) to the pricing upsell page instead of showing the Overview tab's mocked-only state. [#49119]

## [7.0.0] - 2026-05-21
### Added
- Search: Add a "Compact" block style to the Clear Filters block and stop it inheriting the core Button block styling that rendered oversized on some themes — the default now uses the theme's lighter button baseline. [#48946]
- Search: add an AI Answer block (`jetpack-search/ai-answer`) so authors can surface the AI Answers panel inside the embedded search template — previously only the instant-search overlay could render it. [#48986]
- Search: Make the Load More block match the theme's regular core/button look and add a "Compact" block style so authors can right-size it without custom CSS. [#48984]
- Search: surface the "Enable search suggestions" and "Enable AI Answers" toggles in the search customizer's Additional settings panel, alongside their existing home on the search dashboard. [#48990]
- Search Blocks: Add experimental opt-in to replace the legacy instant-search overlay with the server-rendered Search blocks template; gated behind the `jetpack_search_overlay_block_template_enabled` filter (default false). [#48987]
- Search Blocks: add optional autocomplete suggestions dropdown to the Search Input block — query, taxonomy, and post suggestions powered by the WPCOM search-suggestions endpoint. Authors opt in per block via the new "Show search suggestions" inspector toggle. Taxonomy picks apply as an inline filter when a matching filter block is on the page, otherwise navigate to the archive URL. [#48985]
- Search dashboard: add a "WooCommerce Product Search" control that, when enabled, serves product searches from a dedicated Site-Editor-editable Jetpack Search template instead of WooCommerce's default product search template. [#48936]
- Search Dashboard: add an "Additional settings" heading above the feature toggles in the search-blocks settings view. The heading only renders when at least one of those settings is available, so it never appears orphaned. [#48948]

### Changed
- Build: collapse the per-directory `production-exclude` rules for `src/**/*.js` into a single broad exclude with an explicit carve-out for `src/widgets/**/*.js` (which has no build step and must ship). [#48983]
- Replace internal ContextualUpgradeTrigger upgrade prompts with @wordpress/ui Notice composition. Internal refactor with a Notice-style visual refresh. [#48909]
- Search: Normalize page tabs onto shared minimal variant + jp-admin-page-tabs--minimal wrapper modifier. Bump @wordpress/ui to 0.13.0. [#48964]
- Search: the AI Answer block (`jetpack-search/ai-answer`) no longer gates on the site-wide `jetpack_search_ai_answers_enabled` option — block presence in post content is the only switch. The option still governs the instant-search overlay. [#48993]
- Search Blocks: let authors pick which suggestion sections appear in the Search Input dropdown (query completions, categories & tags, post titles) via a new per-block suggestionTypes attribute. Existing blocks default to all three. [#48991]
- Update package dependencies. [#48405] [#49012]

### Fixed
- AI Answers: Fix the answer panel colors in dark mode. [#49019]
- Instant Search: Prevent the search modal from triggering on third-party form submissions. Forms embedding an input named "s" (e.g. ActiveCampaign sign-up widgets) would incorrectly open the search overlay and block the submission. The fix checks that the form's action URL shares the same origin as the site before intercepting. [#48958]
- Phan: Address PhanPluginDuplicateConditionalNullCoalescing violations. [#48887]
- Search: reject experience requests combined with ai_answers_enabled or search_suggestions_enabled instead of silently dropping them, and gate the WooCommerce product-search template override on the active experience so a stale option can't keep rerouting after a switch away from a server-rendered experience. [#48956]
- Search Blocks: cap the filter-checkbox list at its configured "Maximum items" even after the session has retained options across multiple searches. [#48989]
- Search Dashboard: Hide the AI Agent Access toggle for private sites and improve related settings spacing. [#48912]
- Search dashboard: let the toggle description text span the full settings card width instead of wrapping in a narrow 7-column band. [#48944]

## [0.60.0] - 2026-05-19
### Added
- Add a `wp jetpack-search backfill_taxonomy_slot_mapping [--mode=mirror|rebuild]` command for backfilling custom-taxonomy slot mappings. [#48849]
- Add auto-complete search suggestions feature. [#48473]
- AI Answers: Add a customization dashboard for AI Answers behavior. [#48592]
- AI Answers: Add a streaming AI answers panel to the instant-search overlay, available on all paid plans. [#48592]
- REST API: Add a `search_experience` parameter (`overlay` | `inline` | `embedded`) to `/jetpack/v4/search/plan/activate`. [#48848]
- Search Blocks: Add a `rebuild` mode for custom-taxonomy slot backfills. [#48708]
- Search Blocks: Add an "Auto-switch to Product view" toggle on Results List blocks to opt out per block. [#48943]
- Search Blocks: Add automatic Results List switching to the Product layout when the URL scopes search to the `product` post type. [#48943]
- Search Blocks: Add Custom Taxonomy filter support for mapped taxonomies in Jetpack Search's index. [#48684]
- Search Dashboard: Add a 2x2 experience selector with previews and customization actions on the Settings tab. [#48563]
- Search Dashboard: Add AI Agent Access opt-in toggle. [#48362]

### Changed
- Dashboard: Add "Autocomplete" to the pricing comparison grid, shown as included on both the free and paid plans. [#48899]
- Dashboard: Add "Jetpack Search blocks" and "Embedded search page" to the pricing comparison grid, shown as included on both the free and paid plans. [#48891]
- Dashboard: Add an "AI Answers (Preview)" row to the pricing comparison grid, included on the paid plan only. [#48896]
- Dashboard: Show pricing rows for Jetpack Search blocks and Embedded search only when Search blocks are enabled. [#48893]
- Exclude development files from production builds. [#47365]
- Search 3.0: Honor the site's date format setting in result cards. [#48763]
- Search 3.0: Show the post author before the date in expanded result cards. [#48751]
- Search Blocks: Hide Search 3.0 blocks from the editor on disconnected sites and sites without a Search plan. [#48818]
- Search Blocks: Rename the WooCommerce gate consistently across the PHP and JS layers. [#48749]
- Search Dashboard: Polish the Settings experience selector. [#48819]
- Update package dependencies. [#48695] [#48696]

### Fixed
- Dashboard: Persist the active Search dashboard tab in the URL across page refreshes. [#48752]
- Dashboard: Update the AI Answers Instant Search notice to point to the Settings tab. [#48822]
- Keep Search experience changes synced for overlay, inline, embedded, and freshly installed sites. [#48745]
- Search 3.0: Fall back to Theme search when the Embedded experience is configured on a non-block theme. [#48941]
- Search Blocks: Only register the Jetpack Search block template and prepend it to the search template hierarchy on block themes during an actual search request. [#48935]
- Search Blocks: Show results for explicit empty searches (`?s=`) instead of leaving the results area empty. [#48707]
- Search Dashboard: Avoid crashes when the WordPress.com plan response is missing usage or current-plan fields. [#48660]
- Search Dashboard: Block switching to Embedded search on classic themes and explain that Embedded search requires the Site Editor. [#48942]
- Search Dashboard: Fix the AI Answers disable toggle so turning it off actually disables the feature. [#48777]
- Search Dashboard: Keep autocomplete suggestions settings available when the Search blocks experience is enabled. [#48898]
- Search Dashboard: Keep the Reader Chat toggle reachable in the experience selector when Search blocks are enabled. [#48816]
- Search Dashboard: Open Embedded experience links in the Jetpack Search template view and filtered patterns library. [#48851]
- Search Dashboard: Record Reader Chat toggle events immediately after settings save, and move the Reader Chat setting after the Instant Search setting. [#48724]
- Search Dashboard: Restore the visible space between "AI Answers" and "(Preview)" in the dashboard tab label. [#48850]

## [0.59.0] - 2026-05-11
### Added
- Search 3.0: Add "Matches content" / "Matches comments" hint badge to the product layout result card when a non-title field matches but the title does not. [#48518]
- Search 3.0: Add a "Slider" variation to `jetpack-search/filter-wc-price`. Toggling `showSlider` reveals a dual-thumb single-track slider above the existing min/max inputs — mirroring WooCommerce Blocks' `product-filter-price-slider` pattern. [#48670]
- Search 3.0: Add a per-block "Logic" toggle to `jetpack-search/filter-checkbox` taxonomy filters. [#48685]
- Search 3.0: Add the `jetpack-search/filter-wc-attribute` block for filtering by a single WooCommerce product attribute. [#48450]
- Search 3.0: Add the `jetpack-search/filter-wc-price` block with min/max number inputs bound to the shared price range state. [#48449]
- Search 3.0: Add the `jetpack-search/filter-wc-rating` block with rating-bucket filtering. [#48448]
- Search 3.0: Add the `jetpack-search/filters-product` parent block for grouping product filter children. [#48454]
- Search 3.0: Add `jetpack-search/filter-wc-stock-status` block — a single "In stock" toggle that excludes WooCommerce out-of-stock products via the `product_visibility` taxonomy. [#48447]
- Search 3.0: Extract the "Clear filters" affordance from `jetpack-search/active-filters` into a standalone `jetpack-search/clear-filters` block. [#48452]
- Search 3.0: Register WooCommerce product Category, Tag, and Brand as inserter-visible variations on the existing jetpack-search/filter-checkbox block. [#48629]
- Search 3.0: Restore product-format sort keys on the results-sort block when WooCommerce is active. [#48671]
- Search: Add backend support for the `experience` field in the search settings REST endpoint. `POST /jetpack/v4/search/settings` accepts `experience` (`embedded`, `overlay`, `inline`, or `off`) and updates the package state in lockstep. `GET /jetpack/v4/search/settings` returns the active `experience`, derived from the legacy settings for sites that have not yet saved via the new UI. [#48540]
- Search: Add Reader Chat opt-in card to the dashboard so site owners can enable or disable Reader Chat without writing PHP. [#48144]
- Search Blocks: Add 'product' layout to the search-results block, alongside an Inspector control to switch between compact / expanded / product. [#48509]
- Search Blocks: Add a "Powered by Jetpack" block (`jetpack/powered-by`) to the results-panel default template, patterns, and search template. [#48548]
- Search Blocks: Add a chips display style option to the Checkbox Filter block. [#48678]
- Search Blocks: Add a hidden Post Type Scope block that constrains results to an include/exclude post-type list. [#48501]
- Search Blocks: Add foundation data-plane primitives for the upcoming WooCommerce product filter blocks. [#48446]
- Search Blocks: Add jetpack/results-panel container block bundling the result-display stack. [#48504]
- Search Blocks: Extend the chips display style option to the Date and Product Attribute filter blocks. [#48680]
- Search Blocks: Render highlighted content snippet under the result title in the expanded card layout. [#48516]
- Search Dashboard: Add new feature-selection UI gated behind the jetpack_search_blocks_enabled filter. [#48500]
- Search Dashboard: Add Storybook stories for feature-selector components (ExperienceOption and FeatureSelector). [#48624]

### Changed
- Components: Replace Gridicon with Icon and named icon exports from `@wordpress/icons`. [#48537]
- Components: Use Link from `@wordpress/ui` instead of ExternalLink. [#48529]
- Search 3.0: Consolidate icons across all Search blocks so they read as one branded family in the inserter, breadcrumb, and toolbar. [#48686]
- Search 3.0: Extend the `jetpack-search/active-filters` block to render product-aware chips. [#48453]
- Search 3.0: Extract the rating filter's cumulative bucket projection into its own module and add unit tests for the threshold semantics. [#48630]
- Search 3.0: Hide WooCommerce-only blocks, filter variations, layouts, and price-range URL params on sites without WooCommerce active. [#48675]
- Search 3.0: Include `jetpack-search/clear-filters` in the `jetpack-search/filters-product` allowed list and seed it in the default template. [#48672]
- Search 3.0: Only override the theme's search template when the saved experience is `embedded`. [#48562]
- Search 3.0: Redesign `jetpack-search/filter-wc-rating` as the industry-standard "X stars & up" threshold filter. [#48628]
- Search 3.0: Rename the default filter composition block from `jetpack-search/filters-stack` to `jetpack-search/filters`. [#48674]
- Search: Migrate dashboard notices to the @wordpress/ui Notice component. [#48550]
- Search Blocks: Align all 13 blocks under three predictable naming patterns and move them to a dedicated jetpack-search/* namespace. [#48590]
- Search Blocks: Allow the Post Type Scope block to be inserted inside the Filters container. [#48511]
- Search Blocks: Convert createElement/h calls to JSX in editor preview components for readability. [#48502]
- Search Blocks: Differentiate result path and content text styles in the expanded layout. [#48587]
- Search Blocks: Fold the no-results and search-error blocks into jetpack/search-results so the editor exposes one block with three states. [#48513]
- Search Blocks: Keep previously-seen checkbox filter options visible and uncheckable across searches. [#48593]
- Search Blocks: Keep selected filter-checkbox and filter-date buckets visible in the list so visitors can untick them in place. [#48591]
- Search Blocks: Render skeleton placeholders pre-hydration so deep-linked search pages don't flash blank columns before the JS view bundle loads. [#48505]
- Search Blocks: Render WooCommerce formatted prices and post titles as plain text. [#48549]
- Search Dashboard: Hide the Off row of the new feature-selector on WordPress.com. [#48558]

### Fixed
- Search 3.0: Prevent 404 when refreshing a singular page that hosts inline search blocks. [#48436]
- Search 3.0: Stop showing the "Matches content" badge on result cards when the visitor has only applied filters without typing a search query. [#48687]
- Search: Bundle @wordpress/theme and @wordpress/private-apis inline in the dashboard build so it does not silently fail to load when those packages are not registered as WP script handles. [#48550]
- Search Blocks: Add pre-hydration skeleton to the WooCommerce attribute filter block. [#48677]
- Search Blocks: Category, Tag, Post Type, Author, and Custom Taxonomy filter presets now appear in the block inserter. [#48589]
- Search Blocks: Clear the previous query's results, total count, and aggregation buckets when a search request errors out. [#48541]
- Search Blocks: Fix block-validation error on results-panel, filter-popover, and common-filters when inserted via patterns. [#48545]
- Search Blocks: Fix pre-hydration skeleton shape for the product layout. [#48514]
- Search Dashboard: Fix the upsell page clipping its pricing rows at the footer line under the shared `jetpack-admin-page-layout` mixin. [#48623]

## [0.58.0] - 2026-05-04
### Added
- Search 3.0: Add common-filters block — Group-like container for stacking filter blocks (active filters, taxonomy/author/post-type checkboxes, date). [#48478]
- Search 3.0: Add Compact Search block pattern with inline filter and sort popover controls. [#48288]
- Search 3.0: Add filter-date block for filtering search results by year or month. [#48439]
- Search 3.0: Introduce product-shaped filter support to store/api helpers — `wc_stock_status` (terms agg + term clause on `meta._stock_status.value.raw`), `wc_rating` (histogram agg + range-OR clauses on `meta._wc_average_rating.double`), `priceRange` (range clause on `wc.price`), scalar comma-joined URL parsing, and first-paint URL seeding for `min_price`/`max_price`. Infrastructure only; no new blocks ship in this change. [#48397]
- Search: Render a visible error message when a search or load-more request fails. [#48477]
- Search Blocks: Add inspector Filter type control so authors can swap a filter-checkbox between Category, Tag, Post Type, Author, and Custom Taxonomy variations without re-inserting the block. [#48291]
- Search Blocks: Add Inspector panel to the no-results block so block authors can customize the empty-state message. [#48279]
- Search Blocks: Introduce defaultSort, availableSortOptions, label, and displayAs attributes to sort-control. [#48282]

### Changed
- Internal: No longer require automattic/jetpack-changelogger as a per-project dev dependency. [#48225]
- Search: Restyle sort-control radio variant as text-only links with a bullet separator. [#48367]

### Fixed
- Search 3.0: Add ARIA menu keyboard navigation to compact sort popover. [#48371]
- Search 3.0: Surface a Taxonomy picker so the Custom Taxonomy filter variation actually targets a registered taxonomy. [#48428]
- Search: Change search overlay heading from h1 to h2 to fix heading hierarchy on pages that already have an h1. [#48245]
- Search: Disable the "Edit sidebar widgets" button when Instant Search is disabled, preventing a fatal error on block themes that do not register classic sidebars. [#48430]
- Search: Fix dashboard hero section being crushed under shared admin page layout mixin. [#48437]
- Search Blocks: Gate URL-seeded activeFilters on the client instead of at PHP seed time, so deep links work for filter blocks placed in templates / template parts (not just post content). [#48475]
- Search Blocks: Keep `s=` in the URL when the search query is empty so a refresh stays on the search template instead of falling back to the front-page route. [#48370]
- Search Blocks: Render human-readable labels in active-filter pills and resort `bucketSortOrder=alpha` filter lists by visible label client-side. [#48426]

## [0.57.0] - 2026-04-27
### Added
- Search 3.0: Add icons for the Jetpack Search blocks and improve Blog Search pattern keywords. [#48232]
- Search 3.0: Add `filter-checkbox` and `active-filters` blocks with instant-search-aligned field conventions, aggregation-driven item lists, and flat URL state (?category[]=news). [#48227]
- Search 3.0: Use Interactivity API block foundation — composable search blocks, shared reactive store, and Blog Search Page pattern (Phase 1). [#48198]
- Search 3.0: Expose buttonLabel attribute on `load-more` block (editor inspector text input, translated default fallback) and adopt the active theme's button styles via the wp-element-button class. [#48253]
- Search 3.0: Render sample data in the Site Editor preview for each search block so designers see a real DOM shape instead of an empty ServerSideRender shell. [#48233]
- Search: Add fallback image capability in expanded search. [#44657]
- Search: Register a plugin-origin block template so the Jetpack Search layout takes over the theme's search results page. [#48252]
- Search Blocks: Add inspector controls for label, showCount, and maxItems, plus a bucketSortOrder attribute (count | alpha, default count) to filter-checkbox. [#48281]
- Search Blocks: Add authoring controls to `search-input`, including placeholder (declared), showIcon, and submitOnly attributes, with matching inspector controls. [#48280]

### Changed
- Remove redundant @wordpress/interactivity imports from display-only block views. [#48229]
- Search 3.0: Rename the block inserter category to "Search" with the Jetpack logo so it matches the Forms, Monetize, and Grow headings. [#48256]
- Search 3.0: Split editor-side block preview Edit components out of register-blocks.js into per-block edit.js files so changes to one block do not conflict with others. [#48255]
- Search 3.0: Swap hardcoded colors in block styles for theme-aware tokens so the search blocks adapt to the active theme palette and dark backgrounds. [#48259]
- Update package dependencies. [#48302]

### Fixed
- Search 3.0: Hide the `load-more` wrapper while a first-page search is in flight, and swap the button for a spinner while paginating. [#48231]
- Search 3.0: Keep the search results list in the DOM so screen readers announce updates from the ARIA live region. [#48230]
- Search 3.0: Localize Interactivity API view-bundle strings (results count, loading indicator, and active-filter pill aria labels) via wp_interactivity_state. [#48257]
- Search 3.0: Reuse the results-count block as the loading indicator ("Searching…") so the control row doesn't flicker between queries. [#48234]

## [0.56.10] - 2026-04-20
### Changed
- Adopt the shared Jetpack admin-page-layout mixin on the Search admin page. Drops the inline JetpackFooter render and `showFooter={false}` override so AdminPage's built-in footer lives inside the flex column that the mixin pins. [#48109]
- Align Search dashboard toggle to its label baseline so wrapped labels on mobile no longer push the toggle into the middle of the row. [#48178]
- Drop the local `#screen-meta`/`#screen-meta-links` hide rule now that the shared admin-page-layout mixin handles it. [#48195]
- Remove custom toggle color overrides to use native WordPress admin theme colors. [#47317]
- Swap the custom FormToggle on the Search admin dashboard for WordPress ToggleControl, restoring native rendering of the Enable Jetpack Search and Enable instant search toggles. [#48178]
- Update package dependencies. [#48106] [#48141]

### Removed
- Remove the unused custom FormToggle component; all call sites now use WordPress ToggleControl. [#48178]

### Fixed
- Fix mobile overflow on the upsell/pricing page so cards no longer get clipped. [#48194]

## [0.56.9] - 2026-04-15
### Changed
- Update package dependencies. [#47907]

### Fixed
- Dashboard: Avoid forcing a white background in the upsell pricing grid view. [#48088]

## [0.56.8] - 2026-04-10
### Changed
- Update package dependencies. [#47890] [#47998]

## [0.56.7] - 2026-04-06
### Changed
- Update admin page footer design. [#47840]

## [0.56.6] - 2026-03-30
### Changed
- Update package dependencies. [#47799]

## [0.56.5] - 2026-03-23
### Changed
- Move admin notices and JITMs below the page header instead of rendering inside it. [#47558]
- Search: Update header action buttons to use compact size for consistent UI. [#47679]
- Update package dependencies. [#47684]

## [0.56.4] - 2026-03-16
### Changed
- Update dependencies. [#47472]

## [0.56.3] - 2026-03-09
### Changed
- Dashboard: Remove global CSS overrides and move admin notices inside the main container. [#47313]
- Migrate upsell page header to use unified AdminHeader component. [#47313]
- Replace license activation link with a "Use license key" button in the header actions area. [#47434]
- Use the core WordPress spinner component for the dashboard loading state. [#47467]
- Update package dependencies. [#47496]

### Fixed
- Constrain license activation link width on mobile to prevent header overflow. [#47431]

## [0.56.2] - 2026-03-02
### Changed
- Update package dependencies. [#47357]

## [0.56.1] - 2026-02-26
### Changed
- Search admin: Change `max-width` of contents to 1040px. [#47326]
- Update package dependencies. [#47288] [#47300]

## [0.56.0] - 2026-02-23
### Added
- Add a new `disable_tracking` feature flag. [#46722]

### Changed
- Update package dependencies. [#47173]

## [0.55.4] - 2026-02-16
### Changed
- Update package dependencies. [#47099]

### Fixed
- Compatibility: Clean up deprecated CSS. [#47067]

## [0.55.3] - 2026-02-10
### Changed
- Update dependencies. [#46931] [#47002]

## [0.55.2] - 2026-02-02
### Changed
- Update package dependencies. [#46854]

## [0.55.1] - 2026-01-26
### Changed
- Update dependencies. [#46741]

## [0.55.0] - 2026-01-19
### Added
- Add a "Show price" option to allow prices to be shown or hidden in Jetpack Instant Search results. [#46454]

### Changed
- Show WooCommerce product filters in filter widget. [#46373]
- Update package dependencies. [#46552] [#46647]

## [0.54.10] - 2026-01-12
### Changed
- Update package dependencies. [#46456] [#46491]

## [0.54.9] - 2025-12-22
### Changed
- Update dependencies. [#46381]

## [0.54.8] - 2025-12-15
### Changed
- Update dependencies. [#46271]

## [0.54.7] - 2025-12-08
### Fixed
- Ensure proper flags are used with `json_encode()`. [#46092]

## [0.54.6] - 2025-12-01
### Changed
- Update package dependencies. [#46143]

## [0.54.5] - 2025-11-21
### Fixed
- Phan: Address PhanPossiblyUndeclaredVariable violations. [#45911]

## [0.54.4] - 2025-11-18
### Changed
- Update dependencies.

## [0.54.3] - 2025-11-17
### Changed
- Update package dependencies. [#45915] [#45958]

## [0.54.2] - 2025-11-12
### Changed
- Internal updates.

## [0.54.1] - 2025-11-10
### Changed
- Use native WordPress API to load CSS. [#45694]
- Use number formatting in pricing/plan features. [#45794]
- Tests: Ensure PHP 8.5 compatibility. [#45769]
- Update package dependencies. [#45756]

## [0.54.0] - 2025-11-03
### Changed
- Don't translate product names. [#43961]
- Update dependencies. [#45664]

### Fixed
- Phan: Address PhanRedundantCondition, PhanRedundantArrayValuesCall, and PhanPluginRedundantAssignment violations. [#45681]

## [0.53.0] - 2025-10-27
### Added
- Instant Search: Add global WooCommerce Product Attributes as filter options. [#45416]

### Changed
- Instant Search: Fix issue where Safari's 'Use advanced tracking and fingerprinting protection' setting breaks Search. [#45582] [#45588]

## [0.52.24] - 2025-10-21
### Fixed
- Instant Search: Handle browser privacy settings stripping out the search query value. [#45533]

## [0.52.23] - 2025-10-20
### Changed
- Update dependencies. [#45488]

## [0.52.22] - 2025-10-13
### Fixed
- Prevent PHP errors when handling malformed data. [#45419]

## [0.52.21] - 2025-10-06
### Changed
- Update package dependencies. [#45334]

## [0.52.20] - 2025-09-29
### Changed
- Update dependencies.

## [0.52.19] - 2025-09-22
### Changed
- Update dependencies.

## [0.52.18] - 2025-09-19
### Changed
- Update package dependencies. [#45173] [#45229]

## [0.52.17] - 2025-09-15
### Changed
- Update package dependencies. [#45127] [#45128]

## [0.52.16] - 2025-09-08
### Changed
- Update package dependencies. [#45027]

## [0.52.15] - 2025-09-01
### Changed
- Update dependencies.

## [0.52.14] - 2025-08-25
### Fixed
- Resolve `PhanImpossibleCondition` violations. [#44869]
- Pass SSL argument properly to Photon for sites with https enabled. [#44851]

## [0.52.13] - 2025-08-18
### Changed
- Update dependencies.

## [0.52.12] - 2025-08-14
### Changed
- Update package dependencies. [#44701]

## [0.52.11] - 2025-08-11
### Changed
- Update package dependencies. [#44677]

### Fixed
- I18n: Improve context hints in comments for translators. [#44686]
- Prevent PHP errors when directly accessing various files. [#44646]

## [0.52.10] - 2025-08-04
### Changed
- Update dependencies. [#44551]

## [0.52.9] - 2025-07-28
### Changed
- Internal updates.

## [0.52.8] - 2025-07-21
### Changed
- Update package dependencies. [#44356]

## [0.52.7] - 2025-07-14
### Changed
- Update package dependencies. [#44217]

## [0.52.6] - 2025-07-07
### Changed
- Update package dependencies. [#44148] [#44151]

### Fixed
- Accessibility: Update screen reader 'clip' property usage to 'clip-path'. [#44027]

## [0.52.5] - 2025-06-30
### Changed
- Internal updates.

## [0.52.4] - 2025-06-24
### Changed
- Update dependencies.

## [0.52.3] - 2025-06-23
### Changed
- Update package dependencies. [#44020]

## [0.52.2] - 2025-06-16
### Changed
- Update dependencies.

## [0.52.1] - 2025-06-10
### Changed
- Update dependencies.

## [0.52.0] - 2025-06-09
### Fixed
- Address `body_class` filter fatal in older versions of the Blaskan theme. [#43797]
- Tests: Ensure method param count matches PHPUnit data providers. [#43815] [#43828]

## [0.51.0] - 2025-06-05
### Changed
- Update package dependencies. [#43734] [#43747]

### Removed
- Classic Themes: Replace the Core Search widget instead of adding a new widget to the main sidebar. [#43450]

## [0.50.2] - 2025-06-02
### Changed
- Update package dependencies. [#43710]

### Fixed
- Protect against improper calls to `the_title()` filter. [#43511]

## [0.50.1] - 2025-05-26
### Changed
- Update package dependencies. [#43516] [#43578]

## [0.50.0] - 2025-05-19
### Added
- Add highlighting of search term in returned search results. [#43110]
- Allow new Inline Search to be enabled. [#43457]

### Changed
- Update package dependencies. [#43398]

### Fixed
- Mitigate bug with certain P2 theme [#43503]

## [0.49.0] - 2025-05-15
### Added
- Add query filters support to Inline Search. [#43441]

## [0.48.0] - 2025-05-12
### Added
- Surface search corrections when correcting search terms. [#42473]

### Changed
- Update package dependencies. [#43400]
- Use functions from the `@automattic/number-formatters` package. [#42796]

## [0.47.24] - 2025-05-05
### Changed
- Update package dependencies. [#43320] [#43326] [#43350]

### Fixed
- Linting: Address final rules in WordPress Stylelint config. [#43296]
- Linting: Do additional stylesheet cleanup. [#43247]

## [0.47.23] - 2025-04-28
### Fixed
- Linting: Fix more Stylelint violations. [#43213]
- Linting: Remove outdated vendor prefixes in stylesheets. [#43219]

## [0.47.22] - 2025-04-14
### Fixed
- Fix errors caused by malformed order arguments. [#42897]
- Linting: Format SCSS imports consistently. [#43018]
- Linting: Update stylesheets to use WordPress rules for fonts and colors. [#42920] [#42928]
- Linting: Use double colon notation for pseudo-element selectors. [#43019]

## [0.47.21] - 2025-04-07
### Changed
- Code: First pass of style coding standards. [#42734]

## [0.47.20] - 2025-04-04
### Changed
- Update dependencies. [#42820]
- Update package dependencies. [#42809]

### Fixed
- Admin menu registration: Allow child classes to overwrite priority. [#42814]

## [0.47.19] - 2025-03-31
### Changed
- Update dependencies. [#42678]

### Fixed
- Admin Menu: Ensure Akismet menu item shows alongside standalone plugin menus. [#42776]
- Components: Prevent deprecation notices by adding `__next40pxDefaultSize` to controls. [#42677]

## [0.47.18] - 2025-03-24
### Changed
- Update dependencies. [#42564]

### Fixed
- Search: Ensure the count of returned results is shown after searching. [#42570]

## [0.47.17] - 2025-03-18
### Changed
- Update package dependencies. [#42511]

## [0.47.16] - 2025-03-17
### Changed
- Update dependencies. [#42498]

## [0.47.15] - 2025-03-12
### Added
- Provide connection data to footer component. [#42000]

### Changed
- Update package dependencies. [#42384]

## [0.47.14] - 2025-03-10
### Changed
- Internal updates.

## [0.47.13] - 2025-03-03
### Changed
- Update package dependencies. [#42163]

## [0.47.12] - 2025-02-24
### Fixed
- Code: Prevent dynamic class properties. [#41857]

## [0.47.11] - 2025-02-17
### Changed
- Update dependencies.

## [0.47.10] - 2025-02-11
### Changed
- Update dependencies.

## [0.47.9] - 2025-02-10
### Changed
- Updated package dependencies. [#41491] [#41577]

## [0.47.8] - 2025-02-03
### Changed
- Updated package dependencies. [#41286]

## [0.47.7] - 2025-01-27
### Changed
- Internal updates.

## [0.47.6] - 2025-01-20
### Changed
- Code: Use function-style exit() and die() with a default status code of 0. [#41167]
- Updated package dependencies. [#41099]

## [0.47.5] - 2025-01-06
### Changed
- Updated package dependencies. [#40784] [#40792] [#40797] [#40813] [#40843]

## [0.47.4] - 2024-12-16
### Changed
- Updated package dependencies. [#40564]

### Fixed
- Fix missing instant search dialog for themes like Rebalance. [#40472]

## [0.47.3] - 2024-12-09
### Changed
- Updated package dependencies. [#40363]

## [0.47.2] - 2024-11-26
### Changed
- Update dependencies.

## [0.47.1] - 2024-11-25
### Changed
- Updated dependencies. [#40286]
- Updated package dependencies. [#40288]

## [0.47.0] - 2024-11-18
### Removed
- General: Update minimum PHP version to 7.2. [#40147]

## [0.46.0] - 2024-11-11
### Added
- Search: Add ability to customize results [#36378]

### Changed
- Classic Widget: update asset enqueuing strategy to ensure compatibility with the Elementor plugin. [#39820]
- Exclude corejs `exnext.iterator.` polyfills to avoid bloating the bundle. [#40060]
- Updated package dependencies. [#39999] [#40060]

## [0.45.12] - 2024-11-04
### Added
- Enable test coverage. [#39961]

## [0.45.11] - 2024-10-29
### Changed
- Components: Add __nextHasNoMarginBottom to BaseControl-based components, preventing deprecation notices. [#39877]

## [0.45.10] - 2024-10-28
### Changed
- Updated package dependencies. [#39910]

## [0.45.9] - 2024-10-21
### Changed
- Update dependencies. [#39781]

## [0.45.8] - 2024-10-14
### Changed
- Updated package dependencies. [#39707]

### Fixed
- Add `key` to tag and cat lists in `SearchResultMinimal` to improve behavior if lists change at runtime. [#39709]

## [0.45.7] - 2024-10-07
### Changed
- Updated package dependencies. [#39592] [#39594] [#39595] [#39639]

## [0.45.6] - 2024-09-30
### Changed
- Update dependencies. [#39528]

## [0.45.5] - 2024-09-23
### Changed
- Instant search: Use triggering element's document instead of the global `document`. [#39364]
- Search: reduce database calls by ensuring plan support before checking options [#39384]

### Fixed
- Use React properties rather than pass-throughs (e.g. `className` rather than `class`). [#39414]

## [0.45.4] - 2024-09-16
### Changed
- Updated package dependencies. [#39332]

### Fixed
- Move trailing spaces out of i18n messages. [#39305]

## [0.45.3] - 2024-09-10
### Changed
- Updated package dependencies. [#39302]

## [0.45.2] - 2024-09-09
### Changed
- Updated package dependencies. [#39278]

## [0.45.1] - 2024-09-05
### Changed
- Updated package dependencies. [#39176]

## [0.45.0] - 2024-09-02
### Added
- Search: allow customizing highlighted fields [#39053]

### Changed
- Admin menu: change order of Jetpack sub-menu items [#39095]
- Updated package dependencies. [#39111]

### Fixed
- Search: Use the user's locale when formatting request limits. [#38946]

## [0.44.17] - 2024-08-26
### Changed
- Updated package dependencies. [#39004]

## [0.44.16] - 2024-08-21
### Changed
- Internal updates.

## [0.44.15] - 2024-08-19
### Changed
- Update dependencies. [#38662] [#38861]

### Fixed
- Fix incorrect next-version tokens in php `@since` and/or `@deprecated` docs. [#38869]

## [0.44.14] - 2024-08-05
### Changed
- React compatibility: Changing ReactDOM.render usage to be via ReactDOM.createRoot. [#38649]

## [0.44.13] - 2024-07-22
### Changed
- Update dependencies. [#38402]

## [0.44.12] - 2024-07-08
### Changed
- Updated package dependencies. [#38132] [#38133]

## [0.44.11] - 2024-06-24
### Changed
- Update dependencies. [#37979]

## [0.44.10] - 2024-06-17
### Changed
- Updated package dependencies. [#37796] [#37860]

## [0.44.9] - 2024-06-10
### Changed
- Change codebase to use clsx instead of classnames. [#37708]
- Updated package dependencies. [#37669]

## [0.44.8] - 2024-05-27
### Changed
- Update dependencies.

## [0.44.7] - 2024-05-20
### Changed
- Updated package dependencies. [#37379] [#37380] [#37382]

## [0.44.6] - 2024-05-13
### Changed
- Update dependencies. [#37280]

## [0.44.5] - 2024-05-06
### Added
- Add missing package dependencies. [#37141]

### Changed
- Updated package dependencies. [#37147]

### Deprecated
- Deprecate `jetpack_search` property on `Search_Widget`. It has never been set to a non-null value since the package was created. [#37201]

## [0.44.4] - 2024-04-29
### Fixed
- Fix connection flow for new sites. [#37085]

## [0.44.3] - 2024-04-25
### Changed
- Internal updates.

## [0.44.2] - 2024-04-22
### Changed
- Internal updates.

## [0.44.1] - 2024-04-15
### Changed
- Update dependencies. [#36848]

## [0.44.0] - 2024-04-08
### Changed
- Updated package dependencies. [#36760]
- Update to the most recent version of Color Studio, 2.6.0. [#36751]

### Removed
- Removed add Search license link for simple sites due to My Jetpack inavailability. [#36667]

## [0.43.8] - 2024-03-27
### Changed
- Updated package dependencies. [#36585]

## [0.43.7] - 2024-03-25
### Changed
- Internal updates.

## [0.43.6] - 2024-03-18
### Changed
- Internal updates.

## [0.43.5] - 2024-03-12
### Changed
- Updated package dependencies. [#36325]
- Update to the most recent version of the @automattic/calypso-color-schemes package. [#36187] [#36227]

## [0.43.4] - 2024-03-04
### Changed
- Update dependencies. [#36113]
- Updated package dependencies.

## [0.43.3] - 2024-02-27
### Changed
- Update dependencies.

## [0.43.2] - 2024-02-19
### Changed
- Internal updates.

## [0.43.1] - 2024-02-13
### Changed
- Updated package dependencies. [#35608]

## [0.43.0] - 2024-02-05
### Changed
- Updated package dependencies. [#35384] [#35385]
- Use blog ID instead of site slug in checkout links. [#35000]

## [0.42.1] - 2024-01-29
### Changed
- Update dependencies.

## [0.42.0] - 2024-01-25
### Added
- Add price and rating to default sort options. [#35167]

## [0.41.1] - 2024-01-22
### Changed
- Update dependencies. [#35117]

## [0.41.0] - 2024-01-04
### Added
- Search: Add a filter to prevent tracking cookie reset. [#34803]

### Changed
- Updated package dependencies. [#34815]

## [0.40.4] - 2023-12-20
### Changed
- Updated package dependencies. [#34694]

## [0.40.3] - 2023-12-11
### Changed
- Updated package dependencies. [#34416]

## [0.40.2] - 2023-12-03
### Changed
- Updated package dependencies. [#34411] [#34427]

### Fixed
- Instant Search: Fixed the title layout for product layout. [#34263]

## [0.40.1] - 2023-11-24
### Changed
- Replaced usage of strpos() with str_contains(). [#34137]
- Replaced usage of substr() with str_starts_with() and str_ends_with(). [#34207]

## [0.40.0] - 2023-11-20
### Changed
- Replaced usage of strpos() with str_starts_with(). [#34135]
- Updated required PHP version to >= 7.0. [#34192]

## [0.39.7] - 2023-11-14
### Changed
- Updated package dependencies. [#34093]

## [0.39.6] - 2023-11-13
### Fixed
- Switched to classic search for iOS 15 or lower. [#33929]

## [0.39.5] - 2023-11-03

## [0.39.4] - 2023-10-30
### Changed
- Instant Search: rely on browsers' native lazy loading functionality when we want to lazy load images. [#33817]

## [0.39.3] - 2023-10-23
### Changed
- Updated package dependencies. [#33646] [#33687]

## [0.39.2] - 2023-10-16
### Added
- Added HEIC (`*.heic`) to list of images types allowed to be passed through Photon during instant search. [#33494]

### Changed
- Updated package dependencies. [#33429, #33569]

### Fixed
- Search: Fixed excluded types option is not available under certain circumstances. [#33548]

## [0.39.1] - 2023-10-10
### Changed
- Updated package dependencies. [#33428]

## [0.39.0] - 2023-10-03
### Added
- Add a setting for Jetpack AI Search [#33432]

## [0.38.8] - 2023-09-19
### Changed
- Updated Jetpack submenu sort order so individual features are alpha-sorted. [#32958]
- Updated package dependencies. [#33001]

## [0.38.7] - 2023-09-11
### Changed
- General: remove WP 6.1 backwards compatibility checks [#32772]

## [0.38.6] - 2023-09-04
### Changed
- Updated package dependencies. [#32803] [#32804]

## [0.38.5] - 2023-08-28
### Changed
- Updated package dependencies. [#32605]

## [0.38.4] - 2023-08-21
### Changed
- Use the new method to render Connection initial state. [#32499]

## [0.38.3] - 2023-08-09
### Changed
- Updated package dependencies. [#32166]

## [0.38.2] - 2023-07-25
### Changed
- Updated package dependencies. [#31923] [#32040]
- Update props passed to JetpackFooter [#31627]

## [0.38.1] - 2023-07-17
### Changed
- Updated package dependencies. [#31785]

## [0.38.0] - 2023-07-10
### Removed
- Disable Customizer integration for Instant Search if the site is using a block-based theme [#31731]

## [0.37.4] - 2023-07-05
### Changed
- Updated package dependencies. [#31659]

## [0.37.3] - 2023-06-26
### Changed
- Updated package dependencies. [#31468]

## [0.37.2] - 2023-06-06
### Changed
- Updated package dependencies. [#31129]

## [0.37.1] - 2023-05-22
### Changed
- PHP Compatibility: fix dynamic property deprecation notices [#30786]

## [0.37.0] - 2023-05-15
### Added
- Jetpack Search: add "Open overlay from filter links" option, which allows users to enable/disable the opening of the search overlay when filtering from a separate widget outside of the Jetpack Search Sidebar [#30455]

### Changed
- PHP 8.1 compatibility updates [#30564]

## [0.36.3] - 2023-05-02
### Changed
- Updated package dependencies.

## [0.36.2] - 2023-05-01
### Changed
- Internal updates.

## [0.36.1] - 2023-04-25

- Minor internal updates.

## [0.36.0] - 2023-04-17
### Added
- Search: Restore Tracks to Instant Search [#29979]

### Changed
- Updated package dependencies. [#30019]

## [0.35.0] - 2023-04-10
### Added
- Add Jetpack Autoloader package suggestion. [#29988]
- Implemented a "tabbed" variation for static filters. This adds tabs on top of the results for each filter group. [#29811]

## [0.34.4] - 2023-04-04
### Changed
- Updated package dependencies. [#29854, #29857]

## [0.34.3] - 2023-04-03
### Changed
- Internal updates.

## [0.34.2] - 2023-03-28
### Changed
- Minor internal updates.

## [0.34.1] - 2023-03-27
### Added
- (Backup, Boost, Search, Social) Add links on upgrade pages to activate a license key, if you already have one. [#29443]

### Changed
- Updated package dependencies. [#29632]

## [0.34.0] - 2023-03-20
### Changed
- Updated package dependencies. [#29471]

### Removed
- Remove Tracks from Instant Search [#29490]

## [0.33.3] - 2023-03-13
### Fixed
- Search Dashboard: fix wrong return URL when site already has a valid subscription [#29409]

## [0.33.2] - 2023-03-08
### Changed
- Updated package dependencies. [#29216]

### Fixed
- Fix bad check against isMultiSite resulting in extended search format not showing expected additional post details. [#29179]

## [0.33.1] - 2023-02-28
### Added
- Search: Add JITM container [#29106]

### Changed
- Updated package dependencies.

### Fixed
- Fix CSS for products in search results [#29110]

## [0.33.0] - 2023-02-20
### Added
- Adds a "show post date" selector to Search customberg, allows non-multisite sites to show the post date in the "expanded" search result format. [#28918]

### Fixed
- Fixed unit tests without internet [#28985]
- Separated authors by comments if there are multiple authors in a search result [#28975]

## [0.32.0] - 2023-02-15
### Added
- Search: Adds assigned post categories as classnames to search results [#28816]

### Changed
- Update to React 18. [#28710]

## [0.31.7] - 2023-02-08
### Changed
- Updated package dependencies. [#28682]

## [0.31.6] - 2023-01-30
### Changed
- Increased Jetpack Search filters caching from one hour to four hours [#28632]

## [0.31.5] - 2023-01-26
### Changed
- Minor internal updates.

## [0.31.4] - 2023-01-23
### Changed
- Start using utilities from Status package to detect whether a site is private or "coming-soon" (unlaunched). [#28328]

### Fixed
- Clean up JavaScript eslint issues. [#28441]

## [0.31.3] - 2023-01-11
### Changed
- Updated package dependencies.

## [0.31.2] - 2022-12-19
### Changed
- Updated package dependencies. [#27887, #27916, #27962]

### Fixed
- Declare field `REST_Controller->plan`. [#27949]
- Improve PHP 8.2 compatibility. [#27968]

## [0.31.1] - 2022-12-06
### Changed
- Updated package dependencies. [#27340, #27688, #27696, #27697]

## [0.31.0] - 2022-11-28
### Added
- Add an optional global flag that prevents instant search from modifying the url as the search query is being written or modified. [#27264]
- Add prompt for Jetpack Search Free plan upgrade for users who exceed limits. [#27462]
- Search: Add checkmark icon for resolved topics [#27586]

### Changed
- Suggest free Jetpack Search plan instead of the paid one to classic search users [#27372]
- Updated package dependencies. [#26069]

## [0.30.2] - 2022-11-10
### Changed
- Updated package dependencies. [#27319]

### Fixed
- Jetpack Search: Fixed link to language support documentation [#27287]

## [0.30.1] - 2022-11-07
### Changed
- Updated package dependencies. [#27278]

## [0.30.0] - 2022-11-01
### Added
- Search: add blog ID filtering and `blogIdFilteringLabels` option [#27120]

### Changed
- Updated package dependencies. [#27089]

## [0.29.2] - 2022-10-26
### Fixed
- Search: Fix typo in CTA [#27044]
- Search: hide meters etc for Classic Search [#27073]

## [0.29.1] - 2022-10-25
### Added
- Search: add purchase tracking [#26981]

### Changed
- Search: now support 38 languages [#27025]
- Tweak colophon link to Search upgrade page [#26952]
- Updated package dependencies. [#26705]

### Fixed
- Hide Jetpack logo toggle, enforce display for free plans [#26951]
- Search: Hide post-purchase tooltips for free plan activation [#26953]

## [0.29.0] - 2022-10-19
### Added
- Search: enable new pricing if pricing_version is set to 202208 from API [#26900]

### Changed
- Updated package dependencies. [#26808]
- Use API values for paid allowance limits shown in the new pricing table [#26895]

## [0.28.0] - 2022-10-17
### Changed
- Check free plan by product_slug and disable Module Control only on free plan. [#26849]
- Fetch checkoutProductUrl for upgrade flow redirection. [#26848]
- Introduce GET param just_upgraded and localStorage upgrade_tooltip_finished to determine the tooltips showing. [#26828]
- Refactor upgrade tooltips. [#26851]
- Search: always add Search Dashboard page even when submenu is hidden [#26807]
- Search Dashboard: Add missing CTAs and associated logic. [#26852]
- Search Dashboard: Add siteTitle to plugin/package data. [#26816]
- Search Dashboard: Better handling of "Unlimited" requests. [#26813]
- Search Dashboard: Disable adaptive colors for Unlimited requests state. [#26850]
- Search Dashboard: Fix responsive layouts for usage meters. [#26815]
- Search Dashboard: Remove code duplication for support link. [#26811]
- Search Dashboard: Update Plan Usage section to remove info icons. [#26812]
- Updated package dependencies. [#26851]
- Use adaptive coloring for donut meters in search dashboard [#26847]

## [0.27.0] - 2022-10-13
### Added
- Add connection error notice to the Search plugin. [#26778]
- Introduce shadowed IconTooltips to tooltips for highlighting upgraded usage limits. [#26790]

### Changed
- Add upgrade button link with applying upgrade actions. [#26737]
- Search Dashboard: Update Plan Usage section to more closely match design. [#26783]
- Updated package dependencies. [#26790]

### Fixed
- Search: wpcom sites should not be considered as connected [#26835]

## [0.26.0] - 2022-10-11
### Added
- Search Dashboard: Add support for conditional CUTs. [#26656]

### Changed
- Apply ContextualUpgradeTrigger with checkout CTA [#26633]
- Apply tier and latest month usage to plan summary [#26695]
- Apply upgrade trigger displaying conditions and messages from API data [#26712]
- Stop controls when usage over plan limit months. [#26732]
- Updated package dependencies. [#26640]

### Fixed
- Fixed search dashboard for simple sites. [#26713]
- Search Dashboard: Add support link for plan limits. [#26694]
- Search Dashboard: Refactoring of new UI components. [#26723]
- Search Dashboard: Rename variables to avoid jargon. [#26691]

## [0.25.0] - 2022-10-05
### Added
- Added string translations used for the new pricing table [#26595]
- Components: Added UsageMeter along with DonutMeterContainer JS component. [#26344]
- Search: add post type breakdown endpoint [#26463]

### Changed
- Apply JetpackSearchLogo and replace footer link to upsell page [#26481]
- Search: add connection support for new pricing page [#26573]
- Search Dashboard: Added first run and usage section components. [#26639]
- Updated package dependencies. [#26457]
- Use library method for number formatting. [#26636]

### Fixed
- Search: fix redirection after purchase [#26598]

## [0.24.0] - 2022-10-03
### Changed
- Fix styles of Control components on page side to avoid deprecating component styles affecting. [#26567]

## [0.23.0] - 2022-09-27
### Added
- Added stories for the NoticeBox component [#26367]
- Search: added free_tier and new_pricing_202208 to gate new pricing features [#26338]

### Changed
- Introduce PricingTable to update Upsell page [#26408]
- Move JetpackColophon to bottom of SearchResults [#26320]
- Updated mentions of "Search" with "Jetpack Search" as part of rebranding project [#26410]
- Updated package dependencies.

### Fixed
- Fix error message styling in Instant Search overlay. [#26339]

## [0.22.2] - 2022-09-20
### Changed
- Updated package dependencies.

### Fixed
- Fixes the issue where search results are not loaded in customizer [#26212]

## [0.22.1] - 2022-09-13
### Changed
- Updated package dependencies. [#26176]

## [0.22.0] - 2022-09-08
### Added
- Search: added support to search through multiple sites [#26046]

### Changed
- Updated package dependencies.

### Fixed
- Instant Search: Update CSS styles to removes uses of "!important" where possible. [#25825]
- Search: Allow non-owner admins to see search dashboard [#26100]
- Search: fixed Automattic link in footer when Jetpack plugin does not exist [#26045]

## [0.21.1] - 2022-08-30
### Added
- Instant Search: add focus border to search input field [#25304]

### Changed
- Updated package dependencies. [#25694]

### Fixed
- Keep widget preview with settings [#25778]

## [0.21.0] - 2022-08-25
### Changed
- Search: revert "Search should not require user connection" [#25802]
- Updated package dependencies. [#25814]

## [0.20.0] - 2022-08-23
### Added
- Add author filtering support [#25409]

### Changed
- Updated package dependencies. [#25338, #25339, #25377, #25628, #25762, #25769]

### Fixed
- Instant Search: Add focus styles for easier keyboard navigation. (a11y) [#25671]
- Instant Search: Remove redundant links from search results. (a11y) [#25699]

## [0.19.0] - 2022-08-16
### Added
- Instant Search: always use submit overlay trigger if user prefers reduced motion. [#25413]
- Instant Search: only show animation to users who have not chosen reduced motion. [#25630]
- Instant Search: user friendly error messaging. [#25433]

### Fixed
- Instant Search: fix button styling in Twenty Twenty One theme. [#25631]
- Instant Search: fix the display order on mobile to match the tab order. [#25415]
- Instant Search: use classname rather than ID for styling sort select. [#25632]

## [0.18.0] - 2022-08-09
### Added
- Search: added proper error messages for search module control [#24476]

### Changed
- Instant Search: Updates dark mode active link color for increased contrast [#25343]
- Search: changed to only require site level connection [#24477]
- Updated package dependencies. [#24477, #25265]

### Removed
- Search: remove 'results' overlay trigger [#25393]

### Fixed
- Dashboard: updated Instant Search description to match changes in default overlay trigger [#25303]
- Instant Search: Constrain tab loop to overlay when visible. [#25288]
- Instant Search: Make "Clear filters" button accessible. [#25342]

## [0.17.1] - 2022-08-03
### Added
- Instant Search: Adds descriptions to post type icons for accessibility purposes [#25323]
- Record Meter: add info link to docs [#25002]

### Changed
- Updated package dependencies. [#25300, #25315]

### Fixed
- Instant Search: Improve accessibility of seach options controls.
- Search: ensure overlay trigger is consistent for new installs [#25093]

## [0.17.0] - 2022-07-29
### Added
- Record Meter: make feature available to all users
- Search: re-add 'Media' to 'Excluded Post Types'

## [0.16.2] - 2022-07-26
### Added
- Dashboard: added support WPCOM simple sites [#25094]

### Changed
- Instant search: updates overlay focus elements for design consistency [#25260]
- Updated package dependencies. [#25144] [#25147] [#25158]

### Fixed
- Instant Search: Fix keyboard handling of sort options. [#25163]
- Instant Search: prevent hidden submit button appearing on focus [#25136]
- Search Dashboard: Fixed layout issues when Hello Dolly plugin is active. [#25139]

## [0.16.1] - 2022-07-19
### Changed
- Updated package dependencies. [#25086]

### Fixed
- Customberg: re-add collapsing wp-admin sidebar to prevent menu overlap issue [#25060]
- Fixed the currency code missing issue for the upsell page [#25068]

## [0.16.0] - 2022-07-12
### Added
- Hide unsupported taxonomies from widget settings [#24823]

### Changed
- Updated package dependencies. [#25055]

### Fixed
- Fix irrelevant widgets in overlay sidebar [#24824]
- Hide 'Media' from 'Excluded Post Types' because we don't index them [#24822]
- Record Meter: rely less on last_indexed_date from API [#24967]
- Use consistent number formatting in Record Meter [#25003]

## [0.15.4] - 2022-07-06
### Added
- Record Meter: adds labels to custom post type breakdown [#24876]

### Changed
- Updated package dependencies. [#24923]

### Removed
- Record Meter: Remove dismissable functionality and design from notice boxes [#24922]

### Fixed
- Reset letter spacing for header tags [#24954]
- Restores support for multiple post types in the Jetpack Search Widget. [#24868]

## [0.15.3] - 2022-06-28
### Changed
- Record meter: format the numbers used in notice. [#24810]
- Record Meter: updated notice box content when site is not indexed [#24785]
- Search: use centralized search pricing API [#24795]
- Updated package dependencies. [#24826]

### Fixed
- Added My Jetpack package as dependency [#24826]

## [0.15.2] - 2022-06-21
### Changed
- Record Meter: Separated component styles [#24732]
- Renaming master to trunk. [#24661]

## [0.15.1] - 2022-06-14
### Changed
- Search record meter: pass sorted records to RecordMeterBar component [#24731]
- Updated package dependencies. [#24529]

## [0.15.0] - 2022-06-08
### Changed
- Record Meter: switches from using chartJS to the Jetpack RecordMeterBar component [#24322]
- Reorder JS imports for `import/order` eslint rule. [#24601]
- Search record meter: changed the notice box to include a header text [#24346]
- Search widget: use 'Search (Jetpack)' as wdiget name and remove `jetpack_widget_name` [#24577]
- Updated package dependencies. [#24510]

### Removed
- Search: don't open modal if only sort parameter is set [#24576]
- Search: Removed unused chart.js library [#24658]

### Fixed
- Search: avoid query on component mount when the overlay might not be visible [#24609]
- Search: fix gridicon color in dark mode on Customberg [#24668]

## [0.14.2] - 2022-05-30
### Changed
- Updated package dependencies
- Updated package dependencies.
- Use the Checkout workflow to establish the connection and make the purchase

### Fixed
- Avoid filter from being added multiple times

## [0.14.1] - 2022-05-24
### Added
- Allow plugins to filter the list of available modules. Only activate and consider active modules that are available [#24454]

### Changed
- Search: Use Modules methods for activating and deactivating the Search module. [#24385]
- Updated package dependencies. [#24449]

## [0.14.0] - 2022-05-19
### Removed
- Search: Disable auto-collapsing the wp-admin sidebar within Customberg [#24399]

## [0.13.4] - 2022-05-18
### Changed
- Adjust translatable string [#24357]
- Record Meter: switch noticebox persistence storage from localStorage to sessionStorage [#24348]
- Record Meter design updates [#24225]
- Search package: search dashboard refactoring [#24266]
- Updated package dependencies. [#23795] [#24153] [#24306] [#24372]

## [0.13.3] - 2022-05-10
### Added
- Add missing JS dep on `core-js`. [#24288]

### Changed
- Search: refactored Settings to expose the settings array for sync [#24167]
- Updated package dependencies. [#24189] [#24204] [#24276] [#24296] [#24301] [#24302]

### Fixed
- Search: Fix left padding for upsell page [#24285]
- Search: handle tiers without a record limit in Record Meter [#24264]

## [0.13.2] - 2022-05-04
### Added
- Add missing JavaScript dependencies. [#24096]

### Changed
- Remove use of `pnpx` in preparation for pnpm 7.0. [#24210]
- Updated package dependencies. [#24095] [#24198] [#24228] [#24230]

### Deprecated
- Moved the options class into Connection. [#24095]

### Fixed
- Adapt Record Meter to change in API response format [#24107]
- Search: Bundle vendor assets within the main chunk [#24068]
- Search: Fix search for private WoA sites [#24099]
- Search: reset border-radius for search buttons [#24100]

## [0.13.1] - 2022-04-26
### Added
- Search: added upsell page

### Changed
- Updated package dependencies.
- Update package.json metadata.

## [0.13.0] - 2022-04-19
### Added
- Search: add class to retrieve search product information
- Search: Add count estimation function
- Search: added API support for search product tier pricing

### Changed
- PHPCS: Fix `WordPress.Security.ValidatedSanitizedInput`
- Record meter: updates noticeboxes to be dismissable & styled
- Search Record Meter updates formatting
- Use new shared Gridicons component and shared Modules library

## [0.12.3] - 2022-04-12
### Added
- Added deprecated methods as a safety.

### Changed
- Updated package dependencies.

### Fixed
- Search: auto config no longer overrides option if it exists.

## [0.12.2] - 2022-04-06
### Added
- Adds API data to record meter chart.

### Changed
- Janitorial: Refactor classes into shared package.
- Updated package dependencies.

### Removed
- Removed tracking dependency.

### Fixed
- Search: allow Search submenu to be added only once

## [0.12.1] - 2022-03-31
### Fixed
- Search: fixed search submenu is shown because compatibility file is loaded too late.

## [0.12.0] - 2022-03-29
### Added
- Add selector for retrieving last indexed date
- Adds notice box component to record meter
- Search: Migrated tests from Jetpack plugin

### Changed
- Microperformance: Use === null instead of is_null
- Search: connection states
- Updated package dependencies

### Fixed
- Fixed lints found after fixing ESLint config
- Search: address feeback for #23477
- Search: move Jetpack plugin compatibility to the package

## [0.11.3] - 2022-03-24
### Added
- Search: adds a record count above the record meter chart.

### Fixed
- Deactivation: Do not attempt to redirect on a behind-the-scene deactivation.

## [0.11.2] - 2022-03-23
### Added
- adds basic structure for record meter with dummy data

### Changed
- Centralized all intializing logic
- Search dashboard: changed condition to always show dashboard submenu
- Updated package dependencies
- Use Migrated GlotPress locale classes from compat pkg.

### Fixed
- Search: fixed cli and package version reporting broken in #23435

## [0.11.1] - 2022-03-15
### Changed
- Fixed minor product defects
- Search: moved globals to a class for sake of autoloading correctly
- Search package: Updated Gridicon dependancy to use local version
- Updated package dependencies.

## [0.11.0] - 2022-03-08
### Changed
- Components: update attributes used within the Button component to match recent deprecations and changes.
- Move customizer integration into search package
- search: move record meter location on dashboard

### Fixed
- Ensure that WP CLI is present before extending the class.
- Ensure the Customizer classes are loaded.

## [0.10.0] - 2022-03-02
### Added
- Search: add chart.js package to dependencies
- Search: fetch search stats endpoint in wp-admin dashboard

### Changed
- Search: Renamed Customberg class file name
- Updated package dependencies.

### Fixed
- Fix various notices shown for Customberg
- Search package: i18n support for auto added search block label and button

## [0.9.1] - 2022-02-25
### Fixed
- Search: Fixed a regression that prevented modal from being spawned by link clicks

## [0.9.0] - 2022-02-22
### Added
- Bump package versions.
- Search: add stats endpoint to REST controller

### Changed
- Search package: refactor `auto_config_search` and run it from activation API

### Fixed
- Search package: fix auto config doesn't add search input for block themes

## [0.8.0] - 2022-02-16
### Added
- Add babel/runtime to dev dependencies
- Add tier maximum records for Record Meter
- Clicking outside overlay now closes overlay

### Changed
- Change `instance` function for improved compatibility
- Updated package dependencies.

### Fixed
- Form: avoid React warning.
- Improve display of colorpicker in Customberg
- Fixed undefined index features
- Should not exclude widget js in package distribution

## [0.7.0] - 2022-02-09
### Added
- Search Dashboard: add scaffolding for new record meter
- Search package: added auto config CLI

### Changed
- Search: move search widgets to package
- Updated package dependencies

## [0.6.0] - 2022-02-02
### Added
- Add `@use "sass:math"` in base styles scss for upcoming `@wordpress/block-editor` 8.1.0 requirement.
- Search package: added package version number and others

### Changed
- Build: remove unneeded files from production build.
- Instant Search: add image alt text from API
- Updated package dependencies.

## [0.5.4] - 2022-01-31
### Fixed
- Search: Fetch plan info as blog, not as user, to allow nonconnected admins to use dashboard

## [0.5.3] - 2022-01-27
### Fixed
- Search package: fixed compatibility issue with plan activation

## [0.5.2] - 2022-01-25
### Added
- Added a watch command for building assets
- Search E2E: added class names for some form components for easier E2E tests

### Changed
- Search: Improve accessibility via headings hierarchy and aria roles
- Updated package dependencies.

### Fixed
- Search widget: changed fetching search result to just before rendering jp search widget

## [0.5.1] - 2022-01-18
### Changed
- General: update required node version to v16.13.2

## [0.5.0] - 2022-01-11
### Added
- Search: Migrated Classic and Instant Search code from Jetpack plugin.
- Search API: activation and deactivation API.

### Changed
- Search: moved search dashboard to the package.
- Updated package dependencies.

## [0.4.0] - 2022-01-04
### Changed
- Do not escape widget title value
- Switch to pcov for code coverage.
- Updated package dependencies.
- Updated package textdomain from `jetpack` to `jetpack-search-pkg`.

### Fixed
- Add missing textdomains in JS code.

## [0.3.0] - 2021-12-14
### Changed
- Search package: add new methods and update timing for `Plan` class.
- Search package: refactored Module_Control class.

## [0.2.1] - 2021-12-07
### Changed
- Updated package dependencies.

## [0.2.0] - 2021-11-30
### Added
- Added essential scaffolding for package.
- Migrate additional helper classes to package
- Search: added new state store for search dashboard
- Search package: duplicated search dashboard dependencies to the package

### Changed
- Search: migrate/create necessary APIs for the frontend
- Search: removed other dependencies from copied code

## 0.1.0 - 2021-11-09
### Added
- Add a new Search package with Helper and Options classes.
- Search: Migrate helper classes from Jetpack plugin

### Changed
- Set `convertDeprecationsToExceptions` true in PHPUnit config.
- Updated package dependencies.
- Update PHPUnit configs to include just what needs coverage rather than include everything then try to exclude stuff that doesn't.

[8.4.3]: https://github.com/Automattic/jetpack-search/compare/v8.4.2...v8.4.3
[8.4.2]: https://github.com/Automattic/jetpack-search/compare/v8.4.1...v8.4.2
[8.4.1]: https://github.com/Automattic/jetpack-search/compare/v8.4.0...v8.4.1
[8.4.0]: https://github.com/Automattic/jetpack-search/compare/v8.3.5...v8.4.0
[8.3.5]: https://github.com/Automattic/jetpack-search/compare/v8.3.4...v8.3.5
[8.3.4]: https://github.com/Automattic/jetpack-search/compare/v8.3.3...v8.3.4
[8.3.3]: https://github.com/Automattic/jetpack-search/compare/v8.3.2...v8.3.3
[8.3.2]: https://github.com/Automattic/jetpack-search/compare/v8.3.1...v8.3.2
[8.3.1]: https://github.com/Automattic/jetpack-search/compare/v8.3.0...v8.3.1
[8.3.0]: https://github.com/Automattic/jetpack-search/compare/v8.2.1...v8.3.0
[8.2.1]: https://github.com/Automattic/jetpack-search/compare/v8.2.0...v8.2.1
[8.2.0]: https://github.com/Automattic/jetpack-search/compare/v8.1.3...v8.2.0
[8.1.3]: https://github.com/Automattic/jetpack-search/compare/v8.1.2...v8.1.3
[8.1.2]: https://github.com/Automattic/jetpack-search/compare/v8.1.1...v8.1.2
[8.1.1]: https://github.com/Automattic/jetpack-search/compare/v8.1.0...v8.1.1
[8.1.0]: https://github.com/Automattic/jetpack-search/compare/v8.0.0...v8.1.0
[8.0.0]: https://github.com/Automattic/jetpack-search/compare/v7.4.1...v8.0.0
[7.4.1]: https://github.com/Automattic/jetpack-search/compare/v7.4.0...v7.4.1
[7.4.0]: https://github.com/Automattic/jetpack-search/compare/v7.3.3...v7.4.0
[7.3.3]: https://github.com/Automattic/jetpack-search/compare/v7.3.2...v7.3.3
[7.3.2]: https://github.com/Automattic/jetpack-search/compare/v7.3.1...v7.3.2
[7.3.1]: https://github.com/Automattic/jetpack-search/compare/v7.3.0...v7.3.1
[7.3.0]: https://github.com/Automattic/jetpack-search/compare/v7.2.8...v7.3.0
[7.2.8]: https://github.com/Automattic/jetpack-search/compare/v7.2.7...v7.2.8
[7.2.7]: https://github.com/Automattic/jetpack-search/compare/v7.2.6...v7.2.7
[7.2.6]: https://github.com/Automattic/jetpack-search/compare/v7.2.5...v7.2.6
[7.2.5]: https://github.com/Automattic/jetpack-search/compare/v7.2.4...v7.2.5
[7.2.4]: https://github.com/Automattic/jetpack-search/compare/v7.2.3...v7.2.4
[7.2.3]: https://github.com/Automattic/jetpack-search/compare/v7.2.2...v7.2.3
[7.2.2]: https://github.com/Automattic/jetpack-search/compare/v7.2.1...v7.2.2
[7.2.1]: https://github.com/Automattic/jetpack-search/compare/v7.2.0...v7.2.1
[7.2.0]: https://github.com/Automattic/jetpack-search/compare/v7.1.0...v7.2.0
[7.1.0]: https://github.com/Automattic/jetpack-search/compare/v7.0.0...v7.1.0
[7.0.0]: https://github.com/Automattic/jetpack-search/compare/v0.60.0...v7.0.0
[0.60.0]: https://github.com/Automattic/jetpack-search/compare/v0.59.0...v0.60.0
[0.59.0]: https://github.com/Automattic/jetpack-search/compare/v0.58.0...v0.59.0
[0.58.0]: https://github.com/Automattic/jetpack-search/compare/v0.57.0...v0.58.0
[0.57.0]: https://github.com/Automattic/jetpack-search/compare/v0.56.10...v0.57.0
[0.56.10]: https://github.com/Automattic/jetpack-search/compare/v0.56.9...v0.56.10
[0.56.9]: https://github.com/Automattic/jetpack-search/compare/v0.56.8...v0.56.9
[0.56.8]: https://github.com/Automattic/jetpack-search/compare/v0.56.7...v0.56.8
[0.56.7]: https://github.com/Automattic/jetpack-search/compare/v0.56.6...v0.56.7
[0.56.6]: https://github.com/Automattic/jetpack-search/compare/v0.56.5...v0.56.6
[0.56.5]: https://github.com/Automattic/jetpack-search/compare/v0.56.4...v0.56.5
[0.56.4]: https://github.com/Automattic/jetpack-search/compare/v0.56.3...v0.56.4
[0.56.3]: https://github.com/Automattic/jetpack-search/compare/v0.56.2...v0.56.3
[0.56.2]: https://github.com/Automattic/jetpack-search/compare/v0.56.1...v0.56.2
[0.56.1]: https://github.com/Automattic/jetpack-search/compare/v0.56.0...v0.56.1
[0.56.0]: https://github.com/Automattic/jetpack-search/compare/v0.55.4...v0.56.0
[0.55.4]: https://github.com/Automattic/jetpack-search/compare/v0.55.3...v0.55.4
[0.55.3]: https://github.com/Automattic/jetpack-search/compare/v0.55.2...v0.55.3
[0.55.2]: https://github.com/Automattic/jetpack-search/compare/v0.55.1...v0.55.2
[0.55.1]: https://github.com/Automattic/jetpack-search/compare/v0.55.0...v0.55.1
[0.55.0]: https://github.com/Automattic/jetpack-search/compare/v0.54.10...v0.55.0
[0.54.10]: https://github.com/Automattic/jetpack-search/compare/v0.54.9...v0.54.10
[0.54.9]: https://github.com/Automattic/jetpack-search/compare/v0.54.8...v0.54.9
[0.54.8]: https://github.com/Automattic/jetpack-search/compare/v0.54.7...v0.54.8
[0.54.7]: https://github.com/Automattic/jetpack-search/compare/v0.54.6...v0.54.7
[0.54.6]: https://github.com/Automattic/jetpack-search/compare/v0.54.5...v0.54.6
[0.54.5]: https://github.com/Automattic/jetpack-search/compare/v0.54.4...v0.54.5
[0.54.4]: https://github.com/Automattic/jetpack-search/compare/v0.54.3...v0.54.4
[0.54.3]: https://github.com/Automattic/jetpack-search/compare/v0.54.2...v0.54.3
[0.54.2]: https://github.com/Automattic/jetpack-search/compare/v0.54.1...v0.54.2
[0.54.1]: https://github.com/Automattic/jetpack-search/compare/v0.54.0...v0.54.1
[0.54.0]: https://github.com/Automattic/jetpack-search/compare/v0.53.0...v0.54.0
[0.53.0]: https://github.com/Automattic/jetpack-search/compare/v0.52.24...v0.53.0
[0.52.24]: https://github.com/Automattic/jetpack-search/compare/v0.52.23...v0.52.24
[0.52.23]: https://github.com/Automattic/jetpack-search/compare/v0.52.22...v0.52.23
[0.52.22]: https://github.com/Automattic/jetpack-search/compare/v0.52.21...v0.52.22
[0.52.21]: https://github.com/Automattic/jetpack-search/compare/v0.52.20...v0.52.21
[0.52.20]: https://github.com/Automattic/jetpack-search/compare/v0.52.19...v0.52.20
[0.52.19]: https://github.com/Automattic/jetpack-search/compare/v0.52.18...v0.52.19
[0.52.18]: https://github.com/Automattic/jetpack-search/compare/v0.52.17...v0.52.18
[0.52.17]: https://github.com/Automattic/jetpack-search/compare/v0.52.16...v0.52.17
[0.52.16]: https://github.com/Automattic/jetpack-search/compare/v0.52.15...v0.52.16
[0.52.15]: https://github.com/Automattic/jetpack-search/compare/v0.52.14...v0.52.15
[0.52.14]: https://github.com/Automattic/jetpack-search/compare/v0.52.13...v0.52.14
[0.52.13]: https://github.com/Automattic/jetpack-search/compare/v0.52.12...v0.52.13
[0.52.12]: https://github.com/Automattic/jetpack-search/compare/v0.52.11...v0.52.12
[0.52.11]: https://github.com/Automattic/jetpack-search/compare/v0.52.10...v0.52.11
[0.52.10]: https://github.com/Automattic/jetpack-search/compare/v0.52.9...v0.52.10
[0.52.9]: https://github.com/Automattic/jetpack-search/compare/v0.52.8...v0.52.9
[0.52.8]: https://github.com/Automattic/jetpack-search/compare/v0.52.7...v0.52.8
[0.52.7]: https://github.com/Automattic/jetpack-search/compare/v0.52.6...v0.52.7
[0.52.6]: https://github.com/Automattic/jetpack-search/compare/v0.52.5...v0.52.6
[0.52.5]: https://github.com/Automattic/jetpack-search/compare/v0.52.4...v0.52.5
[0.52.4]: https://github.com/Automattic/jetpack-search/compare/v0.52.3...v0.52.4
[0.52.3]: https://github.com/Automattic/jetpack-search/compare/v0.52.2...v0.52.3
[0.52.2]: https://github.com/Automattic/jetpack-search/compare/v0.52.1...v0.52.2
[0.52.1]: https://github.com/Automattic/jetpack-search/compare/v0.52.0...v0.52.1
[0.52.0]: https://github.com/Automattic/jetpack-search/compare/v0.51.0...v0.52.0
[0.51.0]: https://github.com/Automattic/jetpack-search/compare/v0.50.2...v0.51.0
[0.50.2]: https://github.com/Automattic/jetpack-search/compare/v0.50.1...v0.50.2
[0.50.1]: https://github.com/Automattic/jetpack-search/compare/v0.50.0...v0.50.1
[0.50.0]: https://github.com/Automattic/jetpack-search/compare/v0.49.0...v0.50.0
[0.49.0]: https://github.com/Automattic/jetpack-search/compare/v0.48.0...v0.49.0
[0.48.0]: https://github.com/Automattic/jetpack-search/compare/v0.47.24...v0.48.0
[0.47.24]: https://github.com/Automattic/jetpack-search/compare/v0.47.23...v0.47.24
[0.47.23]: https://github.com/Automattic/jetpack-search/compare/v0.47.22...v0.47.23
[0.47.22]: https://github.com/Automattic/jetpack-search/compare/v0.47.21...v0.47.22
[0.47.21]: https://github.com/Automattic/jetpack-search/compare/v0.47.20...v0.47.21
[0.47.20]: https://github.com/Automattic/jetpack-search/compare/v0.47.19...v0.47.20
[0.47.19]: https://github.com/Automattic/jetpack-search/compare/v0.47.18...v0.47.19
[0.47.18]: https://github.com/Automattic/jetpack-search/compare/v0.47.17...v0.47.18
[0.47.17]: https://github.com/Automattic/jetpack-search/compare/v0.47.16...v0.47.17
[0.47.16]: https://github.com/Automattic/jetpack-search/compare/v0.47.15...v0.47.16
[0.47.15]: https://github.com/Automattic/jetpack-search/compare/v0.47.14...v0.47.15
[0.47.14]: https://github.com/Automattic/jetpack-search/compare/v0.47.13...v0.47.14
[0.47.13]: https://github.com/Automattic/jetpack-search/compare/v0.47.12...v0.47.13
[0.47.12]: https://github.com/Automattic/jetpack-search/compare/v0.47.11...v0.47.12
[0.47.11]: https://github.com/Automattic/jetpack-search/compare/v0.47.10...v0.47.11
[0.47.10]: https://github.com/Automattic/jetpack-search/compare/v0.47.9...v0.47.10
[0.47.9]: https://github.com/Automattic/jetpack-search/compare/v0.47.8...v0.47.9
[0.47.8]: https://github.com/Automattic/jetpack-search/compare/v0.47.7...v0.47.8
[0.47.7]: https://github.com/Automattic/jetpack-search/compare/v0.47.6...v0.47.7
[0.47.6]: https://github.com/Automattic/jetpack-search/compare/v0.47.5...v0.47.6
[0.47.5]: https://github.com/Automattic/jetpack-search/compare/v0.47.4...v0.47.5
[0.47.4]: https://github.com/Automattic/jetpack-search/compare/v0.47.3...v0.47.4
[0.47.3]: https://github.com/Automattic/jetpack-search/compare/v0.47.2...v0.47.3
[0.47.2]: https://github.com/Automattic/jetpack-search/compare/v0.47.1...v0.47.2
[0.47.1]: https://github.com/Automattic/jetpack-search/compare/v0.47.0...v0.47.1
[0.47.0]: https://github.com/Automattic/jetpack-search/compare/v0.46.0...v0.47.0
[0.46.0]: https://github.com/Automattic/jetpack-search/compare/v0.45.12...v0.46.0
[0.45.12]: https://github.com/Automattic/jetpack-search/compare/v0.45.11...v0.45.12
[0.45.11]: https://github.com/Automattic/jetpack-search/compare/v0.45.10...v0.45.11
[0.45.10]: https://github.com/Automattic/jetpack-search/compare/v0.45.9...v0.45.10
[0.45.9]: https://github.com/Automattic/jetpack-search/compare/v0.45.8...v0.45.9
[0.45.8]: https://github.com/Automattic/jetpack-search/compare/v0.45.7...v0.45.8
[0.45.7]: https://github.com/Automattic/jetpack-search/compare/v0.45.6...v0.45.7
[0.45.6]: https://github.com/Automattic/jetpack-search/compare/v0.45.5...v0.45.6
[0.45.5]: https://github.com/Automattic/jetpack-search/compare/v0.45.4...v0.45.5
[0.45.4]: https://github.com/Automattic/jetpack-search/compare/v0.45.3...v0.45.4
[0.45.3]: https://github.com/Automattic/jetpack-search/compare/v0.45.2...v0.45.3
[0.45.2]: https://github.com/Automattic/jetpack-search/compare/v0.45.1...v0.45.2
[0.45.1]: https://github.com/Automattic/jetpack-search/compare/v0.45.0...v0.45.1
[0.45.0]: https://github.com/Automattic/jetpack-search/compare/v0.44.17...v0.45.0
[0.44.17]: https://github.com/Automattic/jetpack-search/compare/v0.44.16...v0.44.17
[0.44.16]: https://github.com/Automattic/jetpack-search/compare/v0.44.15...v0.44.16
[0.44.15]: https://github.com/Automattic/jetpack-search/compare/v0.44.14...v0.44.15
[0.44.14]: https://github.com/Automattic/jetpack-search/compare/v0.44.13...v0.44.14
[0.44.13]: https://github.com/Automattic/jetpack-search/compare/v0.44.12...v0.44.13
[0.44.12]: https://github.com/Automattic/jetpack-search/compare/v0.44.11...v0.44.12
[0.44.11]: https://github.com/Automattic/jetpack-search/compare/v0.44.10...v0.44.11
[0.44.10]: https://github.com/Automattic/jetpack-search/compare/v0.44.9...v0.44.10
[0.44.9]: https://github.com/Automattic/jetpack-search/compare/v0.44.8...v0.44.9
[0.44.8]: https://github.com/Automattic/jetpack-search/compare/v0.44.7...v0.44.8
[0.44.7]: https://github.com/Automattic/jetpack-search/compare/v0.44.6...v0.44.7
[0.44.6]: https://github.com/Automattic/jetpack-search/compare/v0.44.5...v0.44.6
[0.44.5]: https://github.com/Automattic/jetpack-search/compare/v0.44.4...v0.44.5
[0.44.4]: https://github.com/Automattic/jetpack-search/compare/v0.44.3...v0.44.4
[0.44.3]: https://github.com/Automattic/jetpack-search/compare/v0.44.2...v0.44.3
[0.44.2]: https://github.com/Automattic/jetpack-search/compare/v0.44.1...v0.44.2
[0.44.1]: https://github.com/Automattic/jetpack-search/compare/v0.44.0...v0.44.1
[0.44.0]: https://github.com/Automattic/jetpack-search/compare/v0.43.8...v0.44.0
[0.43.8]: https://github.com/Automattic/jetpack-search/compare/v0.43.7...v0.43.8
[0.43.7]: https://github.com/Automattic/jetpack-search/compare/v0.43.6...v0.43.7
[0.43.6]: https://github.com/Automattic/jetpack-search/compare/v0.43.5...v0.43.6
[0.43.5]: https://github.com/Automattic/jetpack-search/compare/v0.43.4...v0.43.5
[0.43.4]: https://github.com/Automattic/jetpack-search/compare/v0.43.3...v0.43.4
[0.43.3]: https://github.com/Automattic/jetpack-search/compare/v0.43.2...v0.43.3
[0.43.2]: https://github.com/Automattic/jetpack-search/compare/v0.43.1...v0.43.2
[0.43.1]: https://github.com/Automattic/jetpack-search/compare/v0.43.0...v0.43.1
[0.43.0]: https://github.com/Automattic/jetpack-search/compare/v0.42.1...v0.43.0
[0.42.1]: https://github.com/Automattic/jetpack-search/compare/v0.42.0...v0.42.1
[0.42.0]: https://github.com/Automattic/jetpack-search/compare/v0.41.1...v0.42.0
[0.41.1]: https://github.com/Automattic/jetpack-search/compare/v0.41.0...v0.41.1
[0.41.0]: https://github.com/Automattic/jetpack-search/compare/v0.40.4...v0.41.0
[0.40.4]: https://github.com/Automattic/jetpack-search/compare/v0.40.3...v0.40.4
[0.40.3]: https://github.com/Automattic/jetpack-search/compare/v0.40.2...v0.40.3
[0.40.2]: https://github.com/Automattic/jetpack-search/compare/v0.40.1...v0.40.2
[0.40.1]: https://github.com/Automattic/jetpack-search/compare/v0.40.0...v0.40.1
[0.40.0]: https://github.com/Automattic/jetpack-search/compare/v0.39.7...v0.40.0
[0.39.7]: https://github.com/Automattic/jetpack-search/compare/v0.39.6...v0.39.7
[0.39.6]: https://github.com/Automattic/jetpack-search/compare/v0.39.5...v0.39.6
[0.39.5]: https://github.com/Automattic/jetpack-search/compare/v0.39.4...v0.39.5
[0.39.4]: https://github.com/Automattic/jetpack-search/compare/v0.39.3...v0.39.4
[0.39.3]: https://github.com/Automattic/jetpack-search/compare/v0.39.2...v0.39.3
[0.39.2]: https://github.com/Automattic/jetpack-search/compare/v0.39.1...v0.39.2
[0.39.1]: https://github.com/Automattic/jetpack-search/compare/v0.39.0...v0.39.1
[0.39.0]: https://github.com/Automattic/jetpack-search/compare/v0.38.8...v0.39.0
[0.38.8]: https://github.com/Automattic/jetpack-search/compare/v0.38.7...v0.38.8
[0.38.7]: https://github.com/Automattic/jetpack-search/compare/v0.38.6...v0.38.7
[0.38.6]: https://github.com/Automattic/jetpack-search/compare/v0.38.5...v0.38.6
[0.38.5]: https://github.com/Automattic/jetpack-search/compare/v0.38.4...v0.38.5
[0.38.4]: https://github.com/Automattic/jetpack-search/compare/v0.38.3...v0.38.4
[0.38.3]: https://github.com/Automattic/jetpack-search/compare/v0.38.2...v0.38.3
[0.38.2]: https://github.com/Automattic/jetpack-search/compare/v0.38.1...v0.38.2
[0.38.1]: https://github.com/Automattic/jetpack-search/compare/v0.38.0...v0.38.1
[0.38.0]: https://github.com/Automattic/jetpack-search/compare/v0.37.4...v0.38.0
[0.37.4]: https://github.com/Automattic/jetpack-search/compare/v0.37.3...v0.37.4
[0.37.3]: https://github.com/Automattic/jetpack-search/compare/v0.37.2...v0.37.3
[0.37.2]: https://github.com/Automattic/jetpack-search/compare/v0.37.1...v0.37.2
[0.37.1]: https://github.com/Automattic/jetpack-search/compare/v0.37.0...v0.37.1
[0.37.0]: https://github.com/Automattic/jetpack-search/compare/v0.36.3...v0.37.0
[0.36.3]: https://github.com/Automattic/jetpack-search/compare/v0.36.2...v0.36.3
[0.36.2]: https://github.com/Automattic/jetpack-search/compare/v0.36.1...v0.36.2
[0.36.1]: https://github.com/Automattic/jetpack-search/compare/v0.36.0...v0.36.1
[0.36.0]: https://github.com/Automattic/jetpack-search/compare/v0.35.0...v0.36.0
[0.35.0]: https://github.com/Automattic/jetpack-search/compare/v0.34.4...v0.35.0
[0.34.4]: https://github.com/Automattic/jetpack-search/compare/v0.34.3...v0.34.4
[0.34.3]: https://github.com/Automattic/jetpack-search/compare/v0.34.2...v0.34.3
[0.34.2]: https://github.com/Automattic/jetpack-search/compare/v0.34.1...v0.34.2
[0.34.1]: https://github.com/Automattic/jetpack-search/compare/v0.34.0...v0.34.1
[0.34.0]: https://github.com/Automattic/jetpack-search/compare/v0.33.3...v0.34.0
[0.33.3]: https://github.com/Automattic/jetpack-search/compare/v0.33.2...v0.33.3
[0.33.2]: https://github.com/Automattic/jetpack-search/compare/v0.33.1...v0.33.2
[0.33.1]: https://github.com/Automattic/jetpack-search/compare/v0.33.0...v0.33.1
[0.33.0]: https://github.com/Automattic/jetpack-search/compare/v0.32.0...v0.33.0
[0.32.0]: https://github.com/Automattic/jetpack-search/compare/v0.31.7...v0.32.0
[0.31.7]: https://github.com/Automattic/jetpack-search/compare/v0.31.6...v0.31.7
[0.31.6]: https://github.com/Automattic/jetpack-search/compare/v0.31.5...v0.31.6
[0.31.5]: https://github.com/Automattic/jetpack-search/compare/v0.31.4...v0.31.5
[0.31.4]: https://github.com/Automattic/jetpack-search/compare/v0.31.3...v0.31.4
[0.31.3]: https://github.com/Automattic/jetpack-search/compare/v0.31.2...v0.31.3
[0.31.2]: https://github.com/Automattic/jetpack-search/compare/v0.31.1...v0.31.2
[0.31.1]: https://github.com/Automattic/jetpack-search/compare/v0.31.0...v0.31.1
[0.31.0]: https://github.com/Automattic/jetpack-search/compare/v0.30.2...v0.31.0
[0.30.2]: https://github.com/Automattic/jetpack-search/compare/v0.30.1...v0.30.2
[0.30.1]: https://github.com/Automattic/jetpack-search/compare/v0.30.0...v0.30.1
[0.30.0]: https://github.com/Automattic/jetpack-search/compare/v0.29.2...v0.30.0
[0.29.2]: https://github.com/Automattic/jetpack-search/compare/v0.29.1...v0.29.2
[0.29.1]: https://github.com/Automattic/jetpack-search/compare/v0.29.0...v0.29.1
[0.29.0]: https://github.com/Automattic/jetpack-search/compare/v0.28.0...v0.29.0
[0.28.0]: https://github.com/Automattic/jetpack-search/compare/v0.27.0...v0.28.0
[0.27.0]: https://github.com/Automattic/jetpack-search/compare/v0.26.0...v0.27.0
[0.26.0]: https://github.com/Automattic/jetpack-search/compare/v0.25.0...v0.26.0
[0.25.0]: https://github.com/Automattic/jetpack-search/compare/v0.24.0...v0.25.0
[0.24.0]: https://github.com/Automattic/jetpack-search/compare/v0.23.0...v0.24.0
[0.23.0]: https://github.com/Automattic/jetpack-search/compare/v0.22.2...v0.23.0
[0.22.2]: https://github.com/Automattic/jetpack-search/compare/v0.22.1...v0.22.2
[0.22.1]: https://github.com/Automattic/jetpack-search/compare/v0.22.0...v0.22.1
[0.22.0]: https://github.com/Automattic/jetpack-search/compare/v0.21.1...v0.22.0
[0.21.1]: https://github.com/Automattic/jetpack-search/compare/v0.21.0...v0.21.1
[0.21.0]: https://github.com/Automattic/jetpack-search/compare/v0.20.0...v0.21.0
[0.20.0]: https://github.com/Automattic/jetpack-search/compare/v0.19.0...v0.20.0
[0.19.0]: https://github.com/Automattic/jetpack-search/compare/v0.18.0...v0.19.0
[0.18.0]: https://github.com/Automattic/jetpack-search/compare/v0.17.1...v0.18.0
[0.17.1]: https://github.com/Automattic/jetpack-search/compare/v0.17.0...v0.17.1
[0.17.0]: https://github.com/Automattic/jetpack-search/compare/v0.16.2...v0.17.0
[0.16.2]: https://github.com/Automattic/jetpack-search/compare/v0.16.1...v0.16.2
[0.16.1]: https://github.com/Automattic/jetpack-search/compare/v0.16.0...v0.16.1
[0.16.0]: https://github.com/Automattic/jetpack-search/compare/v0.15.4...v0.16.0
[0.15.4]: https://github.com/Automattic/jetpack-search/compare/v0.15.3...v0.15.4
[0.15.3]: https://github.com/Automattic/jetpack-search/compare/v0.15.2...v0.15.3
[0.15.2]: https://github.com/Automattic/jetpack-search/compare/v0.15.1...v0.15.2
[0.15.1]: https://github.com/Automattic/jetpack-search/compare/v0.15.0...v0.15.1
[0.15.0]: https://github.com/Automattic/jetpack-search/compare/v0.14.2...v0.15.0
[0.14.2]: https://github.com/Automattic/jetpack-search/compare/v0.14.1...v0.14.2
[0.14.1]: https://github.com/Automattic/jetpack-search/compare/v0.14.0...v0.14.1
[0.14.0]: https://github.com/Automattic/jetpack-search/compare/v0.13.4...v0.14.0
[0.13.4]: https://github.com/Automattic/jetpack-search/compare/v0.13.3...v0.13.4
[0.13.3]: https://github.com/Automattic/jetpack-search/compare/v0.13.2...v0.13.3
[0.13.2]: https://github.com/Automattic/jetpack-search/compare/v0.13.1...v0.13.2
[0.13.1]: https://github.com/Automattic/jetpack-search/compare/v0.13.0...v0.13.1
[0.13.0]: https://github.com/Automattic/jetpack-search/compare/v0.12.3...v0.13.0
[0.12.3]: https://github.com/Automattic/jetpack-search/compare/v0.12.2...v0.12.3
[0.12.2]: https://github.com/Automattic/jetpack-search/compare/v0.12.1...v0.12.2
[0.12.1]: https://github.com/Automattic/jetpack-search/compare/v0.12.0...v0.12.1
[0.12.0]: https://github.com/Automattic/jetpack-search/compare/v0.11.3...v0.12.0
[0.11.3]: https://github.com/Automattic/jetpack-search/compare/v0.11.2...v0.11.3
[0.11.2]: https://github.com/Automattic/jetpack-search/compare/v0.11.1...v0.11.2
[0.11.1]: https://github.com/Automattic/jetpack-search/compare/v0.11.0...v0.11.1
[0.11.0]: https://github.com/Automattic/jetpack-search/compare/v0.10.0...v0.11.0
[0.10.0]: https://github.com/Automattic/jetpack-search/compare/v0.9.1...v0.10.0
[0.9.1]: https://github.com/Automattic/jetpack-search/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/Automattic/jetpack-search/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/Automattic/jetpack-search/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/Automattic/jetpack-search/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/Automattic/jetpack-search/compare/v0.5.4...v0.6.0
[0.5.4]: https://github.com/Automattic/jetpack-search/compare/v0.5.3...v0.5.4
[0.5.3]: https://github.com/Automattic/jetpack-search/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/Automattic/jetpack-search/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/Automattic/jetpack-search/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/Automattic/jetpack-search/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/Automattic/jetpack-search/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/Automattic/jetpack-search/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/Automattic/jetpack-search/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/Automattic/jetpack-search/compare/v0.1.0...v0.2.0
