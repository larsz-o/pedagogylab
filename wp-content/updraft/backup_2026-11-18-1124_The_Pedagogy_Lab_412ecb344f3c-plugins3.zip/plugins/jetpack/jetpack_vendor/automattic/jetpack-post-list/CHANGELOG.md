# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.10.12] - 2026-11-16
### Changed
- Update dependencies.

## [0.10.11] - 2026-11-09
### Changed
- Update dependencies. [#54497]
- Update package dependencies. [#54512]

## [0.10.10] - 2026-11-02
### Changed
- Update package dependencies. [#53869]

## [0.10.9] - 2026-10-28
### Changed
- Update package dependencies. [#54118]

## [0.10.8] - 2026-10-26
### Changed
- Internal updates.

## [0.10.7] - 2026-10-19
### Changed
- Update package dependencies. [#53004]

## [0.10.6] - 2026-10-14
### Changed
- Update dependencies.

## [0.10.5] - 2026-10-12
### Changed
- Update dependencies.

## [0.10.4] - 2026-10-05
### Changed
- Update package dependencies. [#52999]

## [0.10.3] - 2026-09-21
### Changed
- Update package dependencies. [#52187]

## [0.10.2] - 2026-09-15
### Changed
- Update dependencies. [#52269]

## [0.10.1] - 2026-09-08
### Changed
- Update package dependencies. [#51701]

## [0.10.0] - 2026-09-01
### Removed
- Minimum supported PHP version is now 7.4. [#51515]

## [0.9.30] - 2026-08-20
### Changed
- Update dependencies. [#51095]

## [0.9.29] - 2026-07-27
### Changed
- Update dependencies. [#50719]
- Update package dependencies. [#50751]

## [0.9.28] - 2026-07-20
### Changed
- Update dependencies. [#50551]
- Update package dependencies. [#50529]

## [0.9.27] - 2026-07-13
### Changed
- Update dependencies. [#50360]

## [0.9.26] - 2026-07-06
### Changed
- Update package dependencies. [#50097] [#50183]

## [0.9.25] - 2026-06-29
### Changed
- Update dependencies. [#50004]

## [0.9.24] - 2026-06-26
### Changed
- Update dependencies.

## [0.9.23] - 2026-06-23
### Changed
- Update package dependencies. [#49831]

## [0.9.22] - 2026-06-22
### Changed
- Update dependencies. [#49641]
- Update package dependencies. [#49691]

## [0.9.21] - 2026-06-15
### Changed
- Update package dependencies. [#49273]

## [0.9.20] - 2026-06-08
### Changed
- Update dependencies. [#49354]

## [0.9.19] - 2026-05-25
### Changed
- Update package dependencies. [#48405]

## [0.9.18] - 2026-05-19
### Changed
- Update dependencies. [#48778]

## [0.9.17] - 2026-05-11
### Changed
- Update dependencies.

## [0.9.16] - 2026-05-04
### Changed
- Internal: No longer require automattic/jetpack-changelogger as a per-project dev dependency. [#48225]

## [0.9.15] - 2026-04-20
### Changed
- Update package dependencies. [#48106]

## [0.9.14] - 2026-04-09
### Changed
- Update package dependencies. [#47890]

## [0.9.13] - 2026-04-06
### Changed
- Update dependencies.

## [0.9.12] - 2026-03-30
### Changed
- Update dependencies.

## [0.9.11] - 2026-03-23
### Changed
- Update package dependencies. [#47684]

## [0.9.10] - 2026-03-16
### Changed
- Update dependencies. [#47472]

## [0.9.9] - 2026-03-09
### Changed
- Update dependencies. [#47508]

## [0.9.8] - 2026-02-26
### Changed
- Update package dependencies. [#47300]

## [0.9.7] - 2026-02-18
### Changed
- Update package dependencies. [#47173]

## [0.9.6] - 2026-02-16
### Changed
- Update dependencies. [#47109]

## [0.9.5] - 2026-02-10
### Changed
- Update package dependencies. [#47002]

## [0.9.4] - 2026-02-02
### Changed
- Update package dependencies. [#46854]

## [0.9.3] - 2026-01-26
### Changed
- Update dependencies.

## [0.9.2] - 2026-01-19
### Changed
- Update package dependencies. [#46647]

## [0.9.1] - 2026-01-12
### Changed
- Update package dependencies. [#46456]

## [0.9.0] - 2025-12-22
### Changed
- Moved Share post action to the Publicize package for better discoverability. The `jetpack_post_list_display_share_action` filter is now handled by Publicize. [#46323]
- Update dependencies. [#46381]

## [0.8.36] - 2025-12-15
### Changed
- Update dependencies. [#46271]

## [0.8.35] - 2025-12-08
### Changed
- Update dependencies.

## [0.8.34] - 2025-12-01
### Changed
- Update package dependencies. [#46143]

## [0.8.33] - 2025-11-17
### Changed
- Update package dependencies. [#45915]

## [0.8.32] - 2025-11-03
### Changed
- Update dependencies. [#45664]

## [0.8.31] - 2025-10-06
### Changed
- Update dependencies. [#45349]

## [0.8.30] - 2025-09-22
### Changed
- Update dependencies.

## [0.8.29] - 2025-09-19
### Changed
- Update package dependencies. [#45173] [#45229]

## [0.8.28] - 2025-09-08
### Changed
- Update package dependencies. [#45027]

## [0.8.27] - 2025-08-14
### Changed
- Update package dependencies. [#44701]

## [0.8.26] - 2025-08-11
### Changed
- Update package dependencies. [#44677]

## [0.8.25] - 2025-08-04
### Changed
- Update dependencies. [#44583]

## [0.8.24] - 2025-07-28
### Changed
- Internal updates.

## [0.8.23] - 2025-07-21
### Changed
- Tests: Update class used in Slideshow block. [#44099]

## [0.8.22] - 2025-07-14
### Changed
- Update dependencies. [#44229]

## [0.8.21] - 2025-07-07
### Changed
- Update package dependencies. [#44148]

## [0.8.20] - 2025-06-30
### Changed
- Update dependencies.

## [0.8.19] - 2025-06-23
### Changed
- Update dependencies. [#44002]
- Update package dependencies. [#44020]

## [0.8.18] - 2025-06-05
### Changed
- Update dependencies. [#43751]

## [0.8.17] - 2025-06-02
### Changed
- Update dependencies.

## [0.8.16] - 2025-05-26
### Changed
- Update package dependencies. [#43578]

## [0.8.15] - 2025-05-22
### Changed
- Update dependencies.

## [0.8.14] - 2025-05-05
### Changed
- Update package dependencies. [#43326]

## [0.8.13] - 2025-04-28
### Changed
- Internal updates.

## [0.8.12] - 2025-04-14
### Changed
- Update dependencies. [#43001]

## [0.8.11] - 2025-04-07
### Changed
- Linting: First pass of style coding standards. [#42734]
- Update dependencies. [#42820]
- Update package dependencies. [#42809]

## [0.8.10] - 2025-03-21
### Changed
- Internal updates.

## [0.8.9] - 2025-03-18
### Changed
- Update dependencies. [#42545]

## [0.8.8] - 2025-03-17
### Changed
- Internal updates.

## [0.8.7] - 2025-03-17
### Changed
- Social: Change the query parameter to open Jetpack sidebar on editor load. [#42364]

## [0.8.6] - 2025-03-12
### Changed
- Internal updates.

## [0.8.5] - 2025-03-10
### Fixed
- Exclude unit tests from published package. [#42190]

## [0.8.4] - 2025-03-03
### Changed
- Update package dependencies. [#42163]

## [0.8.3] - 2025-02-24
### Changed
- Update dependencies.

## [0.8.2] - 2025-02-17
### Changed
- Update dependencies.

## [0.8.1] - 2025-02-10
### Changed
- Updated package dependencies. [#41491]

## [0.8.0] - 2025-02-03
### Added
- Post List: Add a Copy Link Quick Action. [#41305]

## [0.7.3] - 2025-01-13
### Fixed
- Pages and Posts: Fix the layout on mobile when details are open. [#40872]

## [0.7.2] - 2024-12-16
### Changed
- Internal updates.

## [0.7.1] - 2024-11-25
### Changed
- Updated dependencies. [#40286]

## [0.7.0] - 2024-11-18
### Removed
- General: Update minimum PHP version to 7.2. [#40147]

## [0.6.5] - 2024-11-04
### Added
- Enable test coverage. [#39961]

## [0.6.4] - 2024-10-29
### Changed
- Internal updates.

## [0.6.3] - 2024-08-23
### Changed
- Updated package dependencies. [#39004]

## [0.6.2] - 2024-04-08
### Changed
- Internal updates.

## [0.6.1] - 2024-03-18
### Changed
- Internal updates.

## [0.6.0] - 2024-02-26
### Changed
- Social Notes: Added the post list enhancements [#35819]

## [0.5.1] - 2023-11-24
### Changed
- Replaced usage of substr() with str_starts_with() and str_ends_with(). [#34207]

## [0.5.0] - 2023-11-20
### Changed
- Updated required PHP version to >= 7.0. [#34192]

## [0.4.6] - 2023-08-28
### Changed
- Updated package dependencies. [#32605]

## [0.4.5] - 2023-04-10
### Added
- Add Jetpack Autoloader package suggestion. [#29988]

## [0.4.4] - 2023-02-20
### Changed
- Minor internal updates.

## [0.4.3] - 2022-12-06
### Changed
- Updated package dependencies. [#27688]

## [0.4.2] - 2022-11-28
### Changed
- Updated package dependencies. [#27043]

## [0.4.1] - 2022-09-20
### Changed
- Updated package dependencies.

## [0.4.0] - 2022-08-30
### Changed
- Rebrand Publicize to Jetpack Social [#25787]
- Updated package dependencies. [#25158]

## [0.3.1] - 2022-07-06
### Changed
- PHPCS: fix `WordPress.Security.ValidatedSanitizedInput`. [#23942]
- Renaming master to trunk. [#24661]
- Updated package dependencies. [#24045]

## [0.3.0] - 2022-02-01
### Changed
- Build: remove unneeded files from production build.
- Switch to pcov for code coverage.
- Updated package dependencies.
- Updated package textdomain from `jetpack` to `jetpack-post-list`.

## [0.2.4] - 2021-11-19
### Fixed
- Fixed the stretched thumbnails when using a non-square image.
- Fixed the broken layout after making a quick edit.

### Changed
- Updated package dependencies

## [0.2.3] - 2021-11-02
### Changed
- Set `convertDeprecationsToExceptions` true in PHPUnit config.
- Thumbnails only available on "Pages" and "Posts". Share action only when publicize and block-editor supported.
- Updated package dependencies.
- Update PHPUnit configs to include just what needs coverage rather than include everything then try to exclude stuff that doesn't.

## [0.2.2] - 2021-10-08
### Fixed
- Fixed the check for a valid thumbnail

## [0.2.1] - 2021-10-06
### Changed
- Updated package dependencies

## [0.2.0] - 2021-10-06
### Added
- Added a 'Share' post action

### Changed
- Only add the thumbnail column for post types that support it
- Updated package dependencies.

## 0.1.0 - 2021-09-22
### Added
- Add the new Post List package to Jetpack project

### Changed
- Updated the default columns displayed on the post and page list screens
- Refactored thumbnail preview to function server side. All javascript removed.

[0.10.12]: https://github.com/automattic/jetpack-post-list/compare/v0.10.11...v0.10.12
[0.10.11]: https://github.com/automattic/jetpack-post-list/compare/v0.10.10...v0.10.11
[0.10.10]: https://github.com/automattic/jetpack-post-list/compare/v0.10.9...v0.10.10
[0.10.9]: https://github.com/automattic/jetpack-post-list/compare/v0.10.8...v0.10.9
[0.10.8]: https://github.com/automattic/jetpack-post-list/compare/v0.10.7...v0.10.8
[0.10.7]: https://github.com/automattic/jetpack-post-list/compare/v0.10.6...v0.10.7
[0.10.6]: https://github.com/automattic/jetpack-post-list/compare/v0.10.5...v0.10.6
[0.10.5]: https://github.com/automattic/jetpack-post-list/compare/v0.10.4...v0.10.5
[0.10.4]: https://github.com/automattic/jetpack-post-list/compare/v0.10.3...v0.10.4
[0.10.3]: https://github.com/automattic/jetpack-post-list/compare/v0.10.2...v0.10.3
[0.10.2]: https://github.com/automattic/jetpack-post-list/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/automattic/jetpack-post-list/compare/v0.10.0...v0.10.1
[0.10.0]: https://github.com/automattic/jetpack-post-list/compare/v0.9.30...v0.10.0
[0.9.30]: https://github.com/automattic/jetpack-post-list/compare/v0.9.29...v0.9.30
[0.9.29]: https://github.com/automattic/jetpack-post-list/compare/v0.9.28...v0.9.29
[0.9.28]: https://github.com/automattic/jetpack-post-list/compare/v0.9.27...v0.9.28
[0.9.27]: https://github.com/automattic/jetpack-post-list/compare/v0.9.26...v0.9.27
[0.9.26]: https://github.com/automattic/jetpack-post-list/compare/v0.9.25...v0.9.26
[0.9.25]: https://github.com/automattic/jetpack-post-list/compare/v0.9.24...v0.9.25
[0.9.24]: https://github.com/automattic/jetpack-post-list/compare/v0.9.23...v0.9.24
[0.9.23]: https://github.com/automattic/jetpack-post-list/compare/v0.9.22...v0.9.23
[0.9.22]: https://github.com/automattic/jetpack-post-list/compare/v0.9.21...v0.9.22
[0.9.21]: https://github.com/automattic/jetpack-post-list/compare/v0.9.20...v0.9.21
[0.9.20]: https://github.com/automattic/jetpack-post-list/compare/v0.9.19...v0.9.20
[0.9.19]: https://github.com/automattic/jetpack-post-list/compare/v0.9.18...v0.9.19
[0.9.18]: https://github.com/automattic/jetpack-post-list/compare/v0.9.17...v0.9.18
[0.9.17]: https://github.com/automattic/jetpack-post-list/compare/v0.9.16...v0.9.17
[0.9.16]: https://github.com/automattic/jetpack-post-list/compare/v0.9.15...v0.9.16
[0.9.15]: https://github.com/automattic/jetpack-post-list/compare/v0.9.14...v0.9.15
[0.9.14]: https://github.com/automattic/jetpack-post-list/compare/v0.9.13...v0.9.14
[0.9.13]: https://github.com/automattic/jetpack-post-list/compare/v0.9.12...v0.9.13
[0.9.12]: https://github.com/automattic/jetpack-post-list/compare/v0.9.11...v0.9.12
[0.9.11]: https://github.com/automattic/jetpack-post-list/compare/v0.9.10...v0.9.11
[0.9.10]: https://github.com/automattic/jetpack-post-list/compare/v0.9.9...v0.9.10
[0.9.9]: https://github.com/automattic/jetpack-post-list/compare/v0.9.8...v0.9.9
[0.9.8]: https://github.com/automattic/jetpack-post-list/compare/v0.9.7...v0.9.8
[0.9.7]: https://github.com/automattic/jetpack-post-list/compare/v0.9.6...v0.9.7
[0.9.6]: https://github.com/automattic/jetpack-post-list/compare/v0.9.5...v0.9.6
[0.9.5]: https://github.com/automattic/jetpack-post-list/compare/v0.9.4...v0.9.5
[0.9.4]: https://github.com/automattic/jetpack-post-list/compare/v0.9.3...v0.9.4
[0.9.3]: https://github.com/automattic/jetpack-post-list/compare/v0.9.2...v0.9.3
[0.9.2]: https://github.com/automattic/jetpack-post-list/compare/v0.9.1...v0.9.2
[0.9.1]: https://github.com/automattic/jetpack-post-list/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/automattic/jetpack-post-list/compare/v0.8.36...v0.9.0
[0.8.36]: https://github.com/automattic/jetpack-post-list/compare/v0.8.35...v0.8.36
[0.8.35]: https://github.com/automattic/jetpack-post-list/compare/v0.8.34...v0.8.35
[0.8.34]: https://github.com/automattic/jetpack-post-list/compare/v0.8.33...v0.8.34
[0.8.33]: https://github.com/automattic/jetpack-post-list/compare/v0.8.32...v0.8.33
[0.8.32]: https://github.com/automattic/jetpack-post-list/compare/v0.8.31...v0.8.32
[0.8.31]: https://github.com/automattic/jetpack-post-list/compare/v0.8.30...v0.8.31
[0.8.30]: https://github.com/automattic/jetpack-post-list/compare/v0.8.29...v0.8.30
[0.8.29]: https://github.com/automattic/jetpack-post-list/compare/v0.8.28...v0.8.29
[0.8.28]: https://github.com/automattic/jetpack-post-list/compare/v0.8.27...v0.8.28
[0.8.27]: https://github.com/automattic/jetpack-post-list/compare/v0.8.26...v0.8.27
[0.8.26]: https://github.com/automattic/jetpack-post-list/compare/v0.8.25...v0.8.26
[0.8.25]: https://github.com/automattic/jetpack-post-list/compare/v0.8.24...v0.8.25
[0.8.24]: https://github.com/automattic/jetpack-post-list/compare/v0.8.23...v0.8.24
[0.8.23]: https://github.com/automattic/jetpack-post-list/compare/v0.8.22...v0.8.23
[0.8.22]: https://github.com/automattic/jetpack-post-list/compare/v0.8.21...v0.8.22
[0.8.21]: https://github.com/automattic/jetpack-post-list/compare/v0.8.20...v0.8.21
[0.8.20]: https://github.com/automattic/jetpack-post-list/compare/v0.8.19...v0.8.20
[0.8.19]: https://github.com/automattic/jetpack-post-list/compare/v0.8.18...v0.8.19
[0.8.18]: https://github.com/automattic/jetpack-post-list/compare/v0.8.17...v0.8.18
[0.8.17]: https://github.com/automattic/jetpack-post-list/compare/v0.8.16...v0.8.17
[0.8.16]: https://github.com/automattic/jetpack-post-list/compare/v0.8.15...v0.8.16
[0.8.15]: https://github.com/automattic/jetpack-post-list/compare/v0.8.14...v0.8.15
[0.8.14]: https://github.com/automattic/jetpack-post-list/compare/v0.8.13...v0.8.14
[0.8.13]: https://github.com/automattic/jetpack-post-list/compare/v0.8.12...v0.8.13
[0.8.12]: https://github.com/automattic/jetpack-post-list/compare/v0.8.11...v0.8.12
[0.8.11]: https://github.com/automattic/jetpack-post-list/compare/v0.8.10...v0.8.11
[0.8.10]: https://github.com/automattic/jetpack-post-list/compare/v0.8.9...v0.8.10
[0.8.9]: https://github.com/automattic/jetpack-post-list/compare/v0.8.8...v0.8.9
[0.8.8]: https://github.com/automattic/jetpack-post-list/compare/v0.8.7...v0.8.8
[0.8.7]: https://github.com/automattic/jetpack-post-list/compare/v0.8.6...v0.8.7
[0.8.6]: https://github.com/automattic/jetpack-post-list/compare/v0.8.5...v0.8.6
[0.8.5]: https://github.com/automattic/jetpack-post-list/compare/v0.8.4...v0.8.5
[0.8.4]: https://github.com/automattic/jetpack-post-list/compare/v0.8.3...v0.8.4
[0.8.3]: https://github.com/automattic/jetpack-post-list/compare/v0.8.2...v0.8.3
[0.8.2]: https://github.com/automattic/jetpack-post-list/compare/v0.8.1...v0.8.2
[0.8.1]: https://github.com/automattic/jetpack-post-list/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/automattic/jetpack-post-list/compare/v0.7.3...v0.8.0
[0.7.3]: https://github.com/automattic/jetpack-post-list/compare/v0.7.2...v0.7.3
[0.7.2]: https://github.com/automattic/jetpack-post-list/compare/v0.7.1...v0.7.2
[0.7.1]: https://github.com/automattic/jetpack-post-list/compare/v0.7.0...v0.7.1
[0.7.0]: https://github.com/automattic/jetpack-post-list/compare/v0.6.5...v0.7.0
[0.6.5]: https://github.com/automattic/jetpack-post-list/compare/v0.6.4...v0.6.5
[0.6.4]: https://github.com/automattic/jetpack-post-list/compare/v0.6.3...v0.6.4
[0.6.3]: https://github.com/automattic/jetpack-post-list/compare/v0.6.2...v0.6.3
[0.6.2]: https://github.com/automattic/jetpack-post-list/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/automattic/jetpack-post-list/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/automattic/jetpack-post-list/compare/v0.5.1...v0.6.0
[0.5.1]: https://github.com/automattic/jetpack-post-list/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/automattic/jetpack-post-list/compare/v0.4.6...v0.5.0
[0.4.6]: https://github.com/automattic/jetpack-post-list/compare/v0.4.5...v0.4.6
[0.4.5]: https://github.com/automattic/jetpack-post-list/compare/v0.4.4...v0.4.5
[0.4.4]: https://github.com/automattic/jetpack-post-list/compare/v0.4.3...v0.4.4
[0.4.3]: https://github.com/automattic/jetpack-post-list/compare/v0.4.2...v0.4.3
[0.4.2]: https://github.com/automattic/jetpack-post-list/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/automattic/jetpack-post-list/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/automattic/jetpack-post-list/compare/v0.3.1...v0.4.0
[0.3.1]: https://github.com/automattic/jetpack-post-list/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/automattic/jetpack-post-list/compare/v0.2.4...v0.3.0
[0.2.4]: https://github.com/automattic/jetpack-post-list/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/automattic/jetpack-post-list/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/automattic/jetpack-post-list/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/automattic/jetpack-post-list/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/automattic/jetpack-post-list/compare/v0.1.0...v0.2.0
