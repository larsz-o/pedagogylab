<?php
// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery -- we try to reduce overhead by bypassing WP APIs and other extra layers; Some custom complex queries tailored specifically to our needs, giving us full control over the SQL commands and data manipulation
// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fclose, WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_operations_fwrite, WordPress.WP.AlternativeFunctions.file_system_operations_fgets, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents, WordPress.WP.AlternativeFunctions.file_system_operations_mkdir, WordPress.WP.AlternativeFunctions.file_system_operations_fread, WordPress.WP.AlternativeFunctions.file_system_operations_chmod, WordPress.WP.AlternativeFunctions.file_system_operations_fputs, WordPress.WP.AlternativeFunctions.file_system_operations_is_writable, WordPress.WP.AlternativeFunctions.file_system_operations_chown, WordPress.WP.AlternativeFunctions.file_system_operations_chgrp, WordPress.WP.AlternativeFunctions.file_system_operations_touch, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- Native PHP fileystem function is used for direct control and performance because it can bypass additional layers of abstraction so that no overhead from the WordPress filesystem API's internal handling
// phpcs:disable WordPress.WP.AlternativeFunctions.rename_rename -- rename() usage is intentional and safe within this context
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching -- some query operations need to always receive the most up-to-date or actual data directly from the database, reducing the risk of serving stale information.
if (!defined('ABSPATH')) die('No direct access.');

/**
 * Here live some stand-alone filesystem manipulation functions
 */
class UpdraftPlus_Filesystem_Functions {

	/**
	 * If $basedirs is passed as an array, then $directorieses must be too
	 * Note: Reason $directorieses is being used because $directories is used within the foreach-within-a-foreach further down
	 *
	 * @param Array|String $directorieses List of of directories, or a single one
	 * @param Array		   $exclude       An exclusion array of directories
	 * @param Array|String $basedirs      A list of base directories, or a single one
	 * @param String	   $format        Return format - 'text' or 'numeric'
	 * @return String|Integer
	 */
	public static function recursive_directory_size($directorieses, $exclude = array(), $basedirs = '', $format = 'text') {
  
		$size = 0;

		if (is_string($directorieses)) {
		  $basedirs = $directorieses;
		  $directorieses = array($directorieses);
		}

		if (is_string($basedirs)) $basedirs = array($basedirs);

		foreach ($directorieses as $ind => $directories) {
			if (!is_array($directories)) $directories = array($directories);

			$basedir = empty($basedirs[$ind]) ? $basedirs[0] : $basedirs[$ind];

			foreach ($directories as $dir) {
				if (is_file($dir)) {
					$size += @filesize($dir);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
				} else {
					$suffix = ('' != $basedir) ? ((0 === strpos($dir, $basedir.'/')) ? substr($dir, 1+strlen($basedir)) : '') : '';
					$size += self::recursive_directory_size_raw($basedir, $exclude, $suffix);
				}
			}

		}

		if ('numeric' == $format) return $size;

		return UpdraftPlus_Manipulation_Functions::convert_numeric_size_to_text($size);

	}
	
	/**
	 * Ensure that WP_Filesystem is instantiated and functional. Otherwise, outputs necessary HTML and dies.
	 *
	 * @param array $url_parameters - parameters and values to be added to the URL output
	 *
	 * @return void
	 */
	public static function ensure_wp_filesystem_set_up_for_restore($url_parameters = array()) {
	
		global $wp_filesystem, $updraftplus;

		$build_url = UpdraftPlus_Options::admin_page().'?page=updraftplus&action=updraft_restore&nonce='.wp_create_nonce('updraftplus-credentialtest-nonce');
		
		foreach ($url_parameters as $k => $v) {
			$build_url .= '&'.$k.'='.$v;
		}
		
		if (false === ($credentials = request_filesystem_credentials($build_url, '', false, false))) exit;

		if (!WP_Filesystem($credentials)) {

			$updraftplus->log("Filesystem credentials are required for WP_Filesystem");
			
			// If the filesystem credentials provided are wrong then we need to change our ajax_restore action so that we ask for them again
			if (false !== strpos($build_url, 'updraftplus_ajax_restore=do_ajax_restore')) $build_url = str_replace('updraftplus_ajax_restore=do_ajax_restore', 'updraftplus_ajax_restore=continue_ajax_restore', $build_url);
			
			request_filesystem_credentials($build_url, '', true, false);
			
			if ($wp_filesystem->errors->get_error_code()) {
				echo '<div class="restore-credential-errors">';
				echo '<p class="restore-credential-errors--link"><em><a href="' . esc_url(apply_filters('updraftplus_com_link', "https://teamupdraft.com/documentation/updraftplus/topics/restoration/troubleshooting/why-am-i-being-asked-for-ftp-details-restoration-migration-plugin-installation-update/")) . '" target="_blank">' . esc_html__('Why am I seeing this?', 'updraftplus') . '</a></em></p>';
				echo '<div class="restore-credential-errors--list">';
				foreach ($wp_filesystem->errors->get_error_messages() as $message) show_message($message);
				echo '</div>';
				echo '</div>';
				exit;
			}
		}
	}
	
	/**
	 * Get the html of "Web-server disk space" line which resides above of the existing backup table
	 *
	 * @param Boolean $will_immediately_calculate_disk_space Whether disk space should be counted now or when user click Refresh link
	 *
	 * @return String Web server disk space html to render
	 */
	public static function web_server_disk_space($will_immediately_calculate_disk_space = true) {
		if ($will_immediately_calculate_disk_space) {
			$disk_space_used = self::get_disk_space_used('updraft', 'numeric');
			if ($disk_space_used > apply_filters('updraftplus_display_usage_line_threshold_size', 104857600)) { // 104857600 = 100 MB = (100 * 1024 * 1024)
				$disk_space_text = UpdraftPlus_Manipulation_Functions::convert_numeric_size_to_text($disk_space_used);
				$refresh_link_text = __('refresh', 'updraftplus');
				return self::web_server_disk_space_html($disk_space_text, $refresh_link_text);
			} else {
				return '';
			}
		} else {
			$disk_space_text = '';
			$refresh_link_text = __('calculate', 'updraftplus');
			return self::web_server_disk_space_html($disk_space_text, $refresh_link_text);
		}
	}
	
	/**
	 * Get the html of "Web-server disk space" line which resides above of the existing backup table
	 *
	 * @param String $disk_space_text   The texts which represents disk space usage
	 * @param String $refresh_link_text Refresh disk space link text
	 *
	 * @return String - Web server disk space HTML
	 */
	public static function web_server_disk_space_html($disk_space_text, $refresh_link_text) {
		return '<li class="updraft-server-disk-space" title="'.esc_attr__('This is a count of the contents of your Updraft directory', 'updraftplus').'"><strong>'.__('Web-server disk space in use by UpdraftPlus', 'updraftplus').':</strong> <span class="updraft_diskspaceused"><em>'.$disk_space_text.'</em></span> <a class="updraft_diskspaceused_update" href="#">'.$refresh_link_text.'</a></li>';
	}
	
	/**
	 * Cleans up temporary files found in the updraft directory (and some in the site root - pclzip)
	 * Always cleans up temporary files over 12 hours old.
	 * With parameters, also cleans up those.
	 * Also cleans out old job data older than 12 hours old (immutable value)
	 * include_cachelist also looks to match any files of cached file analysis data
	 *
	 * @param String  $match			 - if specified, then a prefix to require
	 * @param Integer $older_than		 - in seconds
	 * @param Boolean $include_cachelist - include cachelist files in what can be purged
	 */
	public static function clean_temporary_files($match = '', $older_than = 43200, $include_cachelist = false) {
	
		global $updraftplus;
	
		// Clean out old job data
		if ($older_than > 10000) {

			global $wpdb;
			$table = is_multisite() ? $wpdb->sitemeta : $wpdb->options;
			$key_column = is_multisite() ? 'meta_key' : 'option_name';
			$value_column = is_multisite() ? 'meta_value' : 'option_value';
			
			// Limit the maximum number for performance (the rest will get done next time, if for some reason there was a back-log)
			// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.InterpolatedNotPrepared  -- $key_column, $value_column are safe string literals ('meta_key'/'option_name', 'meta_value'/'option_value'); $table is $wpdb->sitemeta or $wpdb->options, both are trusted wpdb properties.
			$all_jobs = $wpdb->get_results($wpdb->prepare("SELECT $key_column, $value_column FROM $table WHERE $key_column LIKE %s LIMIT 100", 'updraft_jobdata_%'), ARRAY_A);
			
			foreach ($all_jobs as $job) {
				$nonce = str_replace('updraft_jobdata_', '', $job[$key_column]);
				$val = empty($job[$value_column]) ? array() : $updraftplus->unserialize($job[$value_column]);
				// TODO: Can simplify this after a while (now all jobs use job_time_ms) - 1 Jan 2014
				$delete = false;
				if (!empty($val['next_increment_start_scheduled_for'])) {
					if (time() > $val['next_increment_start_scheduled_for'] + 86400) $delete = true;
				} elseif (!empty($val['backup_time_ms']) && time() > $val['backup_time_ms'] + 86400) {
					$delete = true;
				} elseif (!empty($val['job_time_ms']) && time() > $val['job_time_ms'] + 86400) {
					$delete = true;
				} elseif (!empty($val['job_type']) && 'backup' != $val['job_type'] && empty($val['backup_time_ms']) && empty($val['job_time_ms'])) {
					$delete = true;
				}
				if (isset($val['temp_import_table_prefix']) && '' != $val['temp_import_table_prefix'] && $wpdb->prefix != $val['temp_import_table_prefix']) {
					$tables_to_remove = array();
					$prefix = UpdraftPlus_Database_Utility::esc_like($val['temp_import_table_prefix'])."%";
					$sql = $wpdb->prepare("SHOW TABLES LIKE %s", $prefix);
					
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql is built using $wpdb->prepare() on the line above.
					foreach ($wpdb->get_results($sql) as $table) {
						$tables_to_remove = array_merge($tables_to_remove, array_values(get_object_vars($table)));
					}
					
					foreach ($tables_to_remove as $table_name) {
						// phpcs:ignore PluginCheck.Security.DirectDB.UnescapedDBParameter, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange -- DDL DROP TABLE statement; $table_name is a SQL identifier sanitized using backquote(), Direct schema change is required here and handled carefully.
						$wpdb->query('DROP TABLE '.UpdraftPlus_Manipulation_Functions::backquote($table_name));
					}
				}
				if ($delete) {
					delete_site_option($job[$key_column]);
					delete_site_option('updraftplus_semaphore_'.$nonce);
				}
			}
			$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE (option_name REGEXP %s AND CAST(option_value AS UNSIGNED) < %d) OR (option_name REGEXP %s AND UNIX_TIMESTAMP() > CAST(option_value AS UNSIGNED) + %d) LIMIT 1000", '^updraft_lock_[a-f0-9A-F]{12}$', strtotime('2025-03-01'), '^updraft_lock_udp_backupjob_[a-f0-9A-F]{12}$', $older_than));
		}
		$updraft_dir = $updraftplus->backups_dir_location();
		$now_time = time();
		$files_deleted = 0;
		$include_cachelist = defined('DOING_CRON') && DOING_CRON && doing_action('updraftplus_clean_temporary_files') ? true : $include_cachelist;
		if ($handle = opendir($updraft_dir)) {
			while (false !== ($entry = readdir($handle))) {
				$manifest_match = preg_match("/updraftplus-manifest\.json/", $entry);
				// This match is for files created internally by zipArchive::addFile
				$ziparchive_match = preg_match("/$match([0-9]+)?\.zip\.tmp\.(?:[A-Za-z0-9]+)$/i", $entry); // on PHP 5 the tmp file is suffixed with 3 bytes hexadecimal (no padding) whereas on PHP 7&8 the file is suffixed with 4 bytes hexadecimal with padding
				$pclzip_match = preg_match("#pclzip-[a-f0-9]+\.(?:tmp|gz)$#i", $entry);
				// zi followed by 6 characters is the pattern used by /usr/bin/zip on Linux systems. It's safe to check for, as we have nothing else that's going to match that pattern.
				$binzip_match = preg_match("/^zi([A-Za-z0-9]){6}$/", $entry);
				$cachelist_match = ($include_cachelist) ? preg_match("/-cachelist-.*(?:info|\.tmp)$/i", $entry) : false;
				$browserlog_match = preg_match('/^log\.[0-9a-f]+-browser\.txt$/', $entry);
				$downloader_client_match = preg_match("/$match([0-9]+)?\.zip\.tmp\.(?:[A-Za-z0-9]+)\.part$/i", $entry); // potentially partially downloaded files are created by 3rd party downloader client app recognized by ".part" extension at the end of the backup file name (e.g. .zip.tmp.3b9r8r.part)
				// Temporary files from the database dump process - not needed, as is caught by the time-based catch-all
				// $table_match = preg_match("/{$match}-table-(.*)\.table(\.tmp)?\.gz$/i", $entry);
				// The gz goes in with the txt, because we *don't* want to reap the raw .txt files
				if ((preg_match("/$match\.(tmp|table|txt\.gz)(\.gz)?$/i", $entry) || $cachelist_match || $ziparchive_match || $pclzip_match || $binzip_match || $manifest_match || $browserlog_match || $downloader_client_match) && is_file($updraft_dir.'/'.$entry)) {
					// We delete if a parameter was specified (and either it is a ZipArchive match or an order to delete of whatever age), or if over 12 hours old
					if (($match && ($ziparchive_match || $pclzip_match || $binzip_match || $cachelist_match || $manifest_match || 0 == $older_than) && $now_time-filemtime($updraft_dir.'/'.$entry) >= $older_than) || $now_time-filemtime($updraft_dir.'/'.$entry)>43200) {
						$skip_dblog = (0 == $files_deleted % 25) ? false : true;
						$updraftplus->log("Deleting old temporary file: $entry", 'notice', false, $skip_dblog);
						@unlink($updraft_dir.'/'.$entry);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the file doesn't exist.
						$files_deleted++;
					}
				} elseif (preg_match('/^log\.[0-9a-f]+\.txt$/', $entry) && $now_time-filemtime($updraft_dir.'/'.$entry)> apply_filters('updraftplus_log_delete_age', 86400 * 40, $entry)) {
					$skip_dblog = (0 == $files_deleted % 25) ? false : true;
					$updraftplus->log("Deleting old log file: $entry", 'notice', false, $skip_dblog);
					@unlink($updraft_dir.'/'.$entry);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the file doesn't exist.
					$files_deleted++;
				}
			}
			@closedir($handle);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
		}

		// Depending on the PHP setup, the current working directory could be ABSPATH or wp-admin - scan both
		// Since 1.9.32, we set them to go into $updraft_dir, so now we must check there too. Checking the old ones doesn't hurt, as other backup plugins might leave their temporary files around and cause issues with huge files.
		foreach (array(ABSPATH, ABSPATH.'wp-admin/', $updraft_dir.'/') as $path) {
			if ($handle = opendir($path)) {
				while (false !== ($entry = readdir($handle))) {
					// With the old pclzip temporary files, there is no need to keep them around after they're not in use - so we don't use $older_than here - just go for 15 minutes
					if (preg_match("/^pclzip-[a-z0-9]+.tmp$/", $entry) && $now_time-filemtime($path.$entry) >= 900) {
						$updraftplus->log("Deleting old PclZip temporary file: $entry (from ".basename($path).")");
						@unlink($path.$entry);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the file doesn't exist.
					}
				}
				@closedir($handle);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
			}
		}
	}
	
	/**
	 * Find out whether we really can write to a particular folder
	 *
	 * @param String  $dir					 - the folder path
	 * @param Boolean $test_case_sensitivity - also require that the filesystem be case-sensitive to return true (hence, false could be for multiple reasons)
	 *
	 * @return Boolean - the result
	 */
	public static function really_is_writable($dir, $test_case_sensitivity = false) {
		// Suppress warnings, since if the user is dumping warnings to screen, then invalid JavaScript results and the screen breaks.
		if (!@is_writable($dir)) return false;// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- PHP's logging is not useful here.
		// Found a case - GoDaddy server, Windows, PHP 5.2.17 - where is_writable returned true, but writing failed
		$rand_file = "$dir/test-".md5(wp_rand().time())."-ud.txt";
		$rand_file_uc = substr($rand_file, 0, -7).'-UD.txt';
		while (file_exists($rand_file) && (!$test_case_sensitivity || file_exists($rand_file_uc))) {
			$rand_file = "$dir/test-".md5(wp_rand().time())."-ud.txt";
			$rand_file_uc = substr($rand_file, 0, -7).'-UD.txt';
		}
		
		$file_contents = 'testing... '.wp_rand();
		
		$ret = @file_put_contents($rand_file, $file_contents);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- PHP's logging is not useful here
		
		if ($ret && $test_case_sensitivity) {
			if (is_file($rand_file_uc)) {
				if (file_get_contents($rand_file_uc) === $file_contents) {
					$ret = 0;
				}
				// If it exists but was different, then it's apparently been created by something else. N.B. We only attempt to remove the file we created.
			}
		}
		
		@unlink($rand_file);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the file doesn't exist.
		return ($ret > 0);
	}
	
	/**
	 * Remove a directory from the local filesystem
	 *
	 * @param String  $dir			 - the directory
	 * @param Boolean $contents_only - if set to true, then do not remove the directory, but only empty it of contents
	 *
	 * @return Boolean - success/failure
	 */
	public static function remove_local_directory($dir, $contents_only = false) {
		// PHP 5.3+ only
		// foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $path) {
		// $path->isFile() ? unlink($path->getPathname()) : rmdir($path->getPathname());
		// }
		// return rmdir($dir);

		if ($handle = @opendir($dir)) {// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
			while (false !== ($entry = readdir($handle))) {
				if ('.' !== $entry && '..' !== $entry) {
					if (is_dir($dir.'/'.$entry)) {
						self::remove_local_directory($dir.'/'.$entry, false);
					} else {
						@unlink($dir.'/'.$entry);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the file doesn't exist.
					}
				}
			}
			@closedir($handle);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
		}

		return $contents_only ? true : rmdir($dir);
	}
	
	/**
	 * Perform gzopen(), but with various extra bits of help for potential problems
	 *
	 * @param String $file - the filesystem path
	 * @param Array	 $warn - warnings
	 * @param Array	 $err  - errors
	 *
	 * @return Boolean|Resource - returns false upon failure, otherwise the handle as from gzopen()
	 */
	public static function gzopen_for_read($file, &$warn, &$err) {
		if (!function_exists('gzopen') || !function_exists('gzread')) {
			$missing = '';
			if (!function_exists('gzopen')) $missing .= 'gzopen';
			if (!function_exists('gzread')) $missing .= ($missing) ? ', gzread' : 'gzread';
			/* translators: %s: List of disabled PHP functions. */
			$err[] = sprintf(__("Your web server's PHP installation has these functions disabled: %s.", 'updraftplus'), $missing).' '.
			sprintf(
				/* translators: %s: The process that requires the functions. */
				__('Your hosting company must enable these functions before %s can work.', 'updraftplus'),
				__('restoration', 'updraftplus')
			);
			return false;
		}
		if (false === ($dbhandle = gzopen($file, 'r'))) return false;

		if (!function_exists('gzseek')) return $dbhandle;

		if (false === ($bytes = gzread($dbhandle, 3))) return false;
		// Double-gzipped?
		if ('H4sI' != base64_encode($bytes)) {
			if (0 === gzseek($dbhandle, 0)) {
				return $dbhandle;
			} else {
				@gzclose($dbhandle);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
				return gzopen($file, 'r');
			}
		}
		// Yes, it's double-gzipped

		$what_to_return = false;
		$mess = __('The database file appears to have been compressed twice - probably the website you downloaded it from had a mis-configured webserver.', 'updraftplus');
		$messkey = 'doublecompress';
		$err_msg = '';

		if (false === ($fnew = fopen($file.".tmp", 'w')) || !is_resource($fnew)) {

			@gzclose($dbhandle);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
			$err_msg = __('The attempt to undo the double-compression failed.', 'updraftplus');

		} else {

			@fwrite($fnew, $bytes);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
			$emptimes = 0;
			while (!gzeof($dbhandle)) {
				$bytes = @gzread($dbhandle, 262144);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
				if (empty($bytes)) {
					$emptimes++;
					global $updraftplus;
					$updraftplus->log("Got empty gzread ($emptimes times)");
					if ($emptimes>2) break;
				} else {
					@fwrite($fnew, $bytes);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
				}
			}

			gzclose($dbhandle);
			fclose($fnew);
			// On some systems (all Windows?) you can't rename a gz file whilst it's gzopened
			if (!rename($file.".tmp", $file)) {
				$err_msg = __('The attempt to undo the double-compression failed.', 'updraftplus');
			} else {
				$mess .= ' '.__('The attempt to undo the double-compression succeeded.', 'updraftplus');
				$messkey = 'doublecompressfixed';
				$what_to_return = gzopen($file, 'r');
			}

		}

		$warn[$messkey] = $mess;
		if (!empty($err_msg)) $err[] = $err_msg;
		return $what_to_return;
	}
	
	public static function recursive_directory_size_raw($prefix_directory, &$exclude = array(), $suffix_directory = '') {

		$directory = $prefix_directory.('' == $suffix_directory ? '' : '/'.$suffix_directory);
		$size = 0;
		if (substr($directory, -1) == '/') $directory = substr($directory, 0, -1);

		if (!file_exists($directory) || !is_dir($directory) || !is_readable($directory)) return -1;
		if (file_exists($directory.'/.donotbackup')) return 0;

		if ($handle = opendir($directory)) {
			while (($file = readdir($handle)) !== false) {
				if ('.' != $file && '..' != $file) {
					$spath = ('' == $suffix_directory) ? $file : $suffix_directory.'/'.$file;
					if (false !== ($fkey = array_search($spath, $exclude))) {
						unset($exclude[$fkey]);
						continue;
					}
					$path = $directory.'/'.$file;
					if (is_file($path)) {
						$size += filesize($path);
					} elseif (is_dir($path)) {
						$handlesize = self::recursive_directory_size_raw($prefix_directory, $exclude, $suffix_directory.('' == $suffix_directory ? '' : '/').$file);
						if ($handlesize >= 0) {
							$size += $handlesize;
						}
					}
				}
			}
			closedir($handle);
		}

		return $size;

	}

	/**
	 * Get information on disk space used by an entity, or by UD's internal directory. Returns as a human-readable string.
	 *
	 * @param String $entity - the entity (e.g. 'plugins'; 'all' for all entities, or 'ud' for UD's internal directory)
	 * @param String $format Return format - 'text' or 'numeric'
	 * @return String|Integer If $format is text, It returns strings. Otherwise integer value.
	 */
	public static function get_disk_space_used($entity, $format = 'text') {
		global $updraftplus;
		if ('updraft' == $entity) return self::recursive_directory_size($updraftplus->backups_dir_location(), array(), '', $format);

		$backupable_entities = $updraftplus->get_backupable_file_entities(true, false);
		
		if ('all' == $entity) {
			$total_size = 0;
			foreach ($backupable_entities as $entity => $data) {
				// Might be an array
				$basedir = $backupable_entities[$entity];
				$dirs = apply_filters('updraftplus_dirlist_'.$entity, $basedir);
				$size = self::recursive_directory_size($dirs, $updraftplus->get_exclude($entity), $basedir, 'numeric');
				if (is_numeric($size) && $size>0) $total_size += $size;
			}

			if ('numeric' == $format) {
				return $total_size;
			} else {
				return UpdraftPlus_Manipulation_Functions::convert_numeric_size_to_text($total_size);
			}
			
		} elseif (!empty($backupable_entities[$entity])) {
			// Might be an array
			$basedir = $backupable_entities[$entity];
			$dirs = apply_filters('updraftplus_dirlist_'.$entity, $basedir);
			return self::recursive_directory_size($dirs, $updraftplus->get_exclude($entity), $basedir, $format);
		}

		// Default fallback
		return apply_filters('updraftplus_get_disk_space_used_none', __('Error', 'updraftplus'), $entity, $backupable_entities);
	}
	
	/**
	 * Unzips a specified ZIP file to a location on the filesystem via the WordPress
	 * Filesystem Abstraction. Forked from WordPress core in version 5.1-alpha-44182,
	 * to allow us to provide feedback on progress.
	 *
	 * Assumes that WP_Filesystem() has already been called and set up. Does not extract
	 * a root-level __MACOSX directory, if present.
	 *
	 * Attempts to increase the PHP memory limit before uncompressing. However,
	 * the most memory required shouldn't be much larger than the archive itself.
	 *
	 * @global WP_Filesystem_Base $wp_filesystem WordPress filesystem subclass.
	 *
	 * @param string  $file                    - Full path and filename of ZIP archive.
	 * @param string  $to                      - Full path on the filesystem to extract archive to.
	 * @param integer $starting_index          - index of entry to start unzipping from (allows resumption)
	 * @param array   $folders_to_look         - an array of folders that want to be extracted or not. It can contain:
	 *                                           * The names of the second-level folders. For example: '2025'.
	 *                                           * The relative paths of the folders. For example: '2025/12'.
	 * @param string  $extract_matched_folders - the value is either 'extract_only' or 'extract_except'.
	 *                                           * If the value is 'extract_only', then it'll extract only files in the '$folders_to_look' parameter.
	 *                                           * If the value is 'extract_except', then it'll extract all files except the ones in the '$folders_to_look' parameter.
	 *
	 * @return boolean|WP_Error True on success, WP_Error on failure.
	 */
	public static function unzip_file($file, $to, $starting_index = 0, $folders_to_look = array(), $extract_matched_folders = 'extract_only') {
		global $wp_filesystem;

		if (!$wp_filesystem || !is_object($wp_filesystem)) {
			return new WP_Error('fs_unavailable', __('Could not access filesystem.'));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
		}

		// Unzip can use a lot of memory, but not this much hopefully.
		if (function_exists('wp_raise_memory_limit')) wp_raise_memory_limit('admin');

		$needed_dirs = array();
		$to = trailingslashit($to);

		// Determine any parent dir's needed (of the upgrade directory)
		if (!$wp_filesystem->is_dir($to)) { // Only do parents if no children exist
			$path = preg_split('![/\\\]!', untrailingslashit($to));
			for ($i = count($path); $i >= 0; $i--) {
			
				if (empty($path[$i])) continue;

				$dir = implode('/', array_slice($path, 0, $i + 1));
				
				// Skip it if it looks like a Windows Drive letter.
				if (preg_match('!^[a-z]:$!i', $dir)) continue;

				// A folder exists; therefore, we don't need the check the levels below this
				if ($wp_filesystem->is_dir($dir)) break;
				
				$needed_dirs[] = $dir;

			}
		}

		static $added_unzip_action = false;
		if (!$added_unzip_action) {
			add_action('updraftplus_unzip_file_unzipped', array('UpdraftPlus_Filesystem_Functions', 'unzip_file_unzipped'), 10, 5);
			$added_unzip_action = true;
		}
		
		if (class_exists('ZipArchive', false) && apply_filters('unzip_file_use_ziparchive', true)) {
			$result = self::unzip_file_go($file, $to, $needed_dirs, 'ziparchive', $starting_index, $folders_to_look, $extract_matched_folders);
			if (true === $result || (is_wp_error($result) && 'incompatible_archive' != $result->get_error_code())) return $result;
			if (is_wp_error($result)) {
				global $updraftplus;
				$updraftplus->log("ZipArchive returned an error (will try again with PclZip): ".$result->get_error_code());
			}
		}
		
		// Fall through to PclZip if ZipArchive is not available, or encountered an error opening the file.
		// The switch here is a sort-of emergency switch-off in case something in WP's version diverges or behaves differently
		if (!defined('UPDRAFTPLUS_USE_INTERNAL_PCLZIP') || UPDRAFTPLUS_USE_INTERNAL_PCLZIP) {
			return self::unzip_file_go($file, $to, $needed_dirs, 'pclzip', $starting_index, $folders_to_look, $extract_matched_folders);
		} else {
			return _unzip_file_pclzip($file, $to, $needed_dirs);
		}
	}
	
	/**
	 * Called upon the WP action updraftplus_unzip_file_unzipped, to indicate that a file has been unzipped.
	 *
	 * @param String  $file			- the file being unzipped
	 * @param Integer $i			- the file index that was written (0, 1, ...)
	 * @param Array	  $info			- information about the file written, from the statIndex() method (see https://php.net/manual/en/ziparchive.statindex.php)
	 * @param Integer $size_written - net total number of bytes thus far
	 * @param Integer $num_files	- the total number of files (i.e. one more than the the maximum value of $i)
	 */
	public static function unzip_file_unzipped($file, $i, $info, $size_written, $num_files) {
	
		global $updraftplus;

		static $last_file_seen = null;

		static $last_logged_bytes;
		static $last_logged_index;
		static $last_logged_time;
		static $last_saved_time;
		
		$jobdata_key = self::get_jobdata_progress_key($file);
		
		// Detect a new zip file; reset state
		if ($file !== $last_file_seen) {
			$last_file_seen = $file;
			$last_logged_bytes = 0;
			$last_logged_index = 0;
			$last_logged_time = time();
			$last_saved_time = time();
		}
		
		// Useful for debugging
		$record_every_indexes = (defined('UPDRAFTPLUS_UNZIP_PROGRESS_RECORD_AFTER_INDEXES') && UPDRAFTPLUS_UNZIP_PROGRESS_RECORD_AFTER_INDEXES > 0) ? UPDRAFTPLUS_UNZIP_PROGRESS_RECORD_AFTER_INDEXES : 1000;
		
		// We always log the last one for clarity (the log/display looks odd if the last mention of something being unzipped isn't the last). Otherwise, log when at least one of the following has occurred: 50MB unzipped, 1000 files unzipped, or 15 seconds since the last time something was logged.
		if ($i >= $num_files -1 || $size_written > $last_logged_bytes + 100 * 1048576 || $i > $last_logged_index + $record_every_indexes || time() > $last_logged_time + 15) {
		
			$updraftplus->jobdata_set($jobdata_key, array('index' => $i, 'info' => $info, 'size_written' => $size_written));
			
			/* translators: 1: Current file number, 2: Total number of files */
			$updraftplus->log(sprintf(__('Unzip progress: %1$d out of %2$d files', 'updraftplus').' (%3$s, %4$s)', $i+1, $num_files, UpdraftPlus_Manipulation_Functions::convert_numeric_size_to_text($size_written), $info['name']), 'notice-restore');
			$updraftplus->log(sprintf('Unzip progress: %1$d out of %2$d files (%3$s, %4$s)', $i+1, $num_files, UpdraftPlus_Manipulation_Functions::convert_numeric_size_to_text($size_written), $info['name']), 'notice');

			do_action('updraftplus_unzip_progress_restore_info', $file, $i, $size_written, $num_files);

			$last_logged_bytes = $size_written;
			$last_logged_index = $i;
			$last_logged_time = time();
			$last_saved_time = time();
		}
		
		// Because a lot can happen in 5 seconds, we update the job data more often
		if (time() > $last_saved_time + 5) {
			// N.B. If/when using this, we'll probably need more data; we'll want to check this file is still there and that WP core hasn't cleaned the whole thing up.
			$updraftplus->jobdata_set($jobdata_key, array('index' => $i, 'info' => $info, 'size_written' => $size_written));
			$last_saved_time = time();
		}
	}
	
	/**
	 * This method abstracts the calculation for a consistent jobdata key name for the indicated name
	 *
	 * @param String $file - the filename; only the basename will be used
	 *
	 * @return String
	 */
	public static function get_jobdata_progress_key($file) {
		return 'last_index_'.md5(basename($file));
	}
	
	/**
	 * Compatibility function (exists in WP 4.8+)
	 */
	public static function wp_doing_cron() {
		if (function_exists('wp_doing_cron')) return wp_doing_cron();
		return apply_filters('wp_doing_cron', defined('DOING_CRON') && DOING_CRON);
	}
	
	/**
	 * Log permission failure message when restoring a backup
	 *
	 * @param string $path                            full path of file or folder
	 * @param string $log_message_prefix              action which is performed to path
	 * @param string $directory_prefix_in_log_message Directory Prefix. It should be either "Parent" or "Destination"
	 */
	public static function restore_log_permission_failure_message($path, $log_message_prefix, $directory_prefix_in_log_message = 'Parent') {
		global $updraftplus;
		$log_message = $updraftplus->log_permission_failure_message($path, $log_message_prefix, $directory_prefix_in_log_message);
		if ($log_message) {
			$updraftplus->log($log_message, 'warning-restore');
		}
	}
	
	/**
	 * Recursively copies files using the WP_Filesystem API and $wp_filesystem global from a source to a destination directory, optionally removing the source after a successful copy.
	 *
	 * @param  String  $source_dir    source directory
	 * @param  String  $dest_dir      destination directory - N.B. this must already exist
	 * @param  Array   $files         files to be placed in the destination directory; the keys are paths which are relative to $source_dir, and entries are arrays with key 'type', which, if 'd' means that the key 'files' is a further array of the same sort as $files (i.e. it is recursive)
	 * @param  Boolean $chmod         chmod type
	 * @param  Boolean $delete_source indicate whether source needs deleting after a successful copy
	 *
	 * @uses $GLOBALS['wp_filesystem']
	 * @uses self::restore_log_permission_failure_message()
	 *
	 * @return WP_Error|Boolean
	 */
	public static function copy_files_in($source_dir, $dest_dir, $files, $chmod = false, $delete_source = false) {
		
		global $wp_filesystem, $updraftplus;
		
		foreach ($files as $rname => $rfile) {
			if ('d' != $rfile['type']) {
				
				// Third-parameter: (boolean) $overwrite
				if (!$wp_filesystem->move($source_dir.'/'.$rname, $dest_dir.'/'.$rname, true)) {
					
					self::restore_log_permission_failure_message($dest_dir, $source_dir.'/'.$rname.' -> '.$dest_dir.'/'.$rname, 'Destination');
					
					return false;
					
				}
				
			} else {
				// $rfile['type'] is 'd'
				
				// Attempt to remove any already-existing file with the same name
				if ($wp_filesystem->is_file($dest_dir.'/'.$rname)) @$wp_filesystem->delete($dest_dir.'/'.$rname, false, 'f');// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- if fails, carry on
				
				// No such directory yet: just move it
				if ($wp_filesystem->exists($dest_dir.'/'.$rname) && !$wp_filesystem->is_dir($dest_dir.'/'.$rname) && !$wp_filesystem->move($source_dir.'/'.$rname, $dest_dir.'/'.$rname, false)) {
					
					self::restore_log_permission_failure_message($dest_dir, 'Move '.$source_dir.'/'.$rname.' -> '.$dest_dir.'/'.$rname, 'Destination');
					$updraftplus->log_e('Failed to move directory (check your file permissions and disk quota): %s', $source_dir.'/'.$rname." -&gt; ".$dest_dir.'/'.$rname);
					
					return false;
					
				} elseif (!empty($rfile['files'])) {
					
					if (!$wp_filesystem->exists($dest_dir.'/'.$rname)) $wp_filesystem->mkdir($dest_dir.'/'.$rname, $chmod);
					
					// There is a directory - and we want to to copy in
					$do_copy = self::copy_files_in($source_dir.'/'.$rname, $dest_dir.'/'.$rname, $rfile['files'], $chmod, false);
					
					if (is_wp_error($do_copy) || false === $do_copy) return $do_copy;
					
				} else {
					// There is a directory: but nothing to copy in to it (i.e. $file['files'] is empty). Just remove the directory.
					@$wp_filesystem->rmdir($source_dir.'/'.$rname);// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the method.
				}
			}
		}
		
		// We are meant to leave the working directory empty. Hence, need to rmdir() once a directory is empty. But not the root of it all in case of others/wpcore.
		if ($delete_source || false !== strpos($source_dir, '/')) {
			if (!$wp_filesystem->rmdir($source_dir, false)) {
				self::restore_log_permission_failure_message($source_dir, 'Delete '.$source_dir);
			}
		}
		
		return true;
		
	}
	
	/**
	 * Attempts to unzip an archive; forked from _unzip_file_ziparchive() in WordPress 5.1-alpha-44182, and modified to use the UD zip classes.
	 *
	 * Assumes that WP_Filesystem() has already been called and set up.
	 *
	 * @global WP_Filesystem_Base $wp_filesystem WordPress filesystem subclass.
	 *
	 * @param string  $file                    - full path and filename of ZIP archive.
	 * @param string  $to                      - full path on the filesystem to extract archive to.
	 * @param array	  $needed_dirs             - a partial list of required folders needed to be created.
	 * @param string  $method                  - either 'ziparchive' or 'pclzip'.
	 * @param integer $starting_index          - index of entry to start unzipping from (allows resumption)
	 * @param array   $folders_to_look         - an array of folders that want to be extracted or not. It can contain:
	 *                                           * The names of the second-level folders. For example: '2025'.
	 *                                           * The relative paths of the folders. For example: '/2025/12'.
	 * @param string  $extract_matched_folders - the value is either 'extract_only' or 'extract_except'.
	 *                                           * If the value is 'extract_only', then it'll extract only files in the '$folders_to_look' parameter.
	 *                                           * If the value is 'extract_except', then it'll extract all files except the ones in the '$folders_to_look' parameter.
	 *
	 * @return boolean|WP_Error True on success, WP_Error on failure.
	 */
	private static function unzip_file_go($file, $to, $needed_dirs = array(), $method = 'ziparchive', $starting_index = 0, $folders_to_look = array(), $extract_matched_folders = 'extract_only') {
		global $wp_filesystem, $updraftplus;
		
		$class_to_use = ('ziparchive' == $method) ? 'UpdraftPlus_ZipArchive' : 'UpdraftPlus_PclZip';
		
		// Check if the current filesystem is case-sensitive
		$case_sensitive_filesystem = self::really_is_writable($to, true);

		if (!class_exists($class_to_use)) updraft_try_include_file('includes/class-zip.php', 'require_once');
		
		$updraftplus->log('Unzipping '.basename($file).' to '.$to.' using '.$class_to_use.', starting index '.$starting_index);
		
		$z = new $class_to_use;

		$flags = (version_compare(PHP_VERSION, '5.2.12', '>') && defined('ZIPARCHIVE::CHECKCONS')) ? ZIPARCHIVE::CHECKCONS : 4;
		
		// This is just for crazy people with mbstring.func_overload enabled (deprecated from PHP 7.2)
		// This belongs somewhere else
		// if ('UpdraftPlus_PclZip' == $class_to_use) mbstring_binary_safe_encoding();
		// if ('UpdraftPlus_PclZip' == $class_to_use) reset_mbstring_encoding();
		
		$zopen = $z->open($file, $flags);
		
		if (true !== $zopen) {
			return new WP_Error('incompatible_archive', __('Incompatible Archive.'), array($method.'_error' => $z->last_error));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
		}

		$uncompressed_size = 0;

		$num_files = $z->numFiles;

		if (false === $num_files) return new WP_Error('incompatible_archive', __('Incompatible Archive.'), array($method.'_error' => $z->last_error));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
		
		for ($i = $starting_index; $i < $num_files; $i++) {
			if (!$info = $z->statIndex($i)) {
				return new WP_Error('stat_failed_'.$method, __('Could not retrieve file from archive.').' ('.$z->last_error.')');// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
			}

			// Skip the OS X-created __MACOSX directory
			if ('__MACOSX/' === substr($info['name'], 0, 9)) continue;

			// Don't extract invalid files:
			if (0 !== validate_file($info['name'])) continue;

			if (!empty($folders_to_look)) {
				// Don't create folders that we want to exclude
				$path = trim(UpdraftPlus_Manipulation_Functions::wp_normalize_path($info['name']), '/');
				$path = strstr($path, '/');
				$folder_matches_given_path = self::is_path_in_files((string) $path, $folders_to_look, $case_sensitive_filesystem);
				if (('extract_only' === $extract_matched_folders && !$folder_matches_given_path) || ('extract_except' === $extract_matched_folders && $folder_matches_given_path)) continue;
			}

			$uncompressed_size += $info['size'];

			if ('/' === substr($info['name'], -1)) {
				// Directory.
				$needed_dirs[] = $to . untrailingslashit($info['name']);
			} elseif ('.' !== ($dirname = dirname($info['name']))) {
				// Path to a file.
				$needed_dirs[] = $to . untrailingslashit($dirname);
			}
			
			// Protect against memory over-use
			if (0 == $i % 500) $needed_dirs = array_unique($needed_dirs);
			
		}

		/*
		* disk_free_space() could return false. Assume that any falsey value is an error.
		* A disk that has zero free bytes has bigger problems.
		* Require we have enough space to unzip the file and copy its contents, with a 10% buffer.
		*/
		if (self::wp_doing_cron()) {
			$available_space = function_exists('disk_free_space') ? @disk_free_space(WP_CONTENT_DIR) : false;// phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Call is speculative
			if ($available_space && ($uncompressed_size * 2.1) > $available_space) {
				return new WP_Error('disk_full_unzip_file', __('Could not copy files.').' '.__('You may have run out of disk space.'), compact('uncompressed_size', 'available_space'));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
			}
		}

		$needed_dirs = array_unique($needed_dirs);
		foreach ($needed_dirs as $dir) {
			// Check the parent folders of the folders all exist within the creation array.
			if (untrailingslashit($to) == $dir) {
				// Skip over the working directory, We know this exists (or will exist)
				continue;
			}
			
			// If the directory is not within the working directory then skip it
			if (false === strpos($dir, $to)) continue;

			$parent_folder = dirname($dir);
			while (!empty($parent_folder) && untrailingslashit($to) != $parent_folder && !in_array($parent_folder, $needed_dirs)) {
				$needed_dirs[] = $parent_folder;
				$parent_folder = dirname($parent_folder);
			}
		}
		asort($needed_dirs);

		// Create those directories if need be:
		foreach ($needed_dirs as $_dir) {
			// Only check to see if the Dir exists upon creation failure. Less I/O this way.
			if (!$wp_filesystem->mkdir($_dir, FS_CHMOD_DIR) && !$wp_filesystem->is_dir($_dir)) {
				return new WP_Error('mkdir_failed_'.$method, __('Could not create directory.'), substr($_dir, strlen($to)));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
			}
		}
		unset($needed_dirs);

		$size_written = 0;
		
		$content_cache = array();
		$content_cache_highest = -1;

		for ($i = $starting_index; $i < $num_files; $i++) {

			if (!$info = $z->statIndex($i)) {
				return new WP_Error('stat_failed_'.$method, __('Could not retrieve file from archive.'));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
			}

			// directory
			if ('/' == substr($info['name'], -1)) continue;

			// Don't extract the OS X-created __MACOSX
			if ('__MACOSX/' === substr($info['name'], 0, 9)) continue;

			// Don't extract invalid files:
			if (0 !== validate_file($info['name'])) continue;

			if (!empty($folders_to_look)) {
				// Don't extract folders that we want to exclude
				$path = trim(UpdraftPlus_Manipulation_Functions::wp_normalize_path($info['name']), '/');
				$path = strstr($path, '/', false); // phpcs:ignore PHPCompatibility.FunctionUse.NewFunctionParameters.strstr_before_needleFound -- The third param ($before_needle) of the strstr function doesn't exist on PHP 5.2, but we don't longer support PHP 5.2.
				$folder_matches_given_path = self::is_path_in_files((string) $path, $folders_to_look, $case_sensitive_filesystem);
				if (('extract_only' === $extract_matched_folders && !$folder_matches_given_path) || ('extract_except' === $extract_matched_folders && $folder_matches_given_path)) continue;
			}

			$is_stream_extract = false;

			// N.B. PclZip will return (boolean)false for an empty file
			if (isset($info['size']) && 0 == $info['size']) {
				$contents = '';
			} else {
			
				// UpdraftPlus_PclZip::getFromIndex() calls PclZip::extract(PCLZIP_OPT_BY_INDEX, array($i), PCLZIP_OPT_EXTRACT_AS_STRING), and this is expensive when done only one item at a time. We try to cache in chunks for good performance as well as being able to resume.
				if ($i > $content_cache_highest && 'UpdraftPlus_PclZip' == $class_to_use) {

					$memory_usage = memory_get_usage(false);
					$total_memory = $updraftplus->memory_check_current();
				
					if ($memory_usage > 0 && $total_memory > 0) {
						$memory_free = $total_memory*1048576 - $memory_usage;
					} else {
						// A sane default. Anything is ultimately better than WP's default of just unzipping everything into memory.
						$memory_free = 50*1048576;
					}
					
					$use_memory = max(10485760, $memory_free - 10485760);

					$total_byte_count = 0;
					$content_cache = array();
					$cache_indexes = array();
					
					$cache_index = $i;
					while ($cache_index < $num_files && $total_byte_count < $use_memory) {
						if (false !== ($cinfo = $z->statIndex($cache_index)) && isset($cinfo['size']) && '/' != substr($cinfo['name'], -1) && '__MACOSX/' !== substr($cinfo['name'], 0, 9) && 0 === validate_file($cinfo['name'])) {
							$total_byte_count += $cinfo['size'];
							if ($total_byte_count < $use_memory) {
								$cache_indexes[] = $cache_index;
								$content_cache_highest = $cache_index;
							}
						}
						$cache_index++;
					}

					if (!empty($cache_indexes)) {
						$content_cache = $z->updraftplus_getFromIndexBulk($cache_indexes);
					}
				}

				if (isset($content_cache[$i])) {
					$contents = $content_cache[$i];
				} elseif ($updraftplus->verify_free_memory($info['size'] * 1.2)) {
					$contents = $z->getFromIndex($i);
				} else {
					// Use streaming extraction when remaining PHP memory is insufficient for in-memory extraction (ZIP + inflate overhead).
					if ('UpdraftPlus_PclZip' == $class_to_use) {
						$extract_result = $z->extract($to, $info['name']);
						if (!$extract_result) return new WP_Error('extract_failed_'.$method, __('Could not extract file from archive.'));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
					} else {
						$stream = $z->getStream($info['name']);
						if ($stream) {
							$handle = fopen($to.$info['name'], 'w');
							if (false === $handle) {
								fclose($stream);
								return new WP_Error('extract_failed_'.$method, __('Could not extract file from archive.'));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
							}

							while (!feof($stream)) {
								// 512KB chunks
								if (false === fwrite($handle, fread($stream, 524288))) return new WP_Error('extract_failed_'.$method, __('Could not extract file from archive.'));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
							}

							fclose($handle);
							fclose($stream);
						}
					}
					$is_stream_extract = true;
				}
			}
			
			if (!$is_stream_extract && false === $contents && ('pclzip' !== $method || 0 !== $info['size'])) {
				return new WP_Error('extract_failed_'.$method, __('Could not extract file from archive.').' '.$z->last_error, json_encode($info));// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
			}

			if (!$is_stream_extract && !$wp_filesystem->put_contents($to . $info['name'], $contents, FS_CHMOD_FILE)) {
				return new WP_Error('copy_failed_'.$method, __('Could not copy file.'), $info['name']);// phpcs:ignore WordPress.WP.I18n.MissingArgDomain -- The string exists within the WordPress core.
			}

			if (!empty($info['size'])) $size_written += $info['size'];

			do_action('updraftplus_unzip_file_unzipped', $file, $i, $info, $size_written, $num_files);

		}

		$z->close();

		return true;
	}

	/**
	 * Recursively scan and delete files located in a directory whose modification time is considered older than a given time
	 *
	 * @param string  $working_dir   - An absolute path of working directory that will be scanned.
	 * @param integer $timestamp     - The timestamp to compare with the files' modified time. Files will be deleted if the modified time is older than this timestamp.
	 * @param array   $paths_to_keep - An array of folder or file absolute paths that we want to keep.
	 *
	 * @return void
	 */
	public static function delete_files_by_age($working_dir, $timestamp, $paths_to_keep = array()) {
		global $updraftplus;

		$dir = dir($working_dir);
		if (!$dir) {
			$updraftplus->log("Cannot access the $working_dir directory.", 'notice', false, true);
			return;
		}

		static $depth_level = 0;
		static $total_deleted = 0;
		
		if (0 === $depth_level) $total_deleted = 0;

		$depth_level++;
		while (false !== ($filename = $dir->read())) {
			if ('.' === $filename || '..' === $filename) continue;

			$result = null;
			$filepath = UpdraftPlus_Manipulation_Functions::wp_normalize_path($working_dir.'/'.$filename);
			$file_mtime = @filemtime($filepath); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise because of the function.
			if (is_dir($filepath)) self::delete_files_by_age($filepath, $timestamp, $paths_to_keep);

			if (false === $file_mtime) {
				$updraftplus->log("Unable to get the '$filepath' modification time.", 'notice', false, true);
				continue;
			}
			
			// Keep file that is inside the paths that we want to keep or whose modification time is considered newer than a given time.
			if (self::is_path_in_files($filepath, $paths_to_keep) || $file_mtime >= $timestamp) continue;
			
			if (is_dir($filepath)) {
				// Delete the empty folder
				$result = @rmdir($filepath); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the folder isn't empty.
			} else {
				// Delete the file whose modified time is older than the given timestamp
				$result = @unlink($filepath); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- Silenced to suppress errors that may arise if the file doesn't exist or we don't have sufficient permission to it.
			}

			if (!isset($result)) continue;

			if ($result) {
				$total_deleted++;
			} else {
				$reason = (is_dir($filepath)) ? "The directory isn't empty." : "The file doesn't exist, or you don't have sufficient permission to it.";
				$updraftplus->log("Cannot delete '$filepath'. $reason", 'notice', false, true);
			}

			if ($total_deleted > 0 && 0 === $total_deleted % 100) {
				$updraftplus->log("$total_deleted files deleted.", 'notice', false, true);
			}
		}

		$depth_level--;

		if (0 === $depth_level && $total_deleted % 100 > 0) $updraftplus->log("$total_deleted files deleted.", 'notice', false, true);
	}

	/**
	 * Check if a given path matches with any files/folders in the list (case sensitive)
	 * NOTE: Since the given path can be a file or folder hence a check might be required if a boolean true is returned by this method.
	 * The check can also be done before calling and passing the path into this method.
	 *
	 * @param string  $path           - The path of a folder or file that want to be checked.
	 * @param array   $files          - The list of files and/or folders that want to be checked.
	 * @param boolean $case_sensitive - Whether or not the filesystem is case-sensitive.
	 *
	 * @return boolean True if the path matches with any folder in the list, false otherwise
	 */
	private static function is_path_in_files($path, $files, $case_sensitive = false) {
		$path = trim(UpdraftPlus_Manipulation_Functions::wp_normalize_path($path), '/');
		$path = ($case_sensitive) ? $path : strtolower($path);
		foreach ($files as $file) {
			$file = trim(UpdraftPlus_Manipulation_Functions::wp_normalize_path($file), '/');
			$file = ($case_sensitive) ? $file : strtolower($file);
			$path_parts = explode('/', $path);
			$file_parts = explode('/', $file);
			array_splice($path_parts, count($file_parts));
			if ($path_parts === $file_parts) return true;
		}
		return false;
	}
}
