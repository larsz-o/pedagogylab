<?php
/**
 * Utils class file.
 *
 * @package automattic/jetpack-ip
 */

namespace Automattic\Jetpack\IP;

/**
 * Class that provides static methods for working with IP addresses.
 */
class Utils {

	const PACKAGE_VERSION = '0.8.0';

	/**
	 * Get the current user's IP address.
	 *
	 * @return string|false IP address.
	 */
	public static function get_ip() {
		$remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- clean_ip does it.
		$ip          = self::get_ip_from_trusted_header( $remote_addr );
		if ( $ip ) {
			return $ip;
		}

		return self::pick_ip( $remote_addr, 1, false, $remote_addr );
	}

	/**
	 * Whether the request carries the configured trusted header but `get_ip()` couldn't take an
	 * address from it, so it fell back to `REMOTE_ADDR`.
	 *
	 * @since 0.8.0
	 *
	 * @return bool
	 */
	public static function is_trusted_header_unresolved() {
		return false === self::get_ip_from_trusted_header( null );
	}

	/**
	 * Read the address from the configured trusted header.
	 *
	 * @param string|null $short_list_fallback Address to use when the header has fewer entries than the configured segments.
	 * @return string|false|null IP address, false if the header yields no valid address, or null if no header is configured or the request lacks it.
	 */
	private static function get_ip_from_trusted_header( $short_list_fallback ) {
		$trusted_header_data = get_site_option( 'trusted_ip_header' );
		if ( ! isset( $trusted_header_data->trusted_header ) || ! isset( $_SERVER[ $trusted_header_data->trusted_header ] ) ) {
			return null;
		}

		// The stored header setting can go stale, leaving the header empty, too short, or without a valid address.
		return self::pick_ip(
			wp_unslash( $_SERVER[ $trusted_header_data->trusted_header ] ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- clean_ip does it.
			$trusted_header_data->segments ?? 1,
			! empty( $trusted_header_data->reverse ),
			$short_list_fallback
		);
	}

	/**
	 * Pick one address out of a comma-separated list.
	 *
	 * @param string|null $value         Raw list of addresses.
	 * @param int         $segments      Which entry to use, counted from the end of the list.
	 * @param bool        $reverse_order Whether to reverse the list first.
	 * @param string|null $fallback      Address to use when the list has fewer entries than `$segments`.
	 * @return string|false IP address.
	 */
	private static function pick_ip( $value, $segments, $reverse_order, $fallback ) {
		if ( ! $value ) {
			return false;
		}

		$ips = explode( ',', $value );
		if ( ! $segments ) {
			$segments = 1;
		}
		if ( $reverse_order ) {
			$ips = array_reverse( $ips );
		}
		$ip_count = count( $ips );
		if ( 1 === $ip_count ) {
			return self::clean_ip( $ips[0] );
		} elseif ( $ip_count >= $segments ) {
			return self::clean_ip( $ips[ $ip_count - $segments ] );
		}
		return $fallback ? self::clean_ip( $fallback ) : false;
	}

	/**
	 * Clean IP address.
	 *
	 * @param string $ip The IP address to clean.
	 * @return string|false The cleaned IP address.
	 */
	public static function clean_ip( $ip ) {

		// Some misconfigured servers give back extra info, which comes after "unless".
		$ips = explode( ' unless ', $ip );
		$ip  = $ips[0];

		$ip = strtolower( trim( $ip ) );

		// Check for IPv4 with port.
		if ( preg_match( '/^(\d+\.\d+\.\d+\.\d+):\d+$/', $ip, $matches ) ) {
			$ip = $matches[1];
		}

		// Check for IPv6 (or IPvFuture) with brackets and optional port.
		if ( preg_match( '/^\[([a-z0-9\-._~!$&\'()*+,;=:]+)\](?::\d+)?$/', $ip, $matches ) ) {
			$ip = $matches[1];
		}

		// Check for IPv4 IP cast as IPv6.
		if ( preg_match( '/^::ffff:(\d+\.\d+\.\d+\.\d+)$/', $ip, $matches ) ) {
			$ip = $matches[1];
		}

		// Validate and return.
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : false;
	}

	/**
	 * Checks an IP to see if it is within a private range.
	 *
	 * @param string $ip IP address.
	 * @return bool  True if IP address is private, false otherwise.
	 */
	public static function ip_is_private( $ip ) {
		// We are dealing with ipv6, so we can simply rely on filter_var.
		// Note: str_contains() is not used here, as wp-includes/compat.php may not be loaded in this file.
		if ( false === strpos( $ip, '.' ) ) {
			return ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
		}
		// We are dealing with ipv4.
		$private_ip4_addresses = array(
			'10.0.0.0|10.255.255.255',     // Single class A network.
			'172.16.0.0|172.31.255.255',   // 16 contiguous class B network.
			'192.168.0.0|192.168.255.255', // 256 contiguous class C network.
			'169.254.0.0|169.254.255.255', // Link-local address also referred to as Automatic Private IP Addressing.
			'127.0.0.0|127.255.255.255',    // localhost.
		);
		$long_ip               = ip2long( $ip );
		if ( -1 !== $long_ip ) {
			foreach ( $private_ip4_addresses as $pri_addr ) {
				list ( $start, $end ) = explode( '|', $pri_addr );
				if ( $long_ip >= ip2long( $start ) && $long_ip <= ip2long( $end ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks whether an IP address is a public, globally-routable destination.
	 *
	 * Stricter than the inverse of ip_is_private(): on top of private and reserved
	 * ranges it also rejects the IPv4 special-use ranges PHP's reserved-range
	 * filter leaves open (CGNAT, IETF protocol assignments, 6to4 relay anycast,
	 * benchmarking, multicast), the Azure metadata "Wire Server" address, and IPv6
	 * link-local / unique-local / site-local ranges. IPv6 addresses that embed an
	 * IPv4 address (IPv4-mapped ::ffff:0:0/96, IPv4-compatible ::/96, NAT64
	 * 64:ff9b::/96, and 6to4 2002::/16) are decoded to that IPv4 and re-checked, so
	 * the embedded IPv4 is classified the same way whether or not it is wrapped.
	 *
	 * @param string $ip IP address (IPv4, IPv6, or IPv4-mapped IPv6; any IPv6 zone id is ignored).
	 * @return bool True when the address is a safe public destination, false otherwise.
	 */
	public static function ip_is_public( $ip ) {
		if ( ! is_string( $ip ) || '' === $ip ) {
			return false;
		}

		// Strip an IPv6 zone identifier (e.g. fe80::1%eth0). Zone ids are only valid
		// on IPv6 addresses, so a '%' on anything else (e.g. "8.8.8.8%foo") is malformed.
		if ( false !== strpos( $ip, '%' ) ) {
			if ( false === strpos( $ip, ':' ) ) {
				return false;
			}
			$ip = preg_replace( '/%.*$/', '', $ip );
		}

		// Decode IPv6 forms that embed an IPv4 address to that IPv4 and check it,
		// so the embedded IPv4 is classified the same way whether or not it is wrapped.
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$binary = inet_pton( $ip );
			if ( false !== $binary && 16 === strlen( $binary ) ) {
				$prefix12 = substr( $binary, 0, 12 );
				$embedded = null;

				if (
					"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff" === $prefix12 // IPv4-mapped ::ffff:0:0/96.
					|| "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00" === $prefix12 // IPv4-compatible ::/96 (incl. ::, ::1).
					|| "\x00\x64\xff\x9b\x00\x00\x00\x00\x00\x00\x00\x00" === $prefix12 // NAT64 64:ff9b::/96.
				) {
					$embedded = substr( $binary, 12, 4 );
				} elseif ( "\x20\x02" === substr( $binary, 0, 2 ) ) {
					// 6to4 2002::/16: the embedded IPv4 gateway is in bytes 2-5.
					$embedded = substr( $binary, 2, 4 );
				}

				if ( null !== $embedded ) {
					$mapped = inet_ntop( $embedded );
					if ( is_string( $mapped ) ) {
						$ip = $mapped;
					}
				}
			}
		}

		// Reject anything that is not a valid, non-private, non-reserved address.
		if ( false === filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return false;
		}

		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			// IPv4 special-use ranges the reserved-range filter above leaves open.
			$blocked_ranges = array(
				array( '100.64.0.0', '100.127.255.255' ),   // CGNAT (RFC 6598).
				array( '168.63.129.16', '168.63.129.16' ),  // Azure metadata "Wire Server".
				array( '169.254.0.0', '169.254.255.255' ),  // Link-local, incl. cloud metadata.
				array( '192.0.0.0', '192.0.0.255' ),         // IETF protocol assignments (RFC 6890).
				array( '192.88.99.0', '192.88.99.255' ),     // 6to4 relay anycast (RFC 7526).
				array( '198.18.0.0', '198.19.255.255' ),     // Benchmarking (RFC 2544).
				array( '224.0.0.0', '239.255.255.255' ),     // Multicast (RFC 5771).
			);
			foreach ( $blocked_ranges as $range ) {
				if ( self::ip_address_is_in_range( $ip, $range[0], $range[1] ) ) {
					return false;
				}
			}
			return true;
		}

		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$binary = inet_pton( $ip );
			if ( false === $binary || strlen( $binary ) < 2 ) {
				return false;
			}
			$first = unpack( 'n', $binary )[1];

			// fe80::/10 link-local and fec0::/10 site-local (deprecated).
			if ( 0xfe80 === ( $first & 0xffc0 ) || 0xfec0 === ( $first & 0xffc0 ) ) {
				return false;
			}
			// fc00::/7 unique local addresses.
			if ( 0xfc00 === ( $first & 0xfe00 ) ) {
				return false;
			}
			return true;
		}

		return false;
	}

	/**
	 * Checks whether a URL is a safe destination for a server-side request.
	 *
	 * The URL must pass wp_http_validate_url(), which rejects IPv6-literal hosts, and every
	 * address its host resolves to must pass ip_is_public(). A host that resolves to none fails.
	 * Not covered: redirect hops (check each one), DNS rebinding, or AAAA records without ext-dns.
	 *
	 * @since 0.7.0
	 *
	 * @param string $url URL to check.
	 * @return bool True when the URL is safe to request, false otherwise.
	 */
	public static function url_is_public( $url ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return false;
		}

		$validated_url = wp_http_validate_url( $url );
		if ( ! $validated_url ) {
			return false;
		}

		$host = wp_parse_url( $validated_url, PHP_URL_HOST );
		if ( ! is_string( $host ) || '' === $host ) {
			return false;
		}

		$ips = self::resolve_host_ips( $host );

		// Fail closed: an unresolvable host is not assumed safe.
		if ( empty( $ips ) ) {
			return false;
		}

		foreach ( $ips as $ip ) {
			if ( ! self::ip_is_public( $ip ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Resolves a host to the distinct IPv4 and IPv6 addresses a request to it could reach.
	 *
	 * IP literals are returned as-is. An empty list means the host is malformed or resolved
	 * to nothing, and callers must treat it as unsafe.
	 *
	 * @since 0.7.0
	 *
	 * @param string $host Host name or IP literal (IPv6 literals may be bracketed).
	 * @return string[] List of IP addresses.
	 */
	public static function resolve_host_ips( $host ) {
		if ( ! is_string( $host ) || '' === $host ) {
			return array();
		}

		// Unwrap one bracket pair only, so "]8.8.8.8[" can't become a clean address.
		if ( preg_match( '/^\[(.*)\]$/', $host, $matches ) ) {
			$host = $matches[1];
		}

		// Decode so "169%2e254%2e169%2e254" can't slip past the checks below.
		$host = rawurldecode( $host );

		// Strip an IPv6 zone id ("fe80::1%eth0"); a '%' on any other host is malformed.
		if ( false !== strpos( $host, '%' ) ) {
			if ( false === strpos( $host, ':' ) ) {
				return array();
			}
			$host = preg_replace( '/%.*$/', '', $host );
		}

		/*
		 * Reject control bytes (gethostbynamel() throws on a NUL), stray brackets, and
		 * raw non-ASCII, which the request layer would punycode into a different host.
		 */
		if ( '' === $host || preg_match( '/[\x00-\x20\x7f-\xff\[\]]/', $host ) ) {
			return array();
		}

		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return array( $host );
		}

		$ips = array();

		if ( function_exists( 'gethostbynamel' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- gethostbynamel() warns on an unresolvable host.
			$ipv4 = @gethostbynamel( $host );
			if ( is_array( $ipv4 ) ) {
				$ips = $ipv4;
			}
		}

		// gethostbynamel() only resolves IPv4; check AAAA records too. dns_get_record()
		// can be disabled on some hosts and may warn on lookup failure.
		if ( function_exists( 'dns_get_record' ) ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- dns_get_record may fail on some systems.
			$aaaa = @dns_get_record( $host, DNS_AAAA );
			if ( is_array( $aaaa ) ) {
				foreach ( $aaaa as $record ) {
					if ( ! empty( $record['ipv6'] ) ) {
						$ips[] = $record['ipv6'];
					}
				}
			}
		}

		// Drop anything a resolver returned that is not an IP address.
		$ips = array_filter(
			$ips,
			function ( $ip ) {
				return is_string( $ip ) && false !== filter_var( $ip, FILTER_VALIDATE_IP );
			}
		);

		return array_values( array_unique( $ips ) );
	}

	/**
	 * Validate an IP address.
	 *
	 * @param string $ip IP address.
	 * @return bool True if valid, false otherwise.
	 */
	private static function validate_ip_address( string $ip ) {
		return filter_var( $ip, FILTER_VALIDATE_IP );
	}

	/**
	 * Validate an array of IP addresses.
	 *
	 * @param array $ips List of IP addresses.
	 * @return bool True if all IPs are valid, false otherwise.
	 */
	private static function validate_ip_addresses( array $ips ) {
		foreach ( $ips as $ip ) {
			if ( ! self::validate_ip_address( $ip ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Uses inet_pton if available to convert an IP address to a binary string.
	 * Returns false if an invalid IP address is given.
	 *
	 * @param mixed $ip IP address.
	 * @return int|string|bool
	 */
	public static function convert_ip_address( $ip ) {
		return inet_pton( $ip );
	}

	/**
	 * Determines the IP version of the given IP address.
	 *
	 * @param string $ip IP address.
	 * @return string|false 'ipv4', 'ipv6', or false if invalid.
	 */
	public static function get_ip_version( $ip ) {
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return 'ipv4';
		} elseif ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			return 'ipv6';
		} else {
			return false;
		}
	}

	/**
	 * Extracts IP addresses from a given string.
	 *
	 * Supports IPv4 and IPv6 ranges in both hyphen and CIDR notation.
	 *
	 * @param string $ips List of IPs.
	 * @return array List of valid IP addresses or ranges.
	 */
	public static function get_ip_addresses_from_string( $ips ) {
		// Split the string by spaces, commas, and semicolons.
		$ips = preg_split( '/[\s,;]/', (string) $ips );

		$result = array();

		foreach ( $ips as $ip ) {
			$ip = trim( $ip );

			// Check for CIDR notation
			if ( strpos( $ip, '/' ) !== false ) {
				if ( self::validate_cidr( $ip ) ) {
					$result[] = $ip;
				}
				continue;
			}

			// Validate both IP values from the hyphen range.
			$range = explode( '-', $ip );
			if ( count( $range ) === 2 ) {
				if ( self::validate_ip_range( $range[0], $range[1] ) ) {
					$result[] = $ip;
				}
				continue;
			}

			// Validate the single IP value.
			if ( filter_var( $ip, FILTER_VALIDATE_IP ) !== false ) {
				$result[] = $ip;
			}
		}

		return $result;
	}

	/**
	 * Validates CIDR notation for IPv4 and IPv6 addresses.
	 *
	 * @param string $cidr CIDR notation IP address.
	 * @return bool True if valid, false otherwise.
	 */
	public static function validate_cidr( $cidr ) {
		// Split the CIDR notation into IP address and prefix length using the '/' separator.
		$parts = explode( '/', $cidr );
		if ( count( $parts ) !== 2 ) {
			return false; // Invalid CIDR notation if it doesn't contain exactly one '/'.
		}

		list( $ip, $netmask ) = $parts;

		// Validate the IP address.
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		$ip_version = self::get_ip_version( $ip );
		if ( ! $ip_version ) {
			return false; // Invalid IP address.
		}

		// Validate the netmask based on the IP version.
		if ( ! self::validate_netmask( $netmask, $ip_version ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Checks if an IP address is within a CIDR range.
	 * Supports both IPv4 and IPv6.
	 *
	 * @param string $ip   IP address.
	 * @param string $cidr CIDR notation IP range.
	 * @return bool True if IP is within the range, false otherwise.
	 */
	public static function ip_in_cidr( $ip, $cidr ) {
		// Parse the CIDR notation to extract the base IP address and netmask prefix length.
		$parsed_cidr = self::parse_cidr( $cidr );
		if ( ! $parsed_cidr ) {
			return false;
		}
		list( $range, $netmask ) = $parsed_cidr;

		// Determine the IP version (IPv4 or IPv6) of both the input IP and the CIDR range IP.
		$ip_version    = self::get_ip_version( $ip );
		$range_version = self::get_ip_version( $range );

		// Ensure both IP addresses are valid and of the same IP version.
		if ( ! $ip_version || ! $range_version || $ip_version !== $range_version ) {
			return false;
		}

		// Validate the netmask based on the IP version.
		if ( ! self::validate_netmask( $netmask, $ip_version ) ) {
			return false;
		}

		if ( $ip_version === 'ipv4' ) {
			return self::ip_in_ipv4_cidr( $ip, $range, $netmask );
		} else {
			return self::ip_in_ipv6_cidr( $ip, $range, $netmask );
		}
	}

	/**
	 * Parses the CIDR notation into network address and netmask.
	 *
	 * @param string $cidr CIDR notation IP range.
	 * @return array|false Array containing network address and netmask, or false on failure.
	 */
	public static function parse_cidr( $cidr ) {
		$cidr_parts = explode( '/', $cidr, 2 );
		if ( count( $cidr_parts ) !== 2 ) {
			return false; // Invalid CIDR notation
		}
		list( $range, $netmask ) = $cidr_parts;

		// Determine IP version
		$ip_version = self::get_ip_version( $range );
		if ( ! $ip_version ) {
			return false; // Invalid IP address
		}

		// Validate netmask range
		if ( ! self::validate_netmask( $netmask, $ip_version ) ) {
			return false; // Netmask out of range
		}

		return array( $range, (int) $netmask );
	}

	/**
	 * Validates the netmask based on IP version.
	 *
	 * @param string|int $netmask    Netmask value.
	 * @param string     $ip_version 'ipv4' or 'ipv6'.
	 * @return bool True if valid, false otherwise.
	 */
	public static function validate_netmask( $netmask, $ip_version ) {
		// Ensure that $netmask is an integer
		if ( ! ctype_digit( (string) $netmask ) ) {
			return false;
		}
		$netmask = (int) $netmask;

		// Validate the netmask based on the IP version.
		if ( $ip_version === 'ipv4' ) {
			return ( $netmask >= 0 && $netmask <= 32 );
		} elseif ( $ip_version === 'ipv6' ) {
			return ( $netmask >= 0 && $netmask <= 128 );
		} else {
			return false;
		}
	}

	/**
	 * Checks if an IPv4 address is within a CIDR range.
	 *
	 * @param string $ip      IPv4 address to check.
	 * @param string $range   IPv4 network address.
	 * @param int    $netmask Netmask value.
	 * @return bool True if IP is within the range, false otherwise.
	 */
	public static function ip_in_ipv4_cidr( $ip, $range, $netmask ) {
		// Validate arguments.
		if ( ! self::validate_ip_addresses( array( $ip, $range ) ) || ! self::validate_netmask( $netmask, 'ipv4' ) ) {
			return false; // Invalid IP address or netmask.
		}

		// Convert IP addresses from their dotted representation to 32-bit unsigned integers.
		$ip_long    = ip2long( $ip );
		$range_long = ip2long( $range );

		// Check if the conversion was successful.
		if ( $ip_long === false || $range_long === false ) {
			return false; // One of the IP addresses is invalid.
		}

		/**
		 * Create the subnet mask as a 32-bit unsigned integer.
		 *
		 * Explanation:
		 * - (32 - $netmask) calculates the number of host bits (the bits not used for the network address).
		 * - (1 << (32 - $netmask)) shifts the number 1 left by the number of host bits.
		 *   This results in a number where there is a single 1 followed by zeros equal to the number of host bits.
		 * - Subtracting 1 gives us a number where the host bits are all 1s.
		 * - Applying the bitwise NOT operator (~) inverts the bits, turning all host bits to 0 and network bits to 1.
		 *   This results in the subnet mask having 1s in the network portion and 0s in the host portion.
		 *
		 * Example for netmask = 24:
		 * - (32 - 24) = 8
		 * - (1 << 8) = 256 (binary: 00000000 00000000 00000001 00000000)
		 * - 256 - 1 = 255 (binary: 00000000 00000000 00000000 11111111)
		 * - ~255 = 4294967040 (binary: 11111111 11111111 11111111 00000000)
		 */
		$mask = ~ ( ( 1 << ( 32 - $netmask ) ) - 1 );

		/**
		 * Use bitwise AND to apply the subnet mask to both the IP address and the network address.
		 * - ($ip_long & $mask) isolates the network portion of the IP address.
		 * - ($range_long & $mask) isolates the network portion of the CIDR range.
		 * - If both network portions are equal, the IP address belongs to the same subnet and is within the CIDR range.
		 */
		return ( $ip_long & $mask ) === ( $range_long & $mask );
	}

	/**
	 * Checks if an IPv6 address is within a CIDR range.
	 *
	 * @param string $ip      IPv6 address to check.
	 * @param string $range   IPv6 network address.
	 * @param int    $netmask Netmask value.
	 * @return bool True if IP is within the range, false otherwise.
	 */
	public static function ip_in_ipv6_cidr( $ip, $range, $netmask ) {
		// Validate arguments.
		if ( ! self::validate_ip_addresses( array( $ip, $range ) ) || ! self::validate_netmask( $netmask, 'ipv6' ) ) {
			return false; // Invalid IP address or netmask.
		}

		// Convert IP addresses from their textual representation to binary strings.
		$ip_bin    = inet_pton( $ip );
		$range_bin = inet_pton( $range );

		// Check if the conversion was successful.
		if ( $ip_bin === false || $range_bin === false ) {
			return false; // One of the IP addresses is invalid.
		}

		/**
		 * Calculate the subnet mask in binary form.
		 *
		 * IPv6 addresses are 128 bits long.
		 * The netmask defines how many bits are set to 1 in the subnet mask.
		 *
		 * - $netmask_full_bytes: Number of full bytes (each 8 bits) that are all 1s.
		 * - $netmask_remainder_bits: Remaining bits (less than 8) that need to be set to 1.
		 *
		 * For example, if $netmask = 65:
		 * - $netmask_full_bytes = floor(65 / 8) = 8 (since 8 * 8 = 64 bits)
		 * - $netmask_remainder_bits = 65 % 8 = 1 (1 bit remaining)
		 *
		 * We'll construct the subnet mask by:
		 * - Starting with $netmask_full_bytes of 0xff (11111111 in binary).
		 * - Adding a byte where the first $netmask_remainder_bits bits are 1, rest are 0.
		 * - Padding the rest with zeros to make it 16 bytes (128 bits) long.
		 */

		// Number of full bytes (each full byte is 8 bits) in the netmask.
		$netmask_full_bytes = (int) ( $netmask / 8 );

		// Number of remaining bits in the last byte of the netmask.
		$netmask_remainder_bits = $netmask % 8;

		// Start with a string of $netmask_full_bytes of 0xff bytes (each byte is 8 bits set to 1).
		$netmask_bin = str_repeat( "\xff", $netmask_full_bytes );

		if ( $netmask_remainder_bits > 0 ) {
			// Create the last byte with $netmask_remainder_bits bits set to 1 from the left.
			// - str_repeat('1', $netmask_remainder_bits): creates a string with the required number of '1's.
			// - str_pad(...): pads the string on the right with '0's to make it 8 bits.
			// - bindec(...): converts the binary string to a decimal number.
			// - chr(...): gets the character corresponding to the byte value.
			$last_byte = chr( bindec( str_pad( str_repeat( '1', $netmask_remainder_bits ), 8, '0', STR_PAD_RIGHT ) ) );
			// Append the last byte to the netmask binary string.
			$netmask_bin .= $last_byte;
		}

		// Pad the netmask binary string to 16 bytes (128 bits) with zeros (\x00).
		$netmask_bin = str_pad( $netmask_bin, 16, "\x00" );

		/**
		 * Use bitwise AND to apply the subnet mask to both the IP address and the network address.
		 * - ($ip_bin & $netmask_bin) isolates the network portion of the IP address.
		 * - ($range_bin & $netmask_bin) isolates the network portion of the CIDR range.
		 * - If both network portions are equal, the IP address belongs to the same subnet and is within the CIDR range.
		 */
		return ( $ip_bin & $netmask_bin ) === ( $range_bin & $netmask_bin );
	}

	/**
	 * Validates the low and high IP addresses of a range.
	 *
	 * Now supports IPv6 addresses.
	 *
	 * @param string $range_low  Low IP address.
	 * @param string $range_high High IP address.
	 * @return bool True if the range is valid, false otherwise.
	 */
	public static function validate_ip_range( $range_low, $range_high ) {
		// Validate that both IP addresses are valid.
		if ( self::validate_ip_addresses( array( $range_low, $range_high ) ) === false ) {
			return false;
		}

		// Ensure both IPs are of the same version
		$range_low_ip_version  = self::get_ip_version( $range_low );
		$range_high_ip_version = self::get_ip_version( $range_high );

		if ( $range_low_ip_version !== $range_high_ip_version || ! $range_low_ip_version || ! $range_high_ip_version ) {
			return false; // Invalid or mixed IP versions.
		}

		// Convert IP addresses to their packed binary representation.
		$ip_low  = inet_pton( $range_low );
		$ip_high = inet_pton( $range_high );

		// Check if the conversion was successful.
		if ( false === $ip_low || false === $ip_high ) {
			return false;
		}

		// Compare the binary representations to ensure the low IP is not greater than the high IP.
		if ( strcmp( $ip_low, $ip_high ) > 0 ) {
			return false;
		}

		return true;
	}

	/**
	 * Checks that a given IP address is within a given range.
	 *
	 * Supports CIDR notation and hyphenated ranges for both IPv4 and IPv6.
	 *
	 * @param string      $ip        IP address.
	 * @param string      $range_low Range low or CIDR notation.
	 * @param null|string $range_high Optional. Range high. Not used if $range_low is CIDR notation.
	 * @return bool
	 */
	public static function ip_address_is_in_range( $ip, $range_low, $range_high = null ) {
		// Validate that all provided IP addresses are valid.
		if ( $range_high !== null && ! self::validate_ip_addresses( array( $ip, $range_low, $range_high ) ) ) {
			return false;
		} else {
			$range_low_parsed = self::parse_cidr( $range_low );
			if ( $range_low_parsed && ! self::validate_ip_addresses( array( $ip, $range_low_parsed[0] ) ) ) {
				return false;
			}
		}

		if ( strpos( $range_low, '/' ) !== false ) {
			// CIDR notation
			if ( $range_high !== null ) {
				// Invalid usage: CIDR notation with range high parameter
				return false;
			}
			return self::ip_in_cidr( $ip, $range_low );
		}

		// Hyphenated range
		if ( $range_high === null ) {
			return false; // Invalid parameters
		}

		$ip_num  = inet_pton( $ip );
		$ip_low  = inet_pton( $range_low );
		$ip_high = inet_pton( $range_high );
		if ( $ip_num && $ip_low && $ip_high && strcmp( $ip_num, $ip_low ) >= 0 && strcmp( $ip_num, $ip_high ) <= 0 ) {
			return true;
		}
		return false;
	}
}
