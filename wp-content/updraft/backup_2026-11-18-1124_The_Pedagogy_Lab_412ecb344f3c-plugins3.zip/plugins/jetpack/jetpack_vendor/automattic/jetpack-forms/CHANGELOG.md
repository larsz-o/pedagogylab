# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [8.4.0] - 2026-11-16
### Added
- Add a `wp jetpack-forms export` command that exports form responses to CSV. [#54219]
- Join the admin shell, so switching to and from other Jetpack dashboards skips the page load when the admin shell flag is on. [#54708]

### Changed
- Admin shell: Declare the page title and subtitle shown while the dashboard opens, when the admin shell flag is on. [#54945]
- Show a progress indicator and a notice while exporting responses. [#54219]
- Update package dependencies. [#54703]

### Fixed
- Apply Global Styles label settings to form labels, including the group label on multiple-choice fields. The Outlined and Animated styles keep their own label weight. [#51905]
- Fix exporting to Google Sheets when a response has a very long value, and say when an export is too large for Google Sheets. [#54219]
- Fix running out of memory when exporting a large number of responses to CSV or Google Drive. [#54219]
- Inbox: Show "Anonymous" for responses with no author details, and hide the IP address row when no IP was recorded. [#53925]
- Keep text typed with a Japanese, Chinese, or Korean input method in a choice option when Enter confirms the conversion. [#54691]

## [8.3.8] - 2026-11-09
### Changed
- Describe the plugin install button and the IP lookup link to screen readers. [#54512]
- Update package dependencies. [#54391] [#54512]
- Use the design system tooltip in the form editor and the responses dashboard. [#54512]

### Fixed
- Form editor: Label the embed code and shortcode snippets in the sidebar for screen readers and add usage hints. [#54353]

## [8.3.7] - 2026-11-02
### Changed
- Update package dependencies. [#53869] [#54382] [#54390]

### Fixed
- Fix the class attribute on field wrappers that use the inset label layout. [#54426]

## [8.3.6] - 2026-10-28
### Changed
- Update package dependencies. [#54118]

## [8.3.5] - 2026-10-26
### Changed
- Block editor: Report that the Forms module is off when the form block is unavailable, so the editor can say why. [#53257]
- Dashboard: Open on the remembered tab without a server-side redirect, saving a page load on every visit. [#53752]

### Deprecated
- Dashboard: Deprecate Dashboard::get_default_tab(), as the dashboard now picks its opening tab client-side. [#53752]

### Fixed
- Dashboard: Send sites without Central Form Management from the Forms list to the inbox even while settings are still loading. [#53752]

## [8.3.4] - 2026-10-19
### Changed
- Update package dependencies. [#53004] [#53675] [#53806]
- Use apply_shortcodes() terminology instead of do_shortcode(). [#53552]

### Fixed
- Fix a PHP warning and broken form when a contact form shortcode is nested inside another one. [#53603]
- Form editor: Add labels and usage hints to the embed code and shortcode fields in the "add it to a page" dialog. [#53664]

## [8.3.3] - 2026-10-12
### Changed
- Update package dependencies. [#53223]

### Fixed
- Contact Form: Keep brackets in submitted values escaped, so they cannot run shortcodes, on WordPress versions with the new HTML sanitizer. [#53335]
- Dashboard: Fix error notices shown after deleting or trashing a form, even though it succeeded. [#53164]

## [8.3.2] - 2026-10-12
### Changed
- Internal updates.

## [8.3.1] - 2026-10-12
### Fixed
- Restore scrolling on the standalone single response page.

## [8.3.0] - 2026-10-05
### Added
- Add conditional logic to form fields, available on WordPress.com Business plans and higher and on all Jetpack sites. [#52783]

### Changed
- Make the Delete spam button act on the selected responses or the current filter, show how many responses it will delete, and delete large queues in chunks with progress. [#48130]
- Update package dependencies. [#52999]

### Fixed
- Dashboard: Start the Delete permanently and Mark as spam confirmations on Cancel, so pressing Enter no longer permanently deletes a form or marks a response as spam. [#53027]
- Dashboard: Start the Empty trash and Delete spam confirmations on Cancel and show Delete in red, so pressing Enter no longer permanently deletes every response in that folder. [#52979]

## [8.2.2] - 2026-09-29
### Fixed
- Dashboard: Stop logging a console error about missing Jetpack configuration. [#52809]

## [8.2.1] - 2026-09-28
### Changed
- Dashboard: Replace experimental layout and text components with their `@wordpress/ui` equivalents. [#52492]

### Fixed
- Detect Jetpack CRM installs that use a custom plugin folder or file name. [#52725]
- Remove the duplicate divider between the dashboard header and the tabs. [#52641]
- Rating field: Cap the scale when rendering a form or a response so a malformed value cannot exhaust memory. [#52007]
- Show Jetpack in-dashboard messages on the Forms dashboard. [#52641]

### Removed
- Dashboard: Remove an unused integrations modal. [#52492]

## [8.2.0] - 2026-09-21
### Added
- Conditional logic: Add a "Done" button to the rules dialog. [#52347]

### Changed
- Conditional logic: Open the Conditional logic panel by default on a field that has conditions. [#52347]
- Dashboard: Reopen on the last tab used instead of always the default. [#52249]
- Exclude source map files from the distributed package. [#52304]
- Update package dependencies. [#52187]

### Deprecated
- Dashboard: Deprecate `Dashboard::SCRIPT_HANDLE`. [#52296]

### Removed
- Dashboard: Remove the legacy dashboard code and the deprecated `Dashboard_View_Switch` class. [#52296]

### Fixed
- Dashboard: Open the Forms tab when it is requested directly instead of falling back to Responses. [#52249]

## [8.1.0] - 2026-09-15
### Changed
- Form editor: Add additional analytics to welcome guide. [#52148]
- Hide the Forms sidebar item when Forms is not active. [#52156]
- Update package dependencies. [#52105] [#52297]

### Deprecated
- Dashboard: Deprecate the `jetpack_forms_alpha` filter, which no longer selects anything. [#51395]

### Fixed
- Dashboard: Restore the missing border on the responses comment panel. [#52152]
- Prevent extra forms from being created when the block placeholder is clicked more than once. [#52099]
- Stop the Forms data stores from logging a duplicate registration error in the browser console. [#52153]

## [8.0.3] - 2026-09-09
### Changed
- Sidebar: Sort Jetpack menu items alphabetically, pinning My Jetpack to the top and external links and Settings to the bottom. [#52003]

## [8.0.2] - 2026-09-09
### Fixed
- Responses: Restore multi-page printing of a single response. [#52096]
- Responses: Scroll a single response from the page edge instead of from inside the reading column. [#52096]

## [8.0.1] - 2026-09-08
### Changed
- Update package dependencies. [#51701]

### Fixed
- Add an empty alt attribute to the image option thumbnails in the form success summary. [#51781]
- Hide the Lead Capture pattern on WordPress.com, matching the block variation that is already hidden there. [#51857]
- Keep editor-initialized defaults from marking imported forms as changed. [#52053]
- Load active module state before the editor module store. [#51888]

## [8.0.0] - 2026-09-01
### Added
- Add help text to form fields, and show the date field's expected format below the input instead of in its label. Preserve help text across field transformations and form details, and fix field descriptions for inset-label styles. [#51122]
- File upload field: Allow a field to accept more than one file. [#51551]
- Form editor: Record when the welcome guide is shown, stepped through, and dismissed. [#51668]
- Form editor: Replace the generic block editor welcome modal with a guide to the form editor. [#51039]
- Responses: Remember which columns are shown, and their order, for each form. [#51615]

### Changed
- CSV export will now handle `\"` sequences per RFC 4180. [#51572]
- Dashboard: Rewrite the missing forms modal to reassure people that forms already on their pages keep working, and spell out the steps to add them to the list. [#47568]
- File upload field: Rebuild the field on the same foundation as the other form fields, so it behaves consistently with them. Markup cached from an earlier release keeps working for one release. [#51183]
- Make form navigation actions real links so they can be opened in a new tab. [#51563]
- Update package dependencies. [#51303] [#51802]

### Removed
- Minimum supported PHP version is now 7.4. [#51515]

### Fixed
- Conditional logic: Explain when fields share a Name/ID rather than offering them as conditions that cannot be told apart. [#51617]
- Conditional logic: Fix the rules dialog not opening from the block toolbar while the settings sidebar is closed. [#51617]
- Conditional logic: Name a checkbox by its own label in the conditions dropdown, keep a value typed before the field was chosen, and show an unticked checkbox as "No" rather than a blank. [#51417]
- Contact Form: Bind the posted form id to the signed form when validating a token-authenticated submission. [#51510]
- Date field: Let screen readers announce the field's own label instead of the date picker instructions. [#51406]
- File upload field: Cancel in-flight uploads and release previews when the form is reset. [#51183]
- File upload field: Fix several problems with adding more than one file at once, and with uploads that stall or fail. [#51549]
- File upload field: Keep the remaining files when a folder or dragged text is included in a multi-file drop. [#51183]
- File upload field: Remove a file from the form immediately instead of waiting for the server, so a slow connection no longer leaves the field looking stuck. [#51183]
- File upload field: Stop uploading a file that was removed while its upload was still being prepared. [#51183]
- Fix checkbox and consent field alignment in the editor on classic themes. [#51560]
- Form editor: Fix the welcome guide artwork not loading on WordPress.com Simple sites. [#51682]
- Inbox: Space out the files listed on a response and line their download buttons up on one edge. [#51734]
- Keep an option's label when switching it to the "Other" option. [#51628]
- Keep prev/next working on a single response after marking it as spam or trash, open responses instantly from the list, and add keyboard shortcuts for triaging responses. [#51670]
- Phone field: Validate a required field with a default country against what the input actually shows, so it can no longer be submitted empty. [#51183]
- Prevent a new choice option from inheriting the previous option's label when pressing Enter. [#51628]
- Responses: Keep one column per form field when a field is moved, and read every answer from the field it belongs to. [#51615]
- Restore the Integrations button in the Form block toolbar when the settings sidebar is closed. [#51630]

## [7.26.0] - 2026-08-25
### Added
- Responses: Show each form field as a column when viewing a single form's responses. [#51448]

### Changed
- Responses: On small screens, show only the response and its actions instead of a table that scrolls sideways. [#51448]
- Responses: On small screens, the View action now opens the response the same way tapping its title does. [#51486]
- Show progress while a new form's editor opens, and report it when creating a form fails. [#51371]

### Fixed
- Apply the name typed when creating a form, and stop a dismissed save from reporting into a reopened dialog. [#51371]
- Contact Form: Remove the classic-theme editor margin between a field's label and its input. [#51527]
- Responses: Allow a single response to scroll when it is taller than the screen. [#51486]
- Responses: Prevent an error that could stop responses from loading when a file upload field was stored without any file data. [#51485]

## [7.25.0] - 2026-08-20
### Added
- Add a Print action to form responses, which opens the response on its own page and prints just the response. [#51368]
- Add conditional logic to form fields, so any field can be shown or hidden based on another field's answer. Disabled by default while in testing; enable it with the forms-conditional-logic feature flag. [#50938]
- Contact Form: Add background image support to the Form and Step blocks. [#50975]
- Feedback author avatars: Pick a stable Color Studio background color per email for initials identity avatars via `bg_color`. [#50578]

### Changed
- Responses: Open a response on its own page from the list's View action and from both response notification email buttons, and keep the user on that page when a response is marked as spam or trashed. [#51127]
- Update package dependencies. [#51125] [#51399]

### Fixed
- Contact Form: Make Group and Columns blocks fill the form width so nested fields render full-width. [#51266]
- Dashboard: Keep response field icons and formatting after marking a response as spam. [#51288]
- Dashboard: Show an explanation instead of a blank page when the dashboard assets are missing. [#51151]
- Fix the first change made to a form after opening a page being discarded when saving. [#51393]
- Form preview: Label the admin bar edit link "Edit Form" instead of "Edit Page". [#51235]
- Grouped field labels: Lower the legend padding reset so themes and global styles can override it. [#51187]
- Multistep forms: Keep step padding within the form width. [#50975]
- Prevent a fatal error when logging webhook responses with unexpected header types. [#51156]
- Rating field: Keep the default left-aligned, borderless rendering under the Outlined and Animated form styles. [#51126]
- Responses: Preserve line breaks in multi-line answers. [#51369]
- Show an empty checkbox icon next to checkbox fields the respondent left unchecked, instead of always showing a ticked one. [#51293]
- Slider field: Keep the default label when the form uses the Outlined or Animated style, so the label no longer overlaps the slider track. [#51124]

## [7.24.0] - 2026-08-10
### Security
- Contact Form: Improve sanitization of content submitted through the file field.

### Added
- Add form fill duration to form entries. [#45786]

### Changed
- Add the site ID and Jetpack version to the response email open tracking event. [#51102]
- Update package dependencies. [#50509] [#51008]

### Fixed
- Ensure the submit button inside a Form renders as a button element so forms saved without an explicit element can still be submitted. [#51046]
- Form block: Show the fallback notification recipient as a placeholder so it is clear when no address is saved. [#51014]
- Form editor: Keep the form block selected so the form settings sidebar stays reachable. [#51047]

## [7.23.4] - 2026-08-03
### Removed
- Dashboard: Remove redundant workaround for a dashboard loading edge case now fixed in bundled dependencies. No functional change. [#50780]

### Fixed
- Keep responses readable when a field label, submitted value, or page title contains a "<" character. [#50817]
- Load JS translation catalogs and stamp the package text domain on the wp-build dashboard bundles. [#50762]

## [7.23.3] - 2026-07-27
### Changed
- Update dependencies. [#50719]
- Update package dependencies. [#50717] [#50751] [#50753] [#50792]

## [7.23.2] - 2026-07-20
### Changed
- Update package dependencies. [#50510] [#50529]

## [7.23.1] - 2026-07-13
### Changed
- Forms now reports its unread count to the central menu-badges registry instead of writing admin-menu markup directly. [#50190]
- Update package dependencies. [#49272] [#50234] [#50407]
- Update WPDS design tokens to the @wordpress/theme 0.16/0.17 names (see https://github.com/WordPress/gutenberg/blob/trunk/packages/theme/CHANGELOG.md#0160-2026-06-24 ). [#49272]

### Removed
- Remove unused react-redux, redux, and redux-thunk dependencies. [#50282]

### Fixed
- Block editor: Surface the most common fields (Name, Email, Text…) first in the form's block inserter instead of burying them past the quick-inserter cutoff. [#50425]
- Contact Form: Restore the listView block support so form fields can be managed from the editor List View (regressed when block attributes were ported to block.json metadata). [#50463]
- Feedback: Parse versionless JSON `post_content` as JSON instead of falling through to the legacy plain-text parser. [#50380]
- Fix an invalid Stack "gap" value ("s" -> "sm") in the single-response actions bar, surfaced as a type error by the @wordpress/ui update. [#49272]
- Fix the Form Responses quick link disappearing from the admin bar on mobile viewports, and align its icon with the native items. [#50421]
- Stop loading the unused legacy dashboard SPA bundle on the new (wp-build) Forms dashboard. [#50219]

## [7.23.0] - 2026-07-06
### Added
- Warn admins and editors when a form isn't collecting responses (email and saving both off, no integration) in the editor, on the live form, and in the dashboard. [#49808]
- Responses: Add a standalone full-page view for a single form response. [#49827]

### Changed
- Update package dependencies. [#50097] [#50183]

### Fixed
- Date field: Prevent the on-screen keyboard from appearing on mobile when tapping the date picker; show the date picker instead. [#50211]
- Disable the per-viewport "Hide on…" visibility control on form field, input, and choice/option blocks, since it was not honored on the frontend. [#49973]
- File upload: Fix the file upload field collapsing to its content width on the front end instead of filling the form like it does in the editor. [#49978]
- Multistep forms: Fix navigation buttons floating and the button gap collapsing on the frontend when a button width is set. [#49939]
- Responses: Update the unread response count in the admin sidebar immediately when a response is marked as read by viewing it, so the badge no longer requires a page refresh to reflect the change. [#50187]

## [7.22.6] - 2026-06-29
### Security
- Restrict status counts to a user's own forms when they cannot edit others' forms. [#49929]

### Changed
- Update package dependencies. [#49271]

### Fixed
- Restore webhook, Post to URL and Salesforce delivery for forms placed in block templates, template parts and widgets, which stopped firing in 15.9. [#49861]

## [7.22.5] - 2026-06-25
### Changed
- Update package dependencies. [#49831]

### Fixed
- Fix a `@wordpress/ui` 0.15 type error in the responses dashboard. [#49800]

## [7.22.4] - 2026-06-22
### Changed
- Update package dependencies. [#49631] [#49638] [#49691] [#49757]

## [7.22.3] - 2026-06-15
### Changed
- Update package dependencies. [#49492]

### Fixed
- Post to URL: Prevent a fatal TypeError when a form's legacy `hiddenFields` attribute is stored as a name => value map or JSON string. [#49539]

## [7.22.2] - 2026-06-09
### Changed
- Hide the Jetpack footer across on the Forms list and Responses views wp-build Forms dashboard. [#49432]
- Update package dependencies. [#49273]

### Fixed
- Fix preg_match TypeError when a URL field value is an array instead of a string. [#49323]
- Ensure the feedback REST collection endpoint never returns posts of unrelated types when the invalid_ids filter is in use.
- Harden the legacy Salesforce post-to-URL path and route the request through the WordPress safe HTTP API.
- Improve sanitization of class and style attribute values, and submitted values across the package.
- Restrict webhook and integration configuration to users with the manage_options capability.
- Tighten the permission check on the bulk-delete-by-status feedback endpoint.

## [7.22.1] - 2026-06-08
### Changed
- Update dependencies. [#49354]
- Update package dependencies. [#49379]

### Fixed
- Include the routes directory in the TypeScript config and fix type errors in the dashboard route files. [#49368]

## [7.22.0] - 2026-06-01
### Changed
- Update empty state to use component from @wordpress/ui. [#47908]
- Update package dependencies. [#48404] [#49152] [#49154]

### Fixed
- Dashboard: Align the header logo with the page title, pin the footer to the bottom of the viewport, and keep the tabs and search controls on a single row on desktop. [#49246]

## [7.21.3] - 2026-05-25
### Added
- Abilities: Opt all 8 Forms abilities into the MCP tool surface (meta.mcp public tool). [#49113]

### Changed
- Update package dependencies. [#48405] [#49012]

### Removed
- Remove dead legacy grunion assets: `grunion-admin.js`, `grunion-frontend.js`, `grunion-admin.css`, and 13 unused images. [#47609]

### Fixed
- Address `Uncaught TypeError` message in the editor. [#48979]
- Fix unread submissions counter badge colors in the admin sidebar. [#48921]
- Phan: Address `PhanPluginDuplicateConditionalNullCoalescing` violations. [#48887]

## [7.21.2] - 2026-05-19
### Changed
- Exclude development files from production builds. [#47365]
- Update package dependencies. [#48695]
- Use `@wordpress/ui` links in integrations, response modals, and mail/phone links, keeping dashboard navigation in the same tab where appropriate. [#48407]

### Fixed
- Contact Form: Restore full theme text color for the "Required" label so it meets WCAG contrast requirements across common themes. [#48925]
- Contact Form: Restore full-width submit buttons on small screens for horizontal inline forms. [#48928]

## [7.21.1] - 2026-05-11
### Changed
- Components: Use Link from `@wordpress/ui` instead of ExternalLink. [#48529]
- Dashboard: Update to @wordpress/admin-ui 2.0.0 and use the Page component's new `visual` prop for the Jetpack logo. [#48410]
- Forms: Use the shared `Gravatar` component from `@automattic/jetpack-components/gravatar`. No user-visible change. [#48581]

### Fixed
- Forms: Fix phantom unread counter badge appearing when there are no unread form submissions. [#47281]

## [7.21.0] - 2026-05-04
### Added
- Add admin abilities for form CRUD (list-forms, get-form, create-form, delete-form) and bulk-update-responses. [#47102]

### Changed
- Internal: No longer require automattic/jetpack-changelogger as a per-project dev dependency. [#48225]
- Update package dependencies. [#48347] [#48403]

### Removed
- Dashboard: remove orphaned SCSS @use imports that were never referenced. [#48192]

## [7.20.0] - 2026-04-27
### Added
- Add `jetpack_forms_email_show_actions` filter to hide action buttons in notification emails. [#48262]

### Changed
- Tools: Update rasterization script to strip pHYs chunk from PNGs. [#48219]
- Update package dependencies. [#48302]

## [7.19.0] - 2026-04-20
### Added
- Form preview now lets you submit the form to test the full submission flow end to end. Responses created from preview are stored as test responses, clearly flagged in the notification email, and excluded from the default CSV export. [#48057]

### Changed
- Update package dependencies. [#48106] [#48141] [#48142]

### Removed
- Dashboard: remove dead .jp-forms-filters-bar SCSS left behind after the move to native DataViews filters in #46732 [#48184]

### Fixed
- Forms: make response exports respect the Source filter so the downloaded CSV matches the filtered inbox view. [#48111]

## [7.18.0] - 2026-04-15
### Added
- Support granular date filter in inbox. [#46760]

### Changed
- Enable Central Forms Management (wp-build dashboard and synced forms) by default for all sites, including self-hosted Jetpack installations. [#47826]
- Forms responses dashboard: Request field values as a keyed collection from the API. [#48076]
- Update package dependencies. [#47907]

### Fixed
- Ensure central-form-management feature flag is registered at bootstrap so early callers (including the dashboard default-tab redirect) see the correct value. [#48080]
- Fix the Form block when the Blocks module is inactive by registering it directly from the Forms package and providing the required editor initial state. [#48037]
- Rename 'preview_nonce' query var to 'jetpack_form_preview_nonce' to avoid collision with WordPress core preview URLs, which caused static front page previews to show the blog index on WordPress.com sites. [#48079]
- Show loading state instead of stale data when navigating between form response listings. [#48053]

## [7.17.0] - 2026-04-13
### Added
- Add source filter parameter to feedback REST API for filtering responses by source post ID, with fallback to post_parent for legacy data. [#48027]

### Changed
- Change header actions to be consistent with other pages. [#48036]
- Update package dependencies. [#47890] [#47998]

### Fixed
- Bundle admin-ui base CSS in wp-build output so host applications don't need to load it separately. [#47784]
- Enable mobile navigation sidebar toggle on all Forms dashboard pages. [#48013]
- Fix 'Don't show this again' checkbox in the help modal so it only dismisses permanently when clicking 'Got it', not when closing via the X button or Escape key. [#47943]
- Handle non-string values in the phone field rendering pipeline. [#47970]
- Handle non-string values in the rating field rendering pipeline. [#47971]
- Validate the field type before resolving the block icon path. [#47965]
- Load build.php unconditionally when alpha is enabled, so host applications can integrate Forms routes without manual file loading. [#47997]
- Prevent fatal error when a non-checkbox field's render value or POST-submitted value is an array. [#48032]

## [7.16.0] - 2026-04-06
### Changed
- Clean up old About page images. [#47897]
- Forms: Allow browsers to lazy-load avatars in responses. [#47900]
- Update package dependencies. [#47889] [#47892] [#47899]

### Fixed
- Fix missing margin prop in SelectControl component. [#47904]

## [7.15.0] - 2026-03-30
### Security
- Gravatar: Do not include email or IP address in Gravatar image URL. [#47779]
- Improve form submission validation. [#47795]

### Added
- Add WordPress Playground blueprint for Forms development. [#47758]
- Dashboard: Add tracking events for form-level actions (preview, copy embed, copy shortcode, duplicate, trash, restore, delete, rename, publish/unpublish, edit, view responses). [#47646]

### Changed
- Exclude blueprints directory from production builds. [#47821]
- Gravatar: Show initials derived from email prefix instead of mystery person avatar when no name is provided. [#47807]
- Remove reduntant de-registration of Jetpack collection in forms editor. [#47614]
- Update DataViews dependency. [#46973]
- Update legacy Node calls. [#47770]
- Update package dependencies. [#47686] [#47799] [#47818]

### Fixed
- Ensure form rename modal does not close when save fails, so users can retry without losing their input. [#47796]
- Fix phone field initialization failure when script module loads after DOMContentLoaded. [#47657]
- Fix undo restoring wrong form status for non-standard statuses in dashboard header actions. [#47798]
- Prevent Forms dashboard black screen when The Events Calendar is active by replacing fragile import() in inline script with a proper script module. [#47823]
- Set ref attribute instead of clearing it during synced form conversion. [#47794]

## [7.14.0] - 2026-03-23
### Added
- Add logged-in user display name and ID to form submission emails and response sidebar. [#47652]
- Add "rename" and "trash" actions to the single form dashboard dropdown menu, and reorder menu items. [#47589]
- Form Editor: Show a post-publish modal guiding users to add their form to a page. [#47539]

### Changed
- Clean up old .png files. [#47678]
- Dashboard: Adjust empty state copy and behavior. [#47464]
- Dashboard: Restore trashed forms as draft instead of publish. [#47591]
- Forms Dashboard: Show name modal when creating a new form instead of navigating directly to the editor. [#47702]
- Improve string handling in legacy classic editor form builder. [#47514]
- Remove greeting text from form response notification emails. [#47649]
- Remove the root route in favor of PHP redirect. [#47573]
- Send blog_lang and permalink to Akismet for improved spam detection on contact form submissions. [#47599]
- Update package dependencies. [#47684] [#47685]

### Removed
- Remove legacy form builder script that is no longer loaded or used. [#47608]

### Fixed
- Add padding to the form editor visual editor area. [#47706]
- Add polyfills for wp-build unbundled dependencies. [#47367]
- Ensure dashboard URL points to `/responses/inbox` instead of `/`. [#47648]
- Prevent blocks from disappearing after navigating back from form editor when page has multiple form blocks. [#47667]
- Fix 404 error on the route-based dashboard. [#47592]
- Fix header spacing for wp-build dashboard on mobile viewport. [#47644]
- Force block editor for jetpack_form post type when Classic Editor plugin is active. [#47621]
- Form Editor: Insert new blocks into the active step in multistep forms instead of the form root. [#47669]
- Gravatar hovercard: Add translation string for private profile error state. [#47594]
- Remove tabs from the wp-build dashboard when CFM is disabled. [#47670]
- Remove unnecessary post_type parameter from form edit URLs that caused incorrect redirects. [#47596]
- Set duplicated form status to draft when the original form is published, preserving the original status otherwise. [#47590]
- Show distinct error message when user lacks permission to edit a form block vs. when the form does not exist. [#47622]

## [7.13.0] - 2026-03-16
### Added
- Add entries filter to filter forms by whether they have responses. [#47523]
- Add form name modal to the wp-build forms dashboard, prompting users to name their form before entering the editor. [#47395]
- Add per-status form counts REST endpoint and display counts in Forms dashboard status filters. [#47475]
- Forms: Add publish/unpublish actions. [#47325]

### Changed
- Editor: Hide word count and reading time panel. [#47528]
- Dashboard: Remove modified date filter. [#47523]
- Hide "Browse form patterns" button in the form placeholder when central form management is enabled. [#47527]
- Update "View form responses" button to link to the specific form's responses when the form has a ref. [#47530]
- Update dependencies. [#47472]

### Fixed
- Create synced form when inserting form variations via the block inserter. [#47335]
- Ensure forms list entries count updates after trashing responses. [#47526]
- Ensure HTML entities are decoded in form title on pre-publish panel. [#47531]
- Ensure number field min and max values display in the UI after page reload. [#47511]
- Fix aria-label attribute by passing a string value to the Page component. [#47481]
- Purge edge cache when a jetpack_form post is published, updated, or unpublished. [#47532]
- Show "No results found" empty state when search or filters are active in the forms list view instead of the onboarding empty state. [#47525]

## [7.12.0] - 2026-03-09
### Added
- Form Editor: Show form embed code. [#47238]

### Changed
- Form Editor: Auto-open the block inserter on load so form field blocks are immediately discoverable. [#47413]
- Hide the Jetpack block collection from the form editor block inserter. [#47390]
- Forms dashboard: Use title header on top-level pages for consistency with other Jetpack pages. [#47446]
- Switch to Native TypeScript compiler based on Go. [#47375]
- Update package dependencies. [#47496] [#47499]

### Removed
- Remove the form title modal from the form editor. [#47458]

### Fixed
- Add missing 'Trash' status label in stage component. [#47450]
- Contact Form: Show synced forms as read-only preview in widget editor with Edit Form button. [#47235]
- Dashboard: Fix admin page header CSS specificity to prevent style conflicts. [#47313]
- Decode HTML entities in form dropdown titles in the variation picker. [#47474]
- Extract `WidgetEditorReadonlyView` into its own component to scope `useBlockEditingMode` to widget editor context only. [#47452]
- Fix TypeScipt type errors detected by `tsgo`. [#47423]
- Update submit button handling to support core/button blocks as part of the jetpack/button to core/button migration. [#47438]

## [7.11.0] - 2026-03-02
### Added
- Auto-create synced form when AI generates form fields with central form management enabled. [#47267]
- Forms Dashboard: Display form status badge in the single form view header. [#47328]

### Changed
- Replace `Badge` component from `@automattic/ui` with `@wordpress/ui` `Badge`, fixing extra margin on badges in the forms dashboard. [#47377]
- Use integer format for response count in dataviews. [#47381]
- Update package dependencies. [#47294]
- Use block type title instead of post title for synced form naming. [#47336]
- Use `Tabs` component from `@wordpress/ui`. [#46985]

### Fixed
- Fix synced form loading state to correctly report loading during initial `IDLE` status. [#47327]
- Fix MailPoet subscriber not created on form submission due to list ID type mismatch and email field not detected by type attribute. [#47394]
- Create new form pages without a placeholder title. [#47383]
- Multi-step Form: Fix navigation button styling to support granular CSS customization. [#47324]

## [7.10.0] - 2026-02-26
### Added
- Add 'Other' option support for radio fields with custom text input, including ARIA accessibility, proper validation, and metadata storage for form submissions. [#46461]
- Add print-friendly styles to form submission emails: hide decorative field icons, tighten spacing, and remove non-essential elements when printing. Minify email CSS to stay under Gmail's 8,192-character style block limit. [#47287]
- Add View Responses button and More Actions dropdown to form editor header. [#47175]
- Forms block: Add border styling support. [#47274]

### Changed
- Optimize CSS loading by moving status notice styles to separate file loaded only when needed. [#47273]
- Revert https://github.com/Automattic/jetpack/pull/47097 - restore button border colors to previous state. [#47260]
- Update package dependencies. [#47285] [#47295] [#47300]

### Fixed
- Fix "Other" option toggle not updating the option label in the editor. [#47316]
- Fix duplicate title in plain text email by removing the preheader element before generating plain text alternative. [#47291]
- Fix infinite loop in Name field block when initializing `fieldVariant` attribute. [#47266]
- Button locator on `multi-step-navigation` was aiming at the wrong element (block parent container instead of button element). [#47286]
- Fix unwanted border appearing in Gutenberg 22.6.0. [#47275]
- Prevent decorative icons from being included when copy/pasting form response emails. [#47279]

## [7.9.0] - 2026-02-23
### Added
- Dashboard: Add "Duplicate" action to the wp-build forms list. [#47171]
- Dashboard: Add actions dropdown (Duplicate, Preview, Copy embed, Copy shortcode) to the single form view header. [#47202]
- Dashboard: Add help for blocks vs forms. [#47135]
- Dashboard: Add rename action to forms list. [#47104]
- Add file field HTML output for emails. [#47148]
- Add pre-publish panel with settings summary and quick navigation to the form editor. [#47255]

### Changed
- Change default form layout from vertical to horizontal with wrap, allowing form fields to display side-by-side. [#47210]
- Change forms dashboard URL filter to allow customizing the dashboard location and resolve legacy hash fragments from email links. [#47029]
- Render images from image select fields on email notifications. [#47160]
- Update package dependencies. [#47173]

### Fixed
- Contact Form: Fix layout classes applied to wrong element for synced forms. [#47136]
- Contact Form: Fix shortcode ref attribute to load form from `jetpack_form` post type. [#47129]
- Dashboard: Fix flash of unstyled response data in the inspector sidebar on initial page load. [#47179]
- Dashboard: Re-add the source column to the single form view responses table. [#47232]
- Dashboard: Remove bottom margin on search control that caused vertical misalignment in the header row. [#47263]
- Dashboard: Remove icons from mobile dropdown menu items for a cleaner appearance. [#47206]
- Dashboard: Use consistent "responses" terminology instead of "entries" and "submissions". [#47256]
- Email template: Fix button layout regression, add responsive mobile stacking, improve font sizes, and align field icons with labels. [#47127]
- Fix 'Mark as spam' button in email notifications to work with wp-build dashboard. [#47150]
- Fix file-type icon paths and show image thumbnails for file fields in the inspector. [#47253]
- Fix image-select field preview styling on the wp-build dashboard. [#47252]
- Fix wp-build dashboard headers and content positioning on mobile. [#47139]
- Form Editor: Add padding below title to prevent block toolbar overlap. [#47170]
- Image Select: Prevent fatal error when rendering image-select fields with invalid image payloads. [#47236]

## [7.8.0] - 2026-02-16
### Added
- Dashboard: Add 'Copy embed' and 'Copy shortcode' actions to copy form code to clipboard. [#47092]
- Form Editor: Show form name modal when creating a new form. [#47105]
- Form Notifications: Add new HTML email template structure with respondent info section, metadata section (date, source, device, IP), and updated action buttons. [#47022]
- Add horizontal layout. [#45272]
- Show status notice for non-published synced forms in the block editor and frontend preview when attempting to publish. [#46914]

### Changed
- Admin Bar: Replace dashicon with SVG icon and add tooltip to "Form Responses" link. [#47120]
- Allow Accordion, Details, and Icon blocks in forms. [#47121]
- Allow filtering active tooltips for integrations from the backend. [#47026]
- Consolidate temporary menus into one for WP build dashboard. [#47058]
- Dashboard: Create new forms in same tab. [#47098]
- Dashboard: Make forms primary on wp-build dashboard. [#47126]
- Dashboard: Set primary actions for wp-build forms list. [#47051]
- Dashboard: Tweaks for wpbuild dashboard header. [#47064]
- Dashboard: Update wp-build header buttons. [#47069]
- File Upload Dropzone: Allow Icon block to be added inside the dropzone. [#47121]
- Allow filtering forms dashboard URL. [#47039]
- Extract method to util class, introduce new email renderer class. [#47108]
- Make sure 100% width fields apply properly on mobile. [#47125]
- Use new email renderer class. [#47117]
- Update package dependencies. [#47099]

### Fixed
- Compatibility: Clean up deprecated CSS. [#47067]
- Contact Form: Fix button border color not following the text color on the frontend. [#47097]
- Contact Form: Fix crash in block label function and display actual form title with status indicator. [#47111]
- Contact Form: Fix layout display in widget areas. [#47132]
- Contact Form: Remove `grunion.css` dependency from forms layout stylesheet. [#47133]
- Form Editor: Fix synced form changes being lost when navigating between page editor and form editor. [#47048]
- Form Editor: Prevent empty paragraphs from being inserted outside the form block. [#47016]
- Load the wp-build dashboard independently of the Gutenberg plugin. [#47035]

## [7.7.0] - 2026-02-10
### Added
- Contact Form: Add shortcode transform support for synced form references. [#46812]
- Dashboard: Update header tab counts. [#46934]
- Add field type icons to submission confirmation page to indicate field types. [#46834]
- Add icon extraction and rasterization pipeline for email templates. [#46979]
- Add preview functionality allowing users with edit permissions to preview forms at a temporary nonce-based URL. [#46935]
- Add single form view to wp-build dashboard. [#46875]
- Response inspector: Display star rating icons for rating field submissions. [#46874]
- Single Response View: Add notes feature to wp-build dashboard. [#46907]

### Changed
- Contain file preview modal component styles. [#46892]
- Dashboard: Hide "New form" button on form responses page. [#47023]
- Format numbers consistently in response action messages using `formatNumber()`. [#46871]
- Add hook for shared wp-build dashboard header details. [#46910]
- Add inline field icons module for wp-build compatibility. [#46950]
- Add SVG icon files for all form field blocks and configure webpack for SVG component and raw imports. [#46858]
- Update response sidebar meta section visually and refactor styles. [#46929]
- Update sidebar information on wp-build dashboard. [#46938]
- Hide 'Last Edited' panel in form editor. [#47013]
- Image select field: Improve preview styling in response inspector. [#46870]
- Multi-step Forms: Replace jetpack/button with core/button for navigation buttons, with backwards compatibility for existing forms. [#46942]
- Refine inspector field styles. [#46970]
- Update package dependencies. [#46936] [#47002]
- Use dynamic number values for spam and trash tip in response sidebar, and add styles. [#46888]

### Fixed
- Contact Form: Add support for form editing in widget editor context. [#46806]
- Contact Form: Fix loading spinner not showing on submit button. [#46913]
- Contact Form: Prevent duplicate form display on the frontend after a successful submission. [#47011]
- Fix Export button on wp-build dashboard. [#46994]
- Fix IP address lookup link in response inspector. [#46969]
- Fix leftover icons after SVG restructuring revert. [#46999]
- Add placeholder option for required shortcode-based select fields to fix validation. [#47007]
- Convert step icons to function components to fix usage as React components. [#47005]
- Remove focus outline from form success message. [#46912]
- Set default value for confirmationType attribute to prevent unnecessary serialization. [#46866]
- Handle deleted or missing form source in responses filter. [#46861]
- Prevent creating synced jetpack_form posts during block preview, and skip form wrapping when editing jetpack_form post type directly. [#46932]

## [7.6.0] - 2026-02-02
### Added
- Display star/heart rating icons on submission confirmation page. [#46679]
- Add filter counts to wp-build inbox. [#46869]
- Add form DataViews table to wp-build dashboard. [#46837]
- Add forms list to wp-build dashboard. [#46830]
- Add item click handler for DataViews on dashboards. [#46752]
- Add new field preview component for response view with improved field type rendering and styling. [#46706]
- Add single form screen. [#46767]
- Auto-create synced form when inserting a field block outside a form (when central form management is enabled). [#46831]
- Display uploaded files with icon, filename, and size on confirmation page. [#46764]

### Changed
- Extract Forms logo and product name into a shared FormsLogo component and use it in both the responses and forms wp-build dashboard stage headers. [#46849]
- Format number field values in the response field preview component using formatNumber() for proper locale-specific formatting (e.g., thousands separators). [#46872]
- Include wp-build watch in regular watch command. [#46857]
- Refactor actions for wp build dashboard. [#46635]
- Update copy from "submissions" to "responses" for consistency. [#46771]
- Update dashboard default view and tab labels - rename "All responses" to "Responses", set "Responses" as the default landing page instead of Forms, and reorder tabs to show Responses first. [#46792]
- Update wp-build dashboard to use `useInboxData`. [#46808]
- Gate the Forms Integrations feature. [#46829]
- Improve country flag and text display consistency across the dashboard. [#46786]
- Response view: display phone numbers with country flags and international formatting. [#46765]
- Share response header via component for new and old dashboard. [#46773]
- Simplify labels for form responses. [#46873]
- Update package dependencies. [#46430] [#46759] [#46851] [#46853] [#46854] [#46880]
- Update unread badge styles for the new dashboard. [#46774]
- Use Page component from package for WP Build dashboard. [#46704]

### Fixed
- Announce form submission and errors to VoiceOver. [#46707]
- Contact Form: Fix Edit Form button in the Site Editor by navigating directly to the form editor. [#46790]
- Ensure form block is selected and locked when editing forms, and restrict available blocks to form-related blocks only. [#46770]
- Form Editor: Stop hiding editor toolbar and sidebar panel tabs. [#46839]
- Ensure first step is selected when switching to or loading a multistep form. [#46813]
- Fix dashboard inspector "mark as read/unread" action. [#46769]
- Fix data normalization on dashboard. [#46828]
- Fix filters alignment and spacing in the new wp-build dashboard responses view so the filters row matches the Inbox layout. [#46797]
- Multi-step forms: Fix submit button spinner CSS selector to target the correct element. [#46807]

## [7.5.0] - 2026-01-26
### Added
- Add an "Edit Form" button that takes you to edit the form via the form editor. [#46582]
- Add granular block categories for better organization of form fields in the block inserter on the Form Editor. [#46626]
- Add redirect for jetpack_forms post type to the new dashboard. [#46670]
- Create a new form post type when inserting a form. [#46608]
- Display image-select field choices with thumbnails and captions on submission confirmation page. [#46664]
- Add bulk actions for form posts. [#46736]
- Add form delete action. [#46648]
- Add permanent delete for form posts. [#46711]
- Add status filter for form posts. [#46709]

### Changed
- Allow hiding settings URL for integrations. [#46749]
- Fix unread count not updating when feedback status changes between published and unpublished states. [#46505]
- Update dataviews header and filters. [#46732]
- Update copy for MailPoet integration. [#46748]
- Use components for empty actions in trash/spam for new wp-build dashboard. [#46695]
- Use Stack component from WP-UI package in new wp-build dashboard. [#46680]
- Use the generated asset dependency file for the dashboard. [#46661]
- Update package dependencies. [#46716]

### Fixed
- Fix a bug where we were overwriting the default wp modules. [#46650]
- Fix wp-build dashboard rendering after wp-build dependency update and prefix functions to avoid conflicts with Gutenberg. [#46652]
- Fix block styles not loading in CIAB environment. [#46643]
- Fix race conditions in spam/not-spam actions when triggered in quick succession. [#46663]
- Image Select Field: Fix useSelect returning different values warning by memoizing derived data. [#46712]
- Image Select Response: Fix image previews by handling edge cases where Photon should not be used (localhost, blob URLs, local domains, private atomic sites). [#46682]
- Slider Field: Fix React iteration render error by adding key prop to control wrapper. [#46713]

## [7.4.0] - 2026-01-19
### Added
- Add ref attribute support for the form block. [#46555]
- Add centralized dashboard tabs. [#46506]
- Add country flag emoji to phone field values in form submission confirmation page. [#46611]
- Add reusable forms list to dashboard. [#46580]
- Display URL field values as clickable links in form submission confirmation page. [#46593]
- Make form webhooks generally available. [#46422]

### Changed
- Update "Create Form" if CFM flag is on. [#46598]
- Update dataviews actions to match between old and new dashboard. [#46564]
- Update form submission confirmation page with new design. [#46521]
- Implement IP flag in new WP Build dashboard. [#46595]
- Replace escape function in checkbox input value. [#46354]
- Split wp-build dashboard Inspector into multiple files. [#46616]
- Update read/unread status column style to match old dashboard. [#46566]
- Update source link to use `ExternalLink` component in new dashboard. [#46586]
- Use empty state component for new dashboard. [#46638]
- Use Gravatar component in new dashboard inbox. [#46567]
- Use wrapper function to mark unread rows in new dashboard. [#46591]
- Update package dependencies. [#46552] [#46568] [#46647]

### Removed
- Clean up all dashboard migration code (filters, methods and wrapped up code). [#43825]

### Fixed
- Consent block: Automatically set required to false when consent type is implicit. [#46443]
- Fix z-index stacking order for animated labels and combobox dropdown. [#46634]
- Fix dashboard routing on wpcom. [#46554]
- Use fallback in all email rendering contexts. [#46581]

## [7.3.0] - 2026-01-12
### Security
- Add SSRF protection for webhook URLs to prevent requests to internal networks and cloud metadata endpoints. [#46424]

### Added
- Add feedback comments. [#46309]
- Add form editor under a feature flag. [#46444]
- Allow merging two options together with backspace. [#46507]

### Changed
- Change how phone combobox handles flag changes, bypassing wpemoji MutationObserver. [#46492]
- Update package dependencies. [#46456] [#46512]

### Fixed
- Fix personal data export search to handle email addresses in all storage formats (legacy, V2, V3) including unicode/emoji characters. [#46429]
- Fix date exports. [#46445]
- Fix wp-build dashboard with updated @wordpress/build package. [#46509]
- Prevent get_render_api_value from mutating internal state when called multiple times on cached feedback objects. [#46524]
- Use consistent checkbox and radio styles in the editor to match frontend rendering. [#46441]

## [7.2.0] - 2026-01-06
### Added
- Add support for setting custom ID on hidden field blocks from block settings. [#46360]
- Add a new filter that lets us control when we want to show the powered by wording in the email. [#46158]
- Add list view sidebar for easier field management. [#46403]
- Allow using the Gutenberg Core Button block as the submit control in Contact Form. The block gets the same interactivity bindings and loading spinner as the Jetpack Button, and all form variations now insert a core button by default. [#46166]
- Support Math and Code blocks inside forms. [#46421]

### Changed
- Use core/button instead of jetpack/button. [#46166]
- Refactor Feedback_Test.php into 8 focused test classes for better organization and maintainability. [#46394]
- Update radio button styling to use ::before pseudo-element approach for consistency with checkboxes. [#46392]

### Fixed
- Fix combobox dropdown styling overrides for phone input field. [#46408]
- Fix checkbox-multiple styling by removing incorrect button style selector. [#46412]
- Fix combobox dropdown occlusion by adding z-index when open. [#46401]
- Fix React console error on checkbox/radio option inputs by providing an onChange handler. [#46439]
- Don't allow ::after pseudo element manipulation on Jetpack Forms radio and checkbox input elements. [#46393]
- Fixing form checkboxes and radio styles for dark background themes. [#46411]
- Update 'Learn more' link in form notification settings. [#46385]
- Improve phone field styling to better mimic theme input styles, including focus outline and filter CSS properties. [#46432]

## [7.1.0] - 2025-12-22
### Added
- Add wp-build based form responses route for DataViews integration. [#46206]

### Changed
- Allow CSV files to be uploaded via contact forms. [#46308]
- Update package dependencies. [#46352]

### Removed
- Remove admin class files. [#46255]

### Fixed
- Fix textarea placeholders to match input placeholder styling. [#46310]
- Fix button padding. [#46331]
- Strip HTML from styled labels in error summary. [#46319]

## [7.0.0] - 2025-12-15
### Added
- Add Jetpack Form custom post type for reusable forms with REST API support and feature flag integration. [#46202]
- Add CTA to install/activate Akismet on empty spam dashboard. [#46212]

### Changed
- Add `jetpack_forms_extra_webhooks` filter and include feedback ID in `jetpack_forms_before_webhook_request` filter. [#46228]
- Auto-generate webhook id so users don't have to fill it. [#46270]
- Refactor how we retrieve form submission fields to send in the webhook payload. [#46201]
- Track webhook requests done in wpcom infrastructure. [#46273]
- Track when users enable and disable webhooks. [#46277]
- Use entire button area for selecting multi-select options. [#46263]
- Replace use of confusing `esc_js` with `wp_json_encode`. [#46229]
- Tests: Replace PHPUnit mocks with anonymous classes to eliminate PHPUnit 12 strictness warnings. [#46256]
- Update package dependencies. [#46244]

### Removed
- Removes classic Admin initialization code. [#46254]

### Fixed
- Fix export functionality to handle null values properly for IP Address, Country code, and Browser fields. [#46250]
- Fix `Contact_Form_Endpoint_Test::test_resend_email` attempting to actually send email. [#46261]
- Ensure submission summary is contained within 100% width. [#46264]
- Fix dashboard height. [#46276]
- Fix slider field text labels showing borders in editor when using certain themes like Assembler. [#46182]
- Fix validation accessibility. [#46275]
- Make form buttons take full width on mobile devices. [#46154]

## [6.22.0] - 2025-12-08
### Added
- Add filter to hide integration icons. [#46188]
- Add integrations display filters. [#46156]

### Changed
- Update package dependencies. [#45914]

### Fixed
- Ensure proper flags are used with `json_encode()`. [#46092]
- Decode HTML entities in exported form names to prevent codes like `&#8211;` appearing in CSV exports. [#46178]
- Fix PHP warning when global gets overwritten. [#46141]
- Set `from` field as primary on dashboard. [#46170]

## [6.21.2] - 2025-12-04
### Fixed
- Forms: Use the correct case on cipher names [#46189]

## [6.21.1] - 2025-12-03
### Fixed
- Fix the flickering between the sidebar loading on different browser widths.

## [6.21.0] - 2025-12-01
### Added
- Add form response webhook support. [#46059]
- Add WordPress Abilities API integration for form submissions management and integrations access. [#45998]
- Use parse_blocks instead of preg_replace for attribute appending on templates and widgets. [#45999]
- Form Webhooks: add logging and filter flag for initialization. [#46059]

### Changed
- Enable form webhooks feature based on current plan support. [#46059]
- Add notice after optimistic response status update. [#46056]
- Improve name variation handling. [#46054]
- Remove related-posts from API calls. [#45928]
- Form Webhooks: clean up and consolidate webhooks to take over the unused-yet-present postToUrl. [#46059]
- Update package dependencies. [#46072] [#46143]

### Fixed
- Add fallback values to CSS custom properties to improve form styling compatibility across themes. [#46038]
- Fix checkbox styling and block interaction in editor by removing disabled attribute and using CSS pointer-events instead. [#46125]
- Do not link to to empty source_link. [#46133]
- Fix inbox reponse email copy button alignment. [#46088]
- Fix notices positioning on dashboard. [#46097]
- Fix spam status change tracking when post is not available. [#46107]
- Make the filter count not be cut off. [#46132]
- Outlined style leading notch was missing base border settings. [#46048]
- Reject form submissions when the parent post/page with the form has been deleted or is no longer published. [#46103]
- Remove clashing between meta and field names. [#46130]
- Trash old spam instead of fully deleting. [#46033]
- Use fallback page value on feedback source if variable is polluted. [#46075]
- Wrap long emails in response. [#46121]

## [6.20.0] - 2025-11-24
### Added
- Add docs on classes and usage. [#46047]

### Changed
- Add examples for first/last name field variations. [#45985]
- Componentize more response styles and JS. [#45918]
- Protect against invalid attributes when merging new values. [#45997]
- Update dashboard header buttons. [#45983]
- Use first/last name for author. [#45944]

### Fixed
- Fix left margin on inbox. [#46044]
- Fix modal/sidebar stacking issue in DataViews inbox where modals would open on top of sidebars at certain screen sizes. [#46017]
- Fix name variation isActive setting. [#46028]
- Jetpack: Remove `getIconColor` functions from block icons. [#45992]
- Remove height hacks in dashboard layout and use viewport-based height calculation. [#46052]

## [6.19.0] - 2025-11-19
### Changed
- Move empty state as component for inbox. [#45971]
- Update to Manage Integrations". [#45979]

### Fixed
- Allow long responses to scroll. [#45975]
- Fix spacing within advanced editor panel. [#45973]
- JWT payload v2. [#45954]

## [6.18.0] - 2025-11-18
### Changed
- Update to ESM module. [#45963]
- Refactor dashboard layout and add Page components for improved structure and maintainability. [#45952]
- Update package dependencies. [#45961]

## [6.17.0] - 2025-11-17
### Added
- Add formTitle on default attributes so it persists throughout parsing and processing. [#45908]

### Changed
- Add a new filter for the JWT token error. [#45949]
- Componentize response file field. [#45892]
- Fix regression making our dashboard not scrollable. [#45867]
- Improve MailPoet subscriber handling. [#45905]
- Optimistically move items from/to inbox/spam/trash. [#45912]
- Render badges in unread/read column when visible. [#45931]
- Show country name as tooltip in IP flags. [#45886]
- Split styles into smaller files alongside their respective components. [#45888]
- Use core WP colors for basic primitive components such as buttons at Forms dashboard. [#45845]
- Update package dependencies. [#45915] [#45916] [#45958]

### Removed
- Clean up code and styles. [#45882]

### Fixed
- Address spacing issues on single input forms. [#45909]
- Fix Delete spam and Empty trash actions. [#45933]
- Pass requiredText from option block to checkbox field. [#45897]

## [6.16.0] - 2025-11-10
### Added
- Add dev docs. [#44841]
- Add email as secondary information on dashboard. [#45802]
- Add keyboard navigation to view responses quickly. [#45811] [#45812]
- Add integrations to dashboard mobile menu. [#45744]
- Add subtitle to dashboard page. [#45773]

### Changed
- Add browser info to the form response email notification. [#45710]
- Add IP lookup link to IP address in form notification email footer. [#45762]
- Adjust dataviews paddings for consistent spacing with the header. [#45824]
- Change integrations modal width. [#45855]
- Default multistep forms to single step view in the editor and prevent viewport jumping during step navigation. [#45693]
- Disable export button if no form entries. [#45777]
- Let there be only 1 primary header CTA and push it to the right. [#45849]
- Modernize responses header with tabs, compact number formatting, and improved mobile layout. [#45748]
- Move integrations from tab to button and display in modal. [#45717]
- Reduce logo size to 20px for better visual balance in the dashboard header. [#45790]
- Remove unused CSS from forms dashboard. [#45853]
- Update dashboard styling for visual consistency (header, buttons, tabs, and color variables). [#45783]
- Update dataview actions. [#45670]
- Update package dependencies. [#45735] [#45737] [#45756]

### Fixed
- Add gravatar everywhere to improve consistency. [#45823]
- Apply tip styles on mobile responses. [#45846]
- Fix a bug where we were not showing duplicate form field values. [#45809]
- Fix animated and outlined styles. [#45743]
- Fix author name on feedback endpoint. [#45832]
- Fix duplicated email on dashboard. [#45821]
- Fix export modal styling. [#45852]
- Fix hidden unread dot. [#45856]
- Fix horizontal scroll on mobile. [#45788] [#45808]
- Fix integrations modal flash. [#45775]
- Fix last page invalidation error when items are removed. [#45740]
- Fix mobile response view modal spacing. [#45778]
- Fix phone field extra controls option to append to shared field controls. [#45764]
- Fix visible sidebar in dashboard when multiple items are selected. [#45806]
- Improve the `invalid_jwt` error message that we show to the user. [#45781]
- Move general form error into field error when necessary. [#45796]

## [6.15.0] - 2025-11-04
### Changed
- Change field attribute width to enum to support both integers and string. [#45741]
- Use `flex-basis: 0` for auto width as it will deal better adjusting to content and not extra space. [#45747]

### Fixed
- Fix error overlapping on single input forms after using position: absolute and turning the main container to `display: flex`. [#45749]

## [6.14.0] - 2025-11-03
### Added
- Device detection: Add a method that returns the browser display name. [#45674]
- Add "auto" width for fields and detect when a form has a single input in it to show prettier validation errors. [#45689]
- Add a new JWT filter. [#45731]
- Add emoji flag to the response email next to the IP Address. [#45645]
- Add error codes to submission errors. [#45628]
- Add first and last name variations. [#45517]
- Add flag next to the IP address. [#45643]
- Add time field. [#45665]
- Add visibility support for field labels. [#45722]
- Enable forms push notifications functionality. [#45682]
- Link IP to lookup service. [#45653]
- Release Image Select Field to production. [#45577]
- Store the country code with the form responses based on the IP address. [#45599]

### Changed
- Add browser info to form responses exports. [#45709]
- Add details for JWT decoding errors. [#45646]
- Add the IP address as a default field in the forms dashboard. [#45704]
- Create new integrations list component. [#45648]
- Default to notify the post author when the notification recipients list is empty. [#45633]
- Move storage setting lower in sidebar. [#45727]
- Show gravatars also for rows without emails. [#45726]
- Use a dropdown selector to list eligible users to receive form notifications. [#45634]
- Use Jetpack logo on dashboard header. [#45609]
- Use table to render response meta. [#45656]
- Improve empty state centering and fix scrolling by consolidating layout min-height rules and improving flexbox handling. [#45649]
- Update package dependencies. [#45652]

### Fixed
- Ensure notices don't overlap the bottom action bar. [#45616]
- Fix a bug with the default email in the editor. [#45711]
- Fix a console error triggered by iterable without key prop. [#45690]
- Fix an error on phone field controls due to lack of key prop. [#45659]
- Fix React error due to missing tbody when nesting tr as direct descendant of table. [#45691]
- Fix response selection filtering bug caused by type mismatch. [#45611]
- Fix tooltip in response IP link. [#45705]
- Make sure fields is array before attempting a count. [#45739]
- Phan: Address PhanRedundantCondition, PhanRedundantArrayValuesCall, and PhanPluginRedundantAssignment violations. [#45681]
- Simplify the selection so that it changes every time to only the valid set of items. [#45618]
- Update counts after landing on a mark as spam link. [#45644]

## [6.13.0] - 2025-10-27
### Changed
- Add 'create new form' CTA to inbox empty state. [#45589]
- Add shared ConsentToggle component. [#45556]
- Align layout grid/components with DataViews table grid. [#45559]
- Improve the performance of loading the form responses dashboard. [#45565]
- Integrate `@wordpress/admin-ui` Page component into dashboard layout. [#45610]
- Record tracks events for inbox actions. [#45606]
- Remove About page from dashboard. [#45615]
- Store the user agent used on form submissions. [#45586]
- Update visual representation of "image select field" responses at inbox. [#45585]
- Update package dependencies. [#45551] [#45592] [#45598]

### Removed
- Remove custom green buttons. [#45613]
- Remove hovercards from inbox list. [#45572]

### Fixed
- Fix textarea submission on enter. [#45602]
- Reduce rerenders in the dashboard. [#45567]
- Update feedback form screenshot. [#45578]
- Adjust UX and accessibility for image select field. [#45560]

## [6.12.0] - 2025-10-21
### Added
- Show gravatar on dataviews list. [#45555]

### Changed
- Merge email and push notification settings panels. [#45548]
- Stop preloading the integrations endpoint. [#45558]

### Deprecated
- Remove unused `useFormsConfig` hook. [#45554]

### Fixed
- Fix bug where the responsive modal is not able to be closed. [#45541] [#45557]
- Fix renderable status of image select field. [#45542]
- Make integrations background white. [#45562]
- Reset the selection on tab switch. [#45543]

## [6.11.0] - 2025-10-20
### Added
- Add Hostinger Reach integration. [#45271]
- Add programmatic initialization support via `window.jetpackFormsInit()`. [#45531]
- Add unread/read filter to the dashboard. [#45514]

### Changed
- Add new useConfigValue hook and start using it on the dashboard. [#45472]
- De-clutter InboxView component and move data processing to hook. [#45489]
- Make dashboard initialization idempotent for SPA environments by using data attribute to track state. [#45539]
- Move view actions to modal header on mobile. [#45410]
- Remove logo from dashboard and align header styles with CIAB. [#45535]
- Remove old file and add tests for hook. [#45497]
- Remove unused `hasAI` from config. [#45522]
- Split components and hooks into their own files. [#45494]
- Trim empty options and display custom placeholder. [#45528]
- Update "Action after submit" sidebar section. [#45502]
- UX improvements for Image Select field. [#45516]

### Deprecated
- Remove Creative Mail promotion. [#45524]

### Fixed
- Improve handling of custom submission message formatting. [#45487]
- Send emails to the author of the form only if they are able to edit it. [#45515]
- Fix PHP warning for when a site doesn't have the JWT token yet. [#45501]
- Fix plugin activation state. [#45471]
- Prevent required text from being removed from required fields when creating a form from a pattern. [#45495]
- Store the feedback source info with more context. [#45231]
- Strip period from Terms submission label on the post-submission page. [#45509]

## [6.10.0] - 2025-10-13
### Added
- Add integrations store. [#45372] [#45432]
- Add notification settings panel. [#45396]
- Add read and unread state. [#45350]

### Changed
- Add optimistic count updates to Forms inbox for immediate UI feedback when moving items between inbox, spam, and trash. [#45424]
- Avoid typographic orphans in Forms panels in editor. [#45455]
- Change how phone field interactivity API is initialized with more atomic registration of the elements. [#45290]
- Fix preload middleware registration to properly cache API requests and support both path formats. [#45454]
- Fix preload parameters to match actual feedback endpoint requests and avoid duplicate HTTP requests. [#45453]
- Hide Google export card if disabled. [#45375]
- Improve loading state to show spinner immediately when data hasn't loaded. [#45379]
- Inbox: Remove view action for desktop. [#45444]
- Inbox: Update empty state notices. [#45421]
- Inbox: Preload initial data and essential endpoints for faster page load. [#45378]
- Reorganize settings to a single panel for rating, slider and phone fields. [#45196]
- Reverse copy of 'go back' toggle. [#45446]
- Update read/unread counts optimistically in the sidebar. [#45425]
- Replace separate count REST API requests with one optimized database query using CASE statements to improve inbox performance. [#45427]
- Update package dependencies. [#45428] [#45429] [#45430]

### Fixed
- Fix missing tooltip on unread/read quick action button. [#45433]
- Fix multistep dropdown showing "Unlabeled" instead of default step titles like "Step 1", "Step 2", etc. [#45463]
- Limit the amount of data sent by the endpoint to prevent exposing data. [#45439]
- Fix sticky loading state for trash view action. [#45411]
- Improve cross plugin compatibility. [#45315]
- Optimize `has_feedback()` query to improve dashboard load performance by limiting query to fetch only one ID instead of loading all feedback posts. [#45361]

## [6.9.0] - 2025-10-08
### Added
- Add actions on dashboard inbox's single response view. [#45352]
- Add required indicator settings and make forms with a sinble input required by default. [#45300]

### Changed
- Optimize inbox data loading with `_fields` parameter to reduce payload size. [#45376]

### Fixed
- Fix telephone field block country selector dropdown so it shows in front of other blocks while selected. [#45380]

## [6.8.0] - 2025-10-06
### Added
- Add loading spinner for integrations. [#45363]

### Changed
- Improve preloading for endpoints. [#45362]
- Update package dependencies. [#45334] [#45335]

### Fixed
- Forms: Fix integrations bottom border. [#45359]
- Forms: Remove integrations loading spinner. [#45373]

## [6.7.0] - 2025-09-30
### Changed
- Forms: Use localized number format for number of responses shown. [#45326]

## [6.6.0] - 2025-09-29
### Added
- Add options to disable "Go Back" link and summary after submission. [#45273]
- Add setting to enable or disable email notifications for form submissions. [#45230]
- Add withSyncEvent fallback for pre 6.8 compatibility. [#45320]

### Changed
- Remove unnecessary copy from exports modal. [#45280]
- Rename 'Manage responses' forms sidebar block panel to 'Responses storage'. [#45228]

### Removed
- Remove unused code `Dashboard_View_Switch` and move useful methods into Dashboard static methods. [#45282]

### Fixed
- Don't override field labels on transforms. [#45281]
- Fix 404 response for empty feedback. [#45289]
- Fix the missing `_links` attribute. [#45274]
- Hide border on last integration card. [#45305]
- Resolve conflict with WordPress 6.7.3. [#45320]

## [6.5.1] - 2025-09-22
### Fixed
- Address linting issues. [#45242]
- Fix image choice widths. [#45257]

## [6.5.0] - 2025-09-19
### Added
- Add extra layer of cache busting for interactivity API files (view.js) with hash suffix. [#45138]
- Add filter to enable integrations. [#45201]
- Add hidden field. [#45104]
- Allow custom search placeholder for phone field. [#45197]

### Changed
- Add scheduled deletion for submissions that skip the submission's inbox and are stored as temporary feedback. [#45178]
- Fix phone field whitespace lint. [#45194]
- Return integration titles from endpoint. [#45151]
- Track on .com how often forms get submitted without a JWT token. [#45221]
- Update Image Select Field to beta. [#45168]
- Use new rating block on Feedback variation and pattern. [#45215]
- Update @wordpress/dataviews package from v7 to v9. [#45213]
- Update package dependencies. [#45173] [#45229]

### Fixed
- Add cache busting on new version for interactivity API script file on top level context. [#45167]
- Address some wee issues on field error stylings. [#45187]
- Fix outline and animated styles for Image Select field. [#45189]
- Fix slider min/max editing. [#45219]
- Fix slider value position. [#45218]
- Improve button alignment when field width allows wrapping the submit button. [#45188]
- Remove input element height CSS rule after fixing form-styles hook attribute. [#45202]
- Restrict button flex setup after last changes to improve overall layout. [#45233]

## [6.4.0] - 2025-09-15
### Added
- Add new block toggle to skip saving form submisions on WP Admin. [#45072]
- Add searchable country selector dropdown (combobox). [#45120]

### Changed
- Add integrations feature flag. [#45037]
- Add integrations permissions check. [#45063]
- Add preloaded config endpoint. [#45091]
- Fix URL validation consistency between frontend and backend to prevent malformed URLs from passing validation. [#45093]
- Improve supported integrations filter. [#45123]
- Image Select field: Show option label on selected options. [#45122]
- Image Select field: Update data processing and UI. [#45080] [#45142]
- Update package dependencies. [#45127] [#45128]

### Fixed
- Address caching issue by adding a manual cache-busting suffix. [#45137]
- Ensure slashes are not errantly stripped. [#45153]
- Fix a warning and bad handling when JSON_DATA is not preceded by a new line. [#45110]
- Fix MailPoet string warning. [#45114]

## [6.3.0] - 2025-09-08
### Added
- Add hidden input block. [#44079]
- Make rating and slider fields available to self-hosted users. [#45094]
- Store the feedback in the new format. [#45047]
- Track form submission failures. [#45090]

### Changed
- Improve performance by splitting editor code into two chunks. [#45065]
- Move all international phone code and UI back into legacy telephone field. [#45061]
- Remove legacy menu item by defaulting the filter to true. [#44043]
- Render implicit consent as hidden field instead of a DOM-hidden checkbox. [#45078]
- Set button state to busy and ignore further clicks when exporting to Google Drive. [#45074]
- Show custom messages for empty inbox/spam/trash folders. [#45013]
- Update @wordpress/dataviews package from v5.0.0 to v7.0.0. [#45012]
- Update package dependencies. [#45027] [#45097]

## [6.2.2] - 2025-09-25
### Fixed
- Resolved conflict with WordPress 6.7.3

## [6.2.1] - 2025-09-25
### Added
- Forms: add extra layer of cache busting for interactivity API files (view.js) with hash suffix [#45138]
- Forms: add searchable country selector dropdown (combobox) [#45120]
- Forms: try and fix deploy cache issue by adding a manual suffix for cache busting [#45137]

### Changed
- Forms: move all international phone code and UI back into legacy telephone field, keep backwards compat [#45061]

## [6.2.0] - 2025-09-03
### Changed
- Use sentence case in integrations panel CTAs. [#45054]

## [6.1.0] - 2025-09-02
### Added
- Release rating and slider fields on WP.com (not Jetpack yet). [#44998]

### Changed
- Tooling: Generate i18n function variants programmatically. [#45020]

### Fixed
- Switch to v3 and fix v2 encoding. [#44927]

## [6.0.0] - 2025-09-01
### Added
- Add default values when border radius style is missing. [#44978]
- Add input styles to image select field. [#45009]
- Add slider field typography controls. [#44967]
- Add styles for image select field on front end. [#44923]

### Changed
- Consolidate slider front end and editor styles. [#44947]
- Deprecate legacy feedback page and add redirect to new `jetpack-forms-admin` dashboard. [#44961]
- Improve checkbox validation for older checkboxes. [#44931]
- Improve slider range touch area. [#44985]
- Improve the showing of the error div to display correctly across themes. [#44939]
- Manage Google Drive connection in dashboard. [#44956]
- Send JSON with built-in WordPress functions. [#45002]

### Fixed
- Ensure slider default obeys step. [#44919]
- Fix dataview footer width and reset page on status change. [#45021]
- Fix default styles for image select field. [#44969]
- Fix fatal when checking for classic forms dashboard. [#44935]
- Fix file field test. [#44959]
- Fix form response line breaks. [#44966]
- Fix Google export on Simple sites. [#44960]
- Fix range slider mobile input. [#45010]
- Fix slider theme CSS conflicts. [#45024]
- Fix text wrapping in the slider tooltip. [#44988]

## [5.5.0] - 2025-08-25
### Added
- Add optional country selector to Phone field. [#44635]
- Add phone number validation on international phone number input. [#44854]
- Add slider min/max labels. [#44834]
- Preserve HTML IDs when processing feedback. [#44760]
- Remove MailPoet integration feature flag. [#44831]
- Show trash action alongside view action in list. [#44882]

### Changed
- Adjust slider field controls. [#44875]
- Allow new fields in step container. [#44864]
- Create form when inserting standalone slider field. [#44840]
- Create new field below when pressing enter on Slider or Rating fields. [#44781]
- Integrations: Adjust UI for opt-in toggle controls. [#44817]
- Let MailPoet handle old/new form data. [#44930]
- Remove call to unused font. [#44815]
- Rename 'Stars Rating' to 'Stars rating field'. [#44880]
- Reorganise shared lists of allowed inner blocks - core blocks. [#44879]
- Update MailPoet to use Feedback class. [#44852]
- Update slider default and step controls. [#44803]
- Use the new Feedback class to save the feedback entries in a new format. [#44821]
- Form step navigation button: Prevent wrapping of inner text. [#44926]
- Update specificity and CSS on the site editor to match the frontend for forms. [#44802]
- Update package dependencies. [#44899]

### Fixed
- Fix a case where fatal error might occur after form submission. [#44908]
- Fix MailPoet markup console error. [#44916]
- Fix null handling in `wp_style_engine_get_styles` to prevent PHP warnings. [#44827]
- Fix radio button validation. [#44836]
- Fix ratings field in small screens. [#44884]
- Fix undefined array key "blockName" warning in contact form pre-render hook. [#44833]
- Slider: Prevent JavaScript warning. [#44837]
- Phone field: Fix styling inconsistencies. [#44850]

## [5.4.0] - 2025-08-18
### Added
- Add slider field increment option. [#44782]
- Add "dots" style variant to form progress indicator block. [#44582]

### Changed
- Add styling and settings to "Image Select" field under feature flag. [#44786]
- Update method used to check for a valid MailPoet connection. [#44784]
- Improve the selected checkbox style. [#44743]

### Fixed
- Fix phone validation in responses. [#44806]
- Silence PHP warnings with more careful calls on expected values. [#44805]

## [5.3.0] - 2025-08-14
### Added
- Add several methods to the Feedback method. [#44713] [#44759] [#44768]
- MailPoet: Implement email consent. [#44744] [#44780]
- Slider: Make min/max editable. [#44715]

### Changed
- Defer loading JavaScript for more responsive page loading. [#44752]
- Enable SCSS processing for field assets. [#44763]
- Extract visually-hidden styles to shared SCSS partial for better code reuse. [#44769]
- Increase default consent field size. [#44690]
- Move CSS to SCSS files. [#44777]
- Slider: Add visually hidden labels for inputs. [#44779]
- Slider: Update `is-selected` styling. [#44783]
- Slider: Visual update to min/max/default value inputs. [#44778]
- Update package dependencies. [#44701]
- Update rating field implementation with improved styling and visual feedback. [#44757]

### Fixed
- Add radio input field backend validation. [#44739]
- Fix animated form style in Safari. [#44689]
- Fix minor CSS glitches in the ratings field. [#44738]
- Fix validation of jetpack multi-checkboxes [#44722]
- Use the new Feedback `get_all_legacy_values` method in `parse_fields_from_content`. [#44761]

## [5.2.0] - 2025-08-11
### Added
- Add initial image select field under feature flag. [#44675]
- Add Time field. [#44272]

### Changed
- Add Typescript support to all webpack files. [#44617]
- Introduce toolbar option to add image choice on image select field. [#44718]
- Revert back to the variation picker if the form only has the submit button. [#42479]
- Update rating field max field visually. [#44592]
- Update package dependencies. [#44677] [#44703]

### Fixed
- Disallow connecting MailPoet without key. [#44687]
- Do not show dropzone in the block picker. [#44695]
- Do not append form HTML ID on post-submission link. [#44683]
- Fix default checkboxes styles, and allow for "browser" styles as a choice. [#44408]
- Fix heart/star icons showing as filled instead of outlined in Twenty Sixteen theme. [#44672]
- Fix MailPoet icon border radius. [#44688]
- Fix ordering of fields on submit when JavaScript is disabled. [#44644]
- Fix rating field causing unsaved post state by replacing useEffect pattern with BlockContextProvider. [#44672]
- I18n: Improve context hints in comments for translators. [#44686]
- Prevent PHP errors when directly accessing various files. [#44646]
- Upgrade checkbox only on first try on Simple sites. [#44711]
- Validate form on submission. [#44562]

## [5.1.0] - 2025-08-04
### Added
- Add MailPoet/lists endpoint. [#44516]
- Add slider field block. [#44150]

### Changed
- Fix how form id is calculated. [#44501]
- Ratings field: Fix translation issues. [#44593]
- Submit forms without page reload. [#44422]
- Update @wordpress/dataviews to 5.0.0. [#44376]
- Update how the success messages to use the new Feedback class. [#44489]
- Update internal_personal_data_exporter to use new Feedback class. [#44488]
- Update to shorter way to get view.js path. [#44542]
- Use the new Feedback Class in feedback endpoint response. [#44485]
- Use the new Feedback Class when downloading a CSV file. [#44487]

### Fixed
- Add safeguards when getting post properties during AJAX calls. [#44533]
- Do not send AJAX submission if form has custom redirect. [#44557]
- Fix flaky CSV export test. [#44552]
- Fix label encoding issues, and handle empty and duplicate label names. [#44599]
- Fix PHP warning in forms admin class. [#44534]
- Fix PHP warnings in Contact_Form_Plugin class. [#44528]
- Handle placeholder for textareas in the editor the same way input tags do. [#44596]
- Remove a PHP notice when non-string is passed in. [#44523]
- Trim the value before validating if empty form. [#44579]

## [5.0.0] - 2025-07-28
### Added
- Add error message on network request failure for AJAX submission. [#44386]
- Add MailPoet integration. [#44425] [#44431] [#44439]
- Add new classes for the Feedback refactor. [#44483]

### Changed
- Clean up unused CSS. [#44471]
- Improve mobile interface. [#44381] [#44391]
- Remove all height hacks, clean up some style issues, and fix the footer to the bottom.
- Update integration modal links. [#44409]
- Update step divider to look more like UI element. [#44402]
- Use Badge component for badges. [#44347]

### Fixed
- Add a JWT token when submitting the form so that we are able to instantiate on submit. [#44399]
- Allow About page to grow width so content remains centered even on oversized screens. [#44477]
- Enqueue view script only when the form is rendered. [#44460]
- Fix Sass warning in inbox. [#44442]
- Fix padding on input and textarea fields. [#44401]
- Fix field order on success message. [#44482]
- Fix form ID collision check. [#44406]
- Improve CSS on the admin side. [#44478]
- Use a core variable to account for admin bar and CSS to account for folded sidebar. [#44470]

## [4.0.1] - 2025-07-21
### Changed
- Revert forms JWT usage for forms reconstruction from responses. [#44397]

## [4.0.0] - 2025-07-21
### Added
- Add "Empty spam" button to delete all responses marked as spam. [#44308]
- Add Gravatars in form responses. [#44270]
- Add tests for feedback endpoint. [#44318]
- Display success info after form submission without reload. [#44204]
- Include multistep form in Jetpack and WordPress.com plans. [#44309]

### Changed
- Add feature flag for MailPoet integration. [#44339]
- Consolidate a single hook for all inbox data, making it easier to share the store props and dispatches and removing the need to invalidate the entire store to get fresh listings after emptying trash. [#44293]
- Invert default disabled state on empty buttons for a cleaner transition to being available. [#44321]
- Make phone fields clickable [#44291]
- Update package dependencies. [#44338] [#44356]
- Use sentence case in default consent text. [#44078]

### Removed
- Prevent rendering of old menu entry once the migration page is shown and the user clicks on the new dashboard URL. [#43714]
- Remove unused editor CSS. [#44346]

### Fixed
- Add a JWT token when submitting the form so that we are able to instantiate on submit. [#44360]
- Fix export hooks error on mobile. [#44357]
- Fix integration card headers on mobile. [#44286]
- Fix excess padding next to Gravatar on mobile. [#44394]
- Prevent post_meta from being created. [#44332]
- Remove manual `DependencyExtractionWebpackPlugin` instantiation. [#44307]
- Show submission information after reload with AJAX submission. [#44342]

## [3.1.0] - 2025-07-14
### Added
- Add "Empty trash" button. [#44225]
- Add link to disconnect Google. [#44253]
- Add tests on component. [#44225]
- Add tip that spam will automatically be deleted after 15 days. [#44226]

### Changed
- Improve email copy-to-clipboard visually and make it less hidden. [#44264]
- Remove redundant "Manage responses" inspector panel from individual field blocks so it now only appears on the main Contact Form block. [#44212]
- Set max width for integrations panel. [#44261]
- Update integration links. [#44255] [#44258]
- Update dashboard response look. [#44262]
- Update package dependencies. [#44217]

### Removed
- Clean up code from dashboard. [#44244]

### Fixed
- Prevent React error by removing unneeded key when listing files. [#44263]

## [3.0.0] - 2025-07-07
### Added
- Contact Form: Introduce a new "Rating" field block that allows site owners to collect star/heart/smiley/emoji ratings from visitors. [#44094]

### Changed
- Disallow rich text formats in multistep form divider label. [#44209]
- Update date picker to remove the jQuery dependency. We now use a new more modern date picker that allows for keyboard navigation. [#43939]
- Update package dependencies. [#44148] [#44151]

### Fixed
- Accessibility: Update screen reader 'clip' property usage to 'clip-path'. [#44027]

## [2.1.0] - 2025-06-30
### Security
- Prevent form element attribute names from being set as field names. [#44113]

### Added
- Add items count to export button labels. [#44064]
- Add JSON response to form submission and AJAX request under feature flag. [#44118]
- Add MailPoet integrations nudge. [#44115]

### Changed
- Contact Form: Simplify multistep form detection and improve error wrapper placement for multistep navigation blocks. [#44076]

### Fixed
- Set correct unread count when there's another badge number on Jetpack menu item. [#44108]
- Load the initial steps as if the form has more than one step in it. [#44098]
- Remove broken group block tranformation. [#44083]

## [2.0.1] - 2025-06-24
### Added
- Add dashboard link to response email. [#43834]
- Add "mark as spam" link to response email. [#43866]

### Changed
- Improve the error validation animation. [#43968]

## [2.0.0] - 2025-06-23
### Added
- File Uploads block: Add Tracks event to upsell nudge. [#43860]
- Introduce multi-step forms. [#43918]

### Changed
- Allow super admins see form submissions. [#43998]
- Convert various cards and components to TypeScript. [#43986] [#43992] [#43993]
- Hide legacy Feedback menu on new sites. [#44060]
- Scripts: Change imports for hosting checks. [#43972]
- Update type handling for integrations. [#43969]
- Update package dependencies. [#44020] [#44040]

### Fixed
- Fix HTML support to labels in animated style. [#43966]
- Fix the overlay z-index for date picker. [#43967]
- Make outline style notched labels more selectable. [#43956]

## [1.3.0] - 2025-06-16
### Added
- Add a preview link to the response view for files. [#43730]
- Add TypeScript type checking to the package. [#43867]
- Add Akismet refresh status button. [#43937]
- Add button to create Salesforce form. [#43911]
- Add variables to be translated. [#43957]
- Show central integrations dashboard. [#43936]

### Changed
- Add inline docs for Salesforce. [#43909]
- Change form creation method. [#43944]
- Consolidate TypeScript types. [#43733]
- Move components that are shared across blocks from the contact-form block folder to the shared folder. [#43895]
- Stop translating Forms product name in the sidebar. [#43925]
- Switch to `Request::is_frontend()` method from Jetpack Status package. [#43873]
- Update package dependencies. [#43892] [#43914] [#43951]
- Use interactivity API for form validation. [#43893]

### Removed
- Remove old duplicated components. [#43895]

### Fixed
- Adjust "About" page layout to fit any text on feature cards. [#43943]
- Catch PHP warning when parsed block data is malformed. [#43865]
- Ensure that the select control uses the correct padding. [#43919]
- Fix a PHP warning. [#43960]
- Fix interactivity bug where the field is not registed yet. [#43959]
- Fix plugin connection badges. [#43856]
- Fix Saleforce badge. [#43862]
- Fix Salesforce form fields. [#43915]
- Fix styling of the select input in animated styles. [#43938]
- Prevent PHP warning when rendering blocks. [#43890]

## [1.2.0] - 2025-06-09
### Added
- Add "Remove" button for dropdown options and prevent dropdowns with no options. [#43616]
- New file uploads field released. [#43846]
- Show unread count on Jetpack > Forms submenu. [#43758]

### Changed
- Add section about developer documentation to FAQ. [#43654]
- Move `get_export_filename` method from Admin to Util. [#43823]
- Use sentence case where appropriate in UI. [#43818] [#43847]
- Update feedback pattern screenshot. [#43849]
- Update inbox fallback and redirect URLs. [#43757]

### Removed
- Remove unused code. [#43816] [#43838]

### Fixed
- Add line-height to migration page heading when it wraps. [#43827]
- Fix dropdown field background color on Windows. [#43848]
- Fix an error with poorly-formatted POST data. [#43835]
- Fix routing on new integrations tab. [#43822]
- Remove all admin notices from the Jetpack Forms admin. [#43776]

## [1.1.0] - 2025-06-05
### Added
- Add "undo" to all action snackbars in Inbox. [#43787]

### Changed
- Remove `is_admin` fencing for menu registration and move Forms down on submenu order. [#43755]
- Make emails clickable in Inbox. [#43771]
- Indicate when no files were uploaded to field with a dash. [#43770]
- Migrate form field blocks to use new inner label, input, option, and options blocks. [#43765]
- Update package dependencies. [#43766]

## [1.0.0] - 2025-06-03
### Added
- Forms: Add events for integrations toggling and card expansion. [#43716]

### Changed
- Update package dependencies. [#43718] [#43734]

## [0.56.0] - 2025-06-02
### Added
- Add tracking pixel to form submission emails to know if emails are being opened (no user info is sent). [#43629]
- Add events to Forms dashboard pages. [#43686]
- Add page to announce that forms moved to Jetpack > Forms menu. [#43620]
- Reinstate sending submission email when user moves response from spam to inbox. [#43559]
- Use translated screenshot on dashboard migration page. [#43693] [#43707]

### Changed
- Add mobile-friendly styles and screenshot on Forms migration page. [#43664]
- Add context to About tab translation. [#43708]
- Add translation hint for Trash terminology. [#43704]
- Change action button placement on mobile. [#43605]
- Create a new page instead of post when creating a new form from dashboard. [#43668]
- Create form patterns from About page. [#43608]
- Enable feature filters by default to migrate forms dashboard page and menu. [#43705]
- Indicate in sidebar if no integrations enabled. [#43547]
- Update inbox header to use latest component features. [#43680]
- Update styles, labels and copy edits for integrations modal and tab. [#43666]
- Update package dependencies. [#43712]

### Removed
- Disable default listing UI for Feedback post types if the menu item is removed. [#43657]

### Fixed
- Contact Form: Use `wp_kses_post` instead of `esc_html` when rendering legend to allow safe HTML in fieldset legends. [#43639]
- File Upload field: Show upload progress when reduced motion is enabled. [#43628]
- Remove dependency from `jetpack-mu-wpcom-plugin`. [#43627]

## [0.55.0] - 2025-05-26
### Added
- Add "Create Form" button to dashboard header. [#43529]
- Add feature filter flags and code for moving submenu item from Feedback > Forms responses to Jetpack > Forms. [#43295]
- Add Integration screen content. [#43530]
- Add integration tab with feature flag. [#43502]

### Changed
- Address styles design on integrations tabs and modal. [#43576]
- Update package dependencies. [#43516] [#43578]

### Fixed
- Apply maximum width on Salesforce ID input. [#43543]
- Ensure admin notice on classic view does not show on all screens. [#43582]
- Fix Akismet spam URL. [#43542]
- Remove the ability to upload multiple files at using the same file upload field. This field is not yet released. [#43555]

## [0.54.0] - 2025-05-19
### Added
- Add Google Drive to integrations modal. [#43479]

### Changed
- Get Google status with new `useIntegrationStatus` hook. [#43463]
- Update Google Sheets icon. [#43501]
- Update Salesforce icons. [#43487]
- Dashboard: Fix container height to consistently fit on view. [#43485]
- Update package dependencies. [#43398]

## [0.53.0] - 2025-05-15
### Added
- Add 33% width option to fields and button. [#43417]

### Changed
- Add Google to form integrations endpoint. [#43453]
- Change copy of upsell banner for File Upload block. [#43395]
- Simplify dropzone area and settings for File Upload field. [#43471]

### Fixed
- Fix a bug preventing responses dashboard from loading (blank screen). [#43460]
- Fix double scrollbars for responses. [#43462]
- Fix Google Connect button styling. [#43440]

## [0.52.0] - 2025-05-12
### Added
- Add Typescript support. [#43394]
- Unify icons and add Creative Mail to About page. [#43414]
- Update the email template for feedback responses. [#43323]

### Changed
- Move Salesforce to block modal. [#43297]
- Replace Landing page with About page. [#43361]
- Update form responses tabs. [#43358]
- Update list of files distributed in stable version of the package. [#43310]
- Update package dependencies. [#43400]

### Removed
- Remove Salesforce Form variation. [#43419]

### Fixed
- Adjust export button mobile styles. [#43381]
- Fix block modal mobile styling. [#43422]
- Fix responses toggle background. [#43377]
- Preserve responses query parameters. [#43372]
- Prevent submenu from interfering with Crowdsignal/Polldaddy submenu items. [#43385]
- Show export button only on responses tab. [#43374]
- Improve Success and Email messages. [#43380]
- Remove unused `block.json` for the File field to prevent it from showing in the WP.org blocks list. [#43387]

## [0.51.0] - 2025-05-05
### Added
- File Upload field: Add registration with plan check. [#43177]
- Add tabs to forms dashboard. [#43280]

### Changed
- Don't show colon after question mark for form labels. [#43307]
- Polish integration modal style and copy. [#43252]
- Remove default spacing from variations. [#43342]
- Use WordPress.com specific URLs at about page. [#43341]
- Update package dependencies. [#43314] [#43326] [#43350] [#43355]

### Deprecated
- Drop WP 6.6 support in Inbox by using new format for useResizeObserver. [#43343]

### Fixed
- Ensure forms modal handles services. [#43336]
- Fix Google Drive connection button style and streamline connection. [#43245]
- Linting: Address final rules in WordPress Stylelint config. [#43296]
- Linting: Do additional stylesheet cleanup. [#43247]

## [0.50.0] - 2025-04-28
### Added
- Add integration status to block sidebar. [#43178]
- Add tests for integrations endpoint. [#43236]
- Add Tracks to block modal. [#43174]

### Changed
- Always show "View action" in inbox. [#43185]
- Have integrations endpoint return array instead of object. [#43183]
- Redirect from `/landing` to `/responses` if there are form responses. [#42854]
- Update email HTML template. [#43093]
- Use componentry instead of CSS for some elements in integrations modal. [#43117]

### Removed
- Remove unused integrations code. [#43211]

### Fixed
- Avoid overwriting form values when field names are repeated. [#43140]
- File Field: Improve code style in interactivity layer. [#43201]
- Fix empty file field error case. [#43173]
- Fix max file size upload check. [#43142]
- Fix toggle deprecation warning. [#43218]
- Linting: Fix more Stylelint violations. [#43213]
- Linting: Remove outdated vendor prefixes in stylesheets. [#43219]

## [0.49.0] - 2025-04-21
### Added
- Add new integrations setup modal. [#43057]

### Changed
- Block registration: Do not display the block in the editor for non-admins when the feature is not active. [#40209]
- Add entry to integations modal in block toolbar. [#43126]
- Add tooltips to integration modal plugin CTAs. [#43102]
- Add tooltips to the toggle in integrations modal. [#43080]
- Remove colon after question mark for form labels. [#43133]
- Hide integrations modal CTA in the sidebar for Simple sites. [#43079]
- Reduce default padding in form patterns. [#43124]
- Update modal to use `VStack` and WP icons. [#43084]
- Inbox: Render source consistently in list and details view. [#43131]
- Load editor styles from metadata file. [#42751]

### Fixed
- Fix Creative Mail SVG issue. [#43112]
- Prevent Google Drive connection attempt without Jetpack user account connection. [#43121]
- Update form responses link on editor sidebar. [#43143]

## [0.48.0] - 2025-04-15
### Changed
- Polish integrations modal. [#43064]

## [0.47.0] - 2025-04-14
### Changed
- Close block panels by default. [#42953]
- Simplify IntegrationCardBody content. [#43020]
- Update IntegrationCard markup and styles. [#43017]

### Fixed
- Center pattern button in Form block placeholder. [#42968]
- Ensure form field hook returns string. [#43011]
- Fix IntegrationCardHeader toggle styles. [#42942]
- Fix integration modal tracks events. [#42945]
- Linting: Clean up various Stylelint violations. [#43010]
- Linting: Update stylesheets to use WordPress rules for fonts and colors. [#42920] [#42928]
- Linting: Use double colon notation for pseudo-element selectors. [#43019]

## [0.46.0] - 2025-04-07
### Added
- Add controls to IntegrationCard header. [#42930]
- Add custom hooks for integrations. [#42822]
- Add header, body, and button components to integrations modal. [#42903]
- Add endpoint for all integrations. [#42878]
- Add progress and errors to the form upload field. [#42845]
- Update CRM integration to hooks. [#42831]

### Changed
- Add default file label. [#42801]
- Add consent toggle to Creative Mail card. [#42874]
- Add brand icons for integrations modal. [#42870]
- Change default submissions view to dataviews. [#42329]
- Change path and return for form integrations endpoint. [#42826]
- Linting: First pass of style coding standards. [#42734]
- Move shared integration card logic. [#42908]
- Reorganize form integration modal code. [#42918]
- Update Creative Mail integration to hooks. [#42762] [#42806] [#42809] [#42828]

### Fixed
- Ensure response management compatibility with WordPress 6.6. [#42883]

## [0.45.0] - 2025-03-31
### Added
- Add third-party integration endpoint. [#42730]
- Add File Upload field prototype. [#42695]

### Changed
- Add block integrations modal with feature flag. [#42747]
- Create IntegrationCard component. [#42771]
- Update button styles in inspector controls. [#42769]
- Update IntegrationCard header markup and style. [#42772]
- Update dependencies. [#42678]

### Fixed
- Components: Update controls to prevent more deprecation notices. [#42677]
- Fix sorting of responses in Classic view. [#42764]
- Fix WordPress `useSelect` warning. [#42675]

## [0.44.0] - 2025-03-24
### Changed
- Update editor sidebar copy. [#42642]
- Update dependencies. [#42564]

### Fixed
- Components: Prevent deprecation notices by adding `__next40pxDefaultSize` to controls. [#42576]
- Fix `source` filtering in Classic view for responses management. [#42641]
- Prevent custom label font sizes from breaking animated label font size reduction. [#42248]
- Placeholder should always display if it's a non-empty string. [#42173]

## [0.43.0] - 2025-03-18
### Added
- Add a quick link to the admin bar to form entries. [#42474]

### Changed
- Remove Google Drive beta badge. [#42481]
- Remove Salesforce beta badge. [#42482]
- Update package dependencies. [#42511]

## [0.42.1] - 2025-03-17
### Fixed
- Fix core list bullets not showing. [#42440]

## [0.42.0] - 2025-03-12
### Added
- Provide connection data to footer component. [#42000]

### Changed
- Remove default padding around forms. [#42340]
- Remove the Jetpack footer on modal. [#42341]
- Update response management with DataViews. [#41602]
- Update package dependencies. [#42384]

### Fixed
- Adjust spacing around DataViews table. [#42348]
- Fix issue where multiple contact forms on the same page would fail to submit correctly. [#42345]
- Update date validation method by removing jQuery. [#41698]
- Update the preview for the different block variations. [#42366]

## [0.41.0] - 2025-03-10
### Added
- Add Akismet panel to form block. [#41826]

## [0.40.0] - 2025-03-03
### Added
- Add min/max options to number field. [#41783]

### Changed
- Contact Form: Updated editor styles for improved UI consistency and better alignment of form elements. [#42112]
- Add accessible name field to advanced settings. [#42101]
- Simplify placeholder block. [#42141]
- Use placeholder attribute in editor instead of value. [#41712]
- Update package dependencies. [#42163]

### Fixed
- Fix warnings when post author is not available. [#42115]
- Ensure fields that skip rendering (like empty options fields) do not trigger validation or show value in form submission response. [#41979]
- Fix 404 error when a user submits an invalid form with JavaScript disabled. [#41947]
- Fix field name set as label when trying to empty label. [#42125]
- Show plugin integrations on Atomic. [#42073]

## [0.39.0] - 2025-02-24
### Changed
- Add Tracks when connecting Google Drive. [#41825]

### Fixed
- Fix `empty form` check for select elements. [#41846]
- Update block editor tracks events. [#41824]

## [0.38.0] - 2025-02-17
### Added
- Forms block: Add number input. [#40962]

### Changed
- Add tracking for plugin installations. [#41732]

### Fixed
- Fix error setting for field. [#41715]
- Fix missing translations in choice field settings. [#41719]
- Fix syncing of shared styles for nested fields. [#41708]
- Vertically align submit button in single row. [#41576]

## [0.37.1] - 2025-02-11
### Fixed
- Fix missing translations. [#41671]

## [0.37.0] - 2025-02-10
### Added
- Add a new file upload field block to allow visitors to upload files through contact forms. [#41582]
- Add support for having multiple forms across paginated pages. [#41407]
- Update fields and button blocks to support contentOnly editing. [#41411]
- Tests: Verify empty forms do not submit. [#41504]

### Changed
- File Upload Field block: Use WordPress upload icon and follow consistent field patterns (currently in beta). [#41586]
- Track forms submissions in order to improve the product. [#41307]
- Update package dependencies. [#41491]

### Fixed
- Fix submit button width and alignment. [#41139]
- Fix block style variations not showing in the editor. [#41457]
- Fix the date format input if multiple date pickers are used with different date formats. [#41611]
- Fix invalid HTML IDs. [#41564]
- Hide fields without options. [#41443]
- Improve the styling options of the separator block when placed inside the form block. [#40967]

## [0.36.0] - 2025-02-03
### Added
- Prevent empty client-side form submission. [#41464]

### Changed
- Remove legacy code and improve code quality. [#41348]
- Rename contact form block placeholder to "Forms". [#41384]
- Update package dependencies. [#41286]

### Fixed
- Add wrapping div to the core HTML block when inserted inside the form block. [#41269]
- Code: Remove extra params on function calls. [#41263]
- Feedback: Fix encoding when going from spam to regular type. [#41359]
- Feedback: Fix missing spacing bug in list view. [#41367]
- Fix date picker styles in dark themes. [#41342]
- Fix field spacing and widths. [#41415]
- Fix permanent deletion of form reponses via quicklinks. [#41321]
- Fix submission when date field errored. [#41511]
- Hide empty radio fields. [#41379]
- Prevent empty style values within form field block attributes. [#41206]
- Prevent error in block placeholder when the Forms module is disabled. [#41382]
- Translations: Fix spam % character. [#41345]

## [0.35.1] - 2025-01-27
### Added
- Add Checkbox and Consent field enter action to create a new block. [#41297]
- Create new default block when pressing Enter on text inputs. [#41177]

### Changed
- Remove wrapping <div> element from form block. [#41274]

### Fixed
- Add missing deprecation for checkboxes and radio fields. [#41198]
- Fix the default checkstate for admins. [#40847]
- Add unique ids to each form. [#40998]
- Fix send to settings for multiple authors. [#41290]
- Make the icons show up as expected in the style editor. [#41314]
- Update the icon colours to the new standard. [#41250]

## [0.35.0] - 2025-01-20
### Added
- Forms: Allow HTML block within forms. [#41040]
- Forms: Handle `Enter` on empty radio/checkbox input. [#41082]

### Changed
- Code: Use function-style exit() and die() with a default status code of 0. [#41167]
- Forms: rename "URL" field to "Website" [#41029]
- Forms: settings, opt-in for default 40px size in gutenberg [#41127]
- Forms: update width control to use more modern ToggleGroupControl [#41130]
- Forms: use core icons for phone and email fields [#41034]
- Updated package dependencies. [#41099]

### Fixed
- Forms: Fix dropdown icon styling. [#41074]
- Forms: Fix redirect field styles [#41030]
- Forms: fix spacing issue in sidebar settings [#41133]
- Forms: Properly support formatting options for labels and required text [#40924]

## [0.34.6] - 2025-01-13
### Fixed
- Add webpack plugin to rename RTL files to match core WP expectations. [#40881]
- Show email only in form submission view if name is empty. [#40898]
- Forms: Fix success message color inside a dark Cover block. [#40917]
- Forms: Update default URL field label to match front-end. [#40921]

## [0.34.5] - 2025-01-06
### Changed
- Updated package dependencies. [#40705] [#40784] [#40792] [#40800] [#40831]

### Fixed
- Form block: Fix submit button styles when there are errors. [#40762]

## [0.34.4] - 2024-12-16
### Changed
- Updated package dependencies. [#40564]

### Fixed
- Form Block: Fix validation of URL input types to allow query strings. [#40490]

## [0.34.3] - 2024-12-09
### Changed
- Updated package dependencies. [#40363]

## [0.34.2] - 2024-11-26
### Changed
- Update dependencies.

## [0.34.1] - 2024-11-25
### Changed
- Updated dependencies. [#40286]
- Updated package dependencies. [#40288]

### Fixed
- Forms: fixed arrow positioning on select elements [#40206]

## [0.34.0] - 2024-11-18
### Removed
- General: Update minimum PHP version to 7.2. [#40147]

### Fixed
- Fix a fatal error occurring due to a function receiving an unexpected input type. [#40183]

## [0.33.8] - 2024-11-11
### Changed
- Updated package dependencies. [#39999] [#40060]

## [0.33.7] - 2024-11-04
### Added
- Enable test coverage. [#39961]

### Fixed
- Fix PHPUnit coverage warnings. [#39989]

## [0.33.6] - 2024-10-29
### Changed
- Components: Add __nextHasNoMarginBottom to BaseControl-based components, preventing deprecation notices. [#39877]

## [0.33.5] - 2024-10-28
### Changed
- Updated package dependencies. [#39910]

## [0.33.4] - 2024-10-21
### Changed
- Update dependencies. [#39781]

## [0.33.3] - 2024-10-14
### Changed
- Only include `wp-polyfill` as a script dependency when needed. [#39629]
- Updated package dependencies. [#39707]

### Fixed
- Improve security of the form endpoint. [#39759]

## [0.33.2] - 2024-10-07
### Changed
- Updated package dependencies. [#39594]

## [0.33.1] - 2024-09-30
### Changed
- Internal updates.

## [0.33.0] - 2024-09-23
### Added
- New filter to allow for excluding the contact form submission IP from being saved or e-mailed. [#39395]

### Changed
- Options: Get selection from the element's document instead of the global `window`. [#39364]
- Refactor Choice fields [#39141]

## [0.32.16] - 2024-09-16
### Changed
- Email submissions: on sites using www., ensure that the sending email address does not use the www. prefix. [#39370]

### Fixed
- Use en-dash in numeric range in i18n message to conform to guidelines. [#39305]

## [0.32.15] - 2024-09-10
### Changed
- Updated package dependencies. [#39302]

## [0.32.14] - 2024-09-09
### Changed
- Updated package dependencies. [#39176] [#39278]

### Fixed
- Contact Forms: added checks for unexpected contents of textarea elements. [#39271]

## [0.32.13] - 2024-09-04
### Changed
- Check for private and password-protected posts when handling the contact form submissions. [#39238]

## [0.32.12] - 2024-09-02
### Changed
- Forms: update child blocks to Block API v3 [#38916]
- Updated package dependencies. [#39111]

## [0.32.11] - 2024-08-26
### Changed
- Updated package dependencies. [#39004]

## [0.32.10] - 2024-08-21
### Changed
- Internal updates.

## [0.32.9] - 2024-08-19
### Changed
- Updated package dependencies. [#38662]

### Fixed
- Lossless image optimization for images (should improve performance with no visible changes). [#38750]

## [0.32.8] - 2024-08-12
### Added
- React 19 compatibility: Making sure useRef includes an argument. [#38765]

## [0.32.7] - 2024-08-05
### Changed
- React compatibility: Changing ReactDOM.render usage to be via ReactDOM.createRoot. [#38649]

## [0.32.6] - 2024-07-29
### Changed
- Update dependencies. [#38558]

## [0.32.5] - 2024-07-22
### Fixed
- Block Picker: Fixed display of the picker in the block editor following changes in WordPress 6.6. [#38406]
- Form Submissions Table: Ensured the IP address is displayed for each submission, when available. [#38352]

## [0.32.4] - 2024-07-15
### Changed
- Internal updates.

## [0.32.3] - 2024-07-08
### Changed
- Updated package dependencies. [#38132]

## [0.32.2] - 2024-06-24
### Changed
- Update dependencies. [#37979]

## [0.32.1] - 2024-06-17
### Changed
- Updated package dependencies. [#37796]

## [0.32.0] - 2024-06-10
### Changed
- Change codebase to use clsx instead of classnames. [#37708]
- Updated package dependencies. [#37669] [#37706]

### Fixed
- Allow users to add multiple options to a dropdown field [#37739]
- Avoid PHP notice when form is submitted to the wrong URL [#37672]

## [0.31.4] - 2024-05-27
### Changed
- Update dependencies.

## [0.31.3] - 2024-05-20
### Changed
- Forms: Ensure non-minified JS file location is also an option when loading the tiny-mce-plugin-form-button script file. [#37351]
- Updated package dependencies. [#37379] [#37380] [#37382]

## [0.31.2] - 2024-05-13
### Changed
- Update dependencies. [#37280]

## [0.31.1] - 2024-05-07
### Fixed
- Contact Form: Prevent an editor error when using the Classic Editor and contact forms are enabled. [#37270]

## [0.31.0] - 2024-05-06
### Added
- Add missing package dependencies. [#37141]

### Changed
- Updated package dependencies. [#37147]

### Removed
- Contact Form: Removing code and renaming relevant references to ensure we use the package version of the contact form. [#37157]

### Fixed
- Fix reference to `Jetpack_Options` class in `Contact_Form_Plugin::record_tracks_event()`. [#37201]

## [0.30.18] - 2024-04-29
### Changed
- General: Use wp_admin_notice function introduced in WP 6.4 to display notices. [#37051]

## [0.30.17] - 2024-04-25
### Fixed
- Set correct `textdomain` in `block.json`. [#37057]

## [0.30.16] - 2024-04-22
### Changed
- Internal updates.

## [0.30.15] - 2024-04-15
### Changed
- Update dependencies. [#36848]

## [0.30.14] - 2024-04-08
### Changed
- Updated package dependencies. [#36760]
- Update to the most recent version of Color Studio, 2.6.0. [#36751]

## [0.30.13] - 2024-03-27
### Changed
- Updated package dependencies. [#36585]

### Fixed
- Enable undoing adding a contact form [#36485]

## [0.30.12] - 2024-03-25
### Changed
- Made some Contact_Form methods publicly available [#36137]

## [0.30.11] - 2024-03-18
### Fixed
- Dashboard: add missing Connection state to the page. [#36406]
- Dashboard: avoid JS errors when content disposition is not set. [#36406]

## [0.30.10] - 2024-03-12
### Changed
- Update code references in docs and comments [#36234]
- Updated package dependencies. [#36325]

## [0.30.9] - 2024-03-12
### Fixed
- Performance: avoid querying for posts on all pages of the dashboard, and only do so on Feedback admin pages. [#36230]

## [0.30.8] - 2024-03-04
### Changed
- Updated package dependencies.

### Fixed
- Contact Form: make constrained inputs full-width on mobile [#36000]

## [0.30.7] - 2024-02-27
### Changed
- Update dependencies.

## [0.30.6] - 2024-02-26
### Deprecated
- Deprecate the temporary tmp_grunion_allow_editor_view filter. [#35584]

## [0.30.5] - 2024-02-13
### Changed
- Updated package dependencies. [#35608]

## [0.30.4] - 2024-02-12
### Fixed
- Dashboard: improve the display of the dashboard to non-admins. [#35571]
- Forms: fix multiple and single choice fields button style [#35456]

## [0.30.3] - 2024-02-05
### Changed
- Asset enqueuing: switch to enqueuing strategy introduced in WordPress 6.3. [#34072]
- Updated package dependencies.

### Fixed
- Center submit button content horizontally [#35319]

## [0.30.2] - 2024-01-29
### Changed
- Update dependencies.

## [0.30.1] - 2024-01-22
### Added
- Contact Form: test setup for front end script [#35074]

## [0.30.0] - 2024-01-08
### Changed
- Updated useModuleStatus hook to use module_status redux store. [#34845]
- Use useModuleStatus hook instead of direct call of store selectors. [#34856]

### Fixed
- Avoid PHP warnings when post is not set. [#34886]

## [0.29.2] - 2024-01-04
### Changed
- Updated package dependencies. [#34815]

## [0.29.1] - 2024-01-02
### Changed
- Made module updates more precise in the modules store. [#34801]

## [0.29.0] - 2023-12-25
### Added
- Contact Form: add accessible name to form [#34667]
- Contact Form: add date format to date picker [#34743]

### Fixed
- Contact Form: suppress PHP warning [#34756]

## [0.28.0] - 2023-12-20
### Added
- Contact Form: add extra field settings to base field. [#34704]

### Changed
- Contact Form: minify stylesheets in prod. [#34672]

## [0.27.0] - 2023-12-15
### Added
- Contact Form: improve form error message [#34629]

### Changed
- Form block: hide 'lead capture' variation for WP.com Atomic sites [#34615]

### Fixed
- Contact Form: add missing Required toolbar button to Checkbox field [#34630]
- Contact Form: align half-width fields on same row [#34632]

## [0.26.0] - 2023-12-14
### Added
- Contact Form: build JS assets [#34622]

### Fixed
- Avoid PHP warnings when methods are called too early. [#34576]

## [0.25.0] - 2023-12-11
### Added
- Contact Form: Added submitting state. [#34367]
- Contact Form: Improved form error message. [#34520]
- Contact Form: Added revalidation for fields on focus out. [#34401]
- Contact Form: Added revalidation for missing value as the user types. [#34518]

### Changed
- Contact Form: Aligned checkbox and radio button baselines. [#34429]
- Contact Form: Refactored accessible-form.js. [#34400]
- Updated package dependencies. [#34416]

### Fixed
- Contact Form: Added margin below global error message. [#34447]
- Contact Form: Ensured warning icons are visible. [#34455]
- Contact Form: Fixed checkbox field layout in editor. [#34405]
- Contact Form: Replaced jQuery UI select by native element. [#34441]
- Contact Form: Specified version for accessible-form script. [#34457]
- Fixed potential undefined variable access in Contact_Form_Plugin. [#34500]

## [0.24.2] - 2023-12-03
### Added
- Made forms a screen reader region. [#34344]

### Changed
- Improved checkbox field design. [#34272]
- Updated package dependencies. [#34411] [#34427]

### Fixed
- Fixed PHP warnings that occurred when processing malformed data. [#34386]
- Added focus state to radio buttons and checkboxes. [#34408]
- Fixed styling issues for Outlined and Animated styles. [#34272]
- Made Contact Form error fixing accessible. [#34173]

## [0.24.1] - 2023-11-24
### Changed
- Replaced usage of strpos() with str_contains(). [#34137]
- Replaced usage of substr() with str_starts_with() and str_ends_with(). [#34207]
- Fixed markup accessibility issues for Contact Form's single and multiple choice inputs. [#34147]
- Updated form blocks to prioritize the use of form elements in the block inserter. [#34247]

### Fixed
- Improved Contact Form required label contrast. [#34237]
- Updated `Admin::grunion_ajax_shortcode()` to use the correct sorting function. [#34230]

## [0.24.0] - 2023-11-20
### Changed
- Replaced usage of strpos() with str_starts_with(). [#34135]
- Updated required PHP version to >= 7.0. [#34192]

### Fixed
- Added an accessible name to the Contact Form dropdown rendered in the front-end. [#34139]
- Avoid errors when a saved feedback form does not have the expected WP_Post format. [#34129]

## [0.23.1] - 2023-11-14
### Changed
- Updated package dependencies. [#34093]

## [0.23.0] - 2023-11-13
### Changed
- Updated 'useModuleStatus' to use the new Jetpack modules store. [#33397]

## [0.22.6] - 2023-11-03

## [0.22.5] - 2023-10-31
### Fixed
- Fixes style for multiple choice checkbox in Froms block. [#33827]

## [0.22.4] - 2023-10-23
### Changed
- Updated package dependencies. [#33646] [#33687]

## [0.22.3] - 2023-10-16
### Changed
- Updated package dependencies. [#33429]

## [0.22.2] - 2023-10-10
### Changed
- Updated package dependencies. [#33428]

## [0.22.1] - 2023-09-28
### Changed
- Minor internal updates.

## [0.22.0] - 2023-09-19
### Changed
- Moving block registration when plugin activated [#33050]
- Updated package dependencies. [#33001]

## [0.21.0] - 2023-09-04
### Added
- Add Jetpack AI Form section to new Forms landing page [#32726]

### Changed
- Updated package dependencies. [#32803] [#32804]

### Fixed
- Fix block icons for display on wp.org [#32754]

## [0.20.1] - 2023-08-28
### Changed
- Updated package dependencies. [#32605]

## [0.20.0] - 2023-08-21
### Added
- Add block.json file to Contact Form block [#32583]
- Forms block - allow transforming to a subscribe block. [#32478]

### Changed
- Forms block: rename "Newsletter Connection" to "Creative Mail" to avoid confusing with "Jetpack Newsletters" and subscription block. Call the block a "Lead Capture" block (not sign up). [#32481]

## [0.19.11] - 2023-08-14
### Changed
- Add a unified/consistent visual aid for focused elements. [#30219]

## [0.19.10] - 2023-08-09
### Changed
- Updated package dependencies. [#32166]

## [0.19.9] - 2023-08-07
### Added
- Added SIG modal ui [#31665]

## [0.19.8] - 2023-07-25
### Changed
- Updated package dependencies. [#32040]
- Update the name of the Newsletter Sign-up Variation. [#31998]

## [0.19.7] - 2023-07-17
### Changed
- Updated package dependencies. [#31785]

### Fixed
- Avoid Fatal errors when exporting fields that were not saved with the correct value. [#31858]
- Fix Forms dropdown required validation [#31894]

## [0.19.6] - 2023-07-05
### Changed
- Remove the default title ("You got a new response!") added to emails sent for new feedback received. [#31667]
- Updated package dependencies. [#31659]

## [0.19.5] - 2023-06-26
### Changed
- Updated package dependencies.

## [0.19.4] - 2023-06-12
### Removed
- Jetpack Forms: remove the links in the response emails sent to site owners [#31270]

## [0.19.3] - 2023-06-06
### Changed
- Updated package dependencies. [#31129]

### Fixed
- Editor view: remove duplicated Add Contact Form button. [#31158]

## [0.19.2] - 2023-05-30
### Changed
- Jetpack Forms: added basic email template [#31026]

## [0.19.1] - 2023-05-29
### Changed
- Internal updates.

## [0.19.0] - 2023-05-22
### Fixed
- Forms: Attempt to fix Forms hash generation [#30764]

## [0.18.0] - 2023-05-18
### Added
- Akismet: include current gmt time to assist in spam detection [#30755]
- Jetpack Forms: improving the styling of response emails [#30088]

### Fixed
- Change hook parameter to what it was before (fields collection). Modify Post_To_Url hook to handle such collection instead of a form instance [#30744]

## [0.17.0] - 2023-05-15
### Added
- Forms: Add style customization options for the MC/SC field buttons style [#30526]
- Forms: Create dashboard landing page [#30161]
- The new Jetpack Forms feedback WP Admin page is now enabled. The old page remains the default for the time being and all users can opt-in to see the new interface by using the 'view' swtich in the top right corner. [#30515]

### Changed
- Forms: Enable Forms landing page redirection logic [#30605]
- Forms: Remove Forms landing page redirection logic [#30548]
- Provide default data sets for responses data to avoid PHP warnings on undefined array keys [#30520]

### Fixed
- Add salesforce form variation alongside default variations for better discoverability. Fix private method for action trigger [#30562]

## [0.16.0] - 2023-05-08
### Added
- Added URL-based navigation support for the new forms dashboard [#30367]
- Add inspector ID/name settings for form fields [#30260]

### Changed
- Do not normalize feedback posts main comment when possible, allowing fexports to not guess which is the Comment and simply adding a column with the input's label [#30475]
- Forms: Introduce Multiple Choice and Single Choice style variations [#30319]
- Forms: Update Multiple Choice and Single Choice fields Sidebar style settings [#30437]
- Updated border radius on forms dashboard cards [#30466]
- Update Forms pattern modal default view to Grid [#28906]
- We will not be re-sending emails when marking items as not-spam in the new forms dashboard. [#30356]

### Fixed
- Add necessary context to the word "Trash". [#30507]
- Change post_type comparison on untrash filter to only affect feedback posts [#30464]
- Ensure array is provided to array_diff_key to avoid warnings [#30317]
- Fix dropdown menu not working due to some CSS issues [#30409]
- Fixed class names for the response on the JP Forms dashboard. [#30468]
- Fixed the hitbox for the source link on the forms dashboard response list. [#30469]
- Forms: Fix Forms response meta date value [#30189]

## [0.15.0] - 2023-05-02
### Added
- Added a 'Copy' button for emails on the Jetpack forms dashboard response tab. [#30256]

### Changed
- Rows in the forms dashboard will now be dynamically removed and appended when performing bulk actions. [#30213]
- Updated package dependencies.

### Fixed
- Ensure IP address can be properly displayed for all form submissions. [#29491]
- Fixed an issue causing the forms dashboard view setting not to be saved on WP.com. [#30258]
- Fixed buggy behavior of loading placeholders in the forms dashboard. [#30353]
- Fixed invalid totals being reported for different tabs in the forms dashboard. [#30354]
- Forms: Fix Forms dashboard Multiple Choice response format. [#30370]

## [0.14.1] - 2023-05-01
### Changed
- Internal updates.

## [0.14.0] - 2023-04-25
### Added
- Added an animation for the responses tab on the forms dashboard. [#30152]
- Added counters on the tabs in the Jetpack Forms dashboard [#30252]
- Reinstate salesforce integration with a generic post-to-url hook [#30191]

### Fixed
- Fixed html entities not displaying correctly in the forms dashboard [#30257]

## [0.13.0] - 2023-04-17
### Added
- Added a 'Check for spam' button to the new feedback dashboard. [#29963]
- Added style overrides for the forms dashboard on WP.com [#29915]

### Changed
- Forms: Update Forms child blocks to allow any transformation between the blocks [#29978]
- Forms: Update forms dashboard body font-size to 14px [#29956]
- Updated package dependencies. [#30019]

### Fixed
- Forms: Fix Forms styles when inside Cover blocks [#30075]
- Forms: Prevent response details meta values line breaking [#30017]

## [0.12.0] - 2023-04-10
### Added
- Add Jetpack Autoloader package suggestion. [#29988]

### Changed
- Forms: Add line on top of the response list when the actions menu is sticky [#29941]
- Forms: Dashboard finetunings round 2 [#29909]
- Forms: Update source column styles and trash action label [#29970]

## [0.11.0] - 2023-04-04
### Added
- Export modal for the new JP Forms dashboard. [#29775]
- Forms: Add single actions menu to the Dashboard inbox view [#29848]
- Forms: Create response inbox filters [#29694]

### Changed
- Disregard post_status when calculating available filters for form responses. [#29817]
- Forms: Dashboard finetunings [#29789]
- Forms: Include bulk actions menu [#29766]
- Forms: Update Dashboard inbox columns responsiveness and sticky items style [#29914]
- Updated form responses endpoint to embed available filter data. [#29805]
- Updated package dependencies. [#29854] [#29857]

### Fixed
- Made feedback bulk actions more explicit and easier to work with. [#29884]

## [0.10.2] - 2023-04-03
### Changed
- Internal updates.

## [0.10.1] - 2023-03-28
### Changed
- Minor internal updates.

## [0.10.0] - 2023-03-27
### Added
- Add all source post IDs on forms/responses endpoint [#29428]
- Added an endpoint for performing bulk actions on feedback responses. [#29682]
- Forms: Add Tabs to Forms dashboard inbox view [#29652]

### Changed
- Add a check for array on $attributes before trying to set an item on it [#29557]
- Add search input and styles [#29397]
- Change default entries per page on responses inbox [#29406]
- Feedback responses endpoint now allows filtering by post status and returns all totals. [#29589]
- Forms: Adjust Forms inbox view columns responsiveness [#29666]
- Forms: Update Forms inbox view responses styles [#29660]
- Jetpack Forms: changed "message sent" tracking from Tracks to bump stat. [#29383]
- Jetpack Forms: Change default entries per page on responses inbox [#29701]
- Jetpack Forms: display carriage returns in responses in the Feedback->Form Responses page. [#29698]
- Jetpack Forms: json_encode form responses instead of using print_r. [#29664]
- Upgrade package number [#29457]

### Fixed
- Refactored state management for forms dashboard [#29684]
- Use Contact_Form_Plugin::init instead of requiring the old module file [#29648]

## [0.9.0] - 2023-03-20
### Added
- Jetpack Forms: Add tracking of Google Sheets exports [#29225]

### Changed
- Rollback rename of columns/fields on export [#29448]
- Updated package dependencies. [#29471]

### Fixed
- Avoid PHP notices when using a form with a dropdown field. [#29512]
- Fix Forms previews on Forms package [#29359]

## [0.8.0] - 2023-03-13
### Added
- Added a 'view' toggle for switching between the new and old feedback views. [#29246]
- Added tracking of Jetpack Forms exports to CSV files. [#29102]

### Changed
- Better handling for loading state and empty results [#29387]
- Move action bar components out of inbox [#29360]
- Move BulkActionsMenu component inside Inbox, too tailored to be reused [#29386]
- Multiple Choice and Single Choice fields redesign [#29290]

### Fixed
- Avoid Fatal errors by calling method from the right class in the paackage. [#29391]

## [0.7.0] - 2023-03-08
### Added
- Add weekly/monthly props to sent message tracking [#28999]
- Add form responses app and state into package (out of plugin) [#29007]
- Fix search by invalidating resolution on the selector [#29259]
- Implement RWD navigation for feedback dashboard [#29315]

### Changed
- Forms: Move field width settings and remove placeholder field from MC/SC fields [#29292]
- Updated package dependencies. [#29216]

### Fixed
- Add defaults for Jetpack Forms CSS variables. [#29236]
- Fix table interactions for feedback dashboard [#29282]
- Forms Responses endpoint: fix permission check. [#29223]
- Move search into state, fix double fetch on search and paging [#29336]

## [0.6.0] - 2023-02-28
### Added
- Added a page navigation component for the new feedback dashboard [#28826]
- Add v2/v4 endpoint for form responses inbox [#29043]
- Allow Form fields style synchronization [#28988]
- Increase form fields padding based on user-defined border-radius [#28820]

### Changed
- Jetpack Forms dashboard now replaces the "Feedback" menu entry in WP Admin. [#29198]

### Fixed
- Remove body font normalization for on contact-form module and package [#29166]

## [0.5.1] - 2023-02-20
### Changed
- Minor internal updates.

## [0.5.0] - 2023-02-15
### Changed
- Update form-styles script to prevent blurred forms on slow loading pages [#28973]

## [0.4.0] - 2023-02-15
### Added
- Added response list table to the new feedback dashboard [#28821]
- Added the template for the response view in the new feedback dashboard [#28877]
- Add new method to reverse print_r output as stored on the feedback posts. Use it to try and parse the form fields, fallback to old method. [#28815]

### Changed
- Update to React 18. [#28710]

### Fixed
- Add filter to prevent contact-form-styles script from being concatenated [#28905]
- Configure with standard `@wordpress/browserslist-config` config. [#28910]
- Prevent Forms blur effect on AMP pages [#28926]

## [0.3.0] - 2023-02-08
### Added
- Add "watch" entries for both composer and package .json files. This allows us to run `jetpack watch packages/forms` while working on JS things [#28704]
- Add tooling for building the Jetpack Forms Dashboard [#28689]
- Moved contact form PHP files to automattic/jetpack-forms [#28574]
- Move Forms blocks to Forms package [#28630]

### Changed
- Forms: Update Form package with latest contact-form changes from trunk [#28752]
- Reorder export columns in 3 groups: response meta (title, source, date), response field values, response extra (consent, ip address) [#28678]

## [0.2.0] - 2023-01-26
### Added
- Moved contact form static files into the new forms package [#28417]

## 0.1.0 - 2023-01-23
### Added
- Added a new jetpack/forms package [#28409]
- Added a public load_contact_form method for initializing the contact form module. [#28416]

[8.4.0]: https://github.com/automattic/jetpack-forms/compare/v8.3.8...v8.4.0
[8.3.8]: https://github.com/automattic/jetpack-forms/compare/v8.3.7...v8.3.8
[8.3.7]: https://github.com/automattic/jetpack-forms/compare/v8.3.6...v8.3.7
[8.3.6]: https://github.com/automattic/jetpack-forms/compare/v8.3.5...v8.3.6
[8.3.5]: https://github.com/automattic/jetpack-forms/compare/v8.3.4...v8.3.5
[8.3.4]: https://github.com/automattic/jetpack-forms/compare/v8.3.3...v8.3.4
[8.3.3]: https://github.com/automattic/jetpack-forms/compare/v8.3.2...v8.3.3
[8.3.2]: https://github.com/automattic/jetpack-forms/compare/v8.3.1...v8.3.2
[8.3.1]: https://github.com/automattic/jetpack-forms/compare/v8.3.0...v8.3.1
[8.3.0]: https://github.com/automattic/jetpack-forms/compare/v8.2.2...v8.3.0
[8.2.2]: https://github.com/automattic/jetpack-forms/compare/v8.2.1...v8.2.2
[8.2.1]: https://github.com/automattic/jetpack-forms/compare/v8.2.0...v8.2.1
[8.2.0]: https://github.com/automattic/jetpack-forms/compare/v8.1.0...v8.2.0
[8.1.0]: https://github.com/automattic/jetpack-forms/compare/v8.0.3...v8.1.0
[8.0.3]: https://github.com/automattic/jetpack-forms/compare/v8.0.2...v8.0.3
[8.0.2]: https://github.com/automattic/jetpack-forms/compare/v8.0.1...v8.0.2
[8.0.1]: https://github.com/automattic/jetpack-forms/compare/v8.0.0...v8.0.1
[8.0.0]: https://github.com/automattic/jetpack-forms/compare/v7.26.0...v8.0.0
[7.26.0]: https://github.com/automattic/jetpack-forms/compare/v7.25.0...v7.26.0
[7.25.0]: https://github.com/automattic/jetpack-forms/compare/v7.24.0...v7.25.0
[7.24.0]: https://github.com/automattic/jetpack-forms/compare/v7.23.4...v7.24.0
[7.23.4]: https://github.com/automattic/jetpack-forms/compare/v7.23.3...v7.23.4
[7.23.3]: https://github.com/automattic/jetpack-forms/compare/v7.23.2...v7.23.3
[7.23.2]: https://github.com/automattic/jetpack-forms/compare/v7.23.1...v7.23.2
[7.23.1]: https://github.com/automattic/jetpack-forms/compare/v7.23.0...v7.23.1
[7.23.0]: https://github.com/automattic/jetpack-forms/compare/v7.22.6...v7.23.0
[7.22.6]: https://github.com/automattic/jetpack-forms/compare/v7.22.5...v7.22.6
[7.22.5]: https://github.com/automattic/jetpack-forms/compare/v7.22.4...v7.22.5
[7.22.4]: https://github.com/automattic/jetpack-forms/compare/v7.22.3...v7.22.4
[7.22.3]: https://github.com/automattic/jetpack-forms/compare/v7.22.2...v7.22.3
[7.22.2]: https://github.com/automattic/jetpack-forms/compare/v7.22.1...v7.22.2
[7.22.1]: https://github.com/automattic/jetpack-forms/compare/v7.22.0...v7.22.1
[7.22.0]: https://github.com/automattic/jetpack-forms/compare/v7.21.3...v7.22.0
[7.21.3]: https://github.com/automattic/jetpack-forms/compare/v7.21.2...v7.21.3
[7.21.2]: https://github.com/automattic/jetpack-forms/compare/v7.21.1...v7.21.2
[7.21.1]: https://github.com/automattic/jetpack-forms/compare/v7.21.0...v7.21.1
[7.21.0]: https://github.com/automattic/jetpack-forms/compare/v7.20.0...v7.21.0
[7.20.0]: https://github.com/automattic/jetpack-forms/compare/v7.19.0...v7.20.0
[7.19.0]: https://github.com/automattic/jetpack-forms/compare/v7.18.0...v7.19.0
[7.18.0]: https://github.com/automattic/jetpack-forms/compare/v7.17.0...v7.18.0
[7.17.0]: https://github.com/automattic/jetpack-forms/compare/v7.16.0...v7.17.0
[7.16.0]: https://github.com/automattic/jetpack-forms/compare/v7.15.0...v7.16.0
[7.15.0]: https://github.com/automattic/jetpack-forms/compare/v7.14.0...v7.15.0
[7.14.0]: https://github.com/automattic/jetpack-forms/compare/v7.13.0...v7.14.0
[7.13.0]: https://github.com/automattic/jetpack-forms/compare/v7.12.0...v7.13.0
[7.12.0]: https://github.com/automattic/jetpack-forms/compare/v7.11.0...v7.12.0
[7.11.0]: https://github.com/automattic/jetpack-forms/compare/v7.10.0...v7.11.0
[7.10.0]: https://github.com/automattic/jetpack-forms/compare/v7.9.0...v7.10.0
[7.9.0]: https://github.com/automattic/jetpack-forms/compare/v7.8.0...v7.9.0
[7.8.0]: https://github.com/automattic/jetpack-forms/compare/v7.7.0...v7.8.0
[7.7.0]: https://github.com/automattic/jetpack-forms/compare/v7.6.0...v7.7.0
[7.6.0]: https://github.com/automattic/jetpack-forms/compare/v7.5.0...v7.6.0
[7.5.0]: https://github.com/automattic/jetpack-forms/compare/v7.4.0...v7.5.0
[7.4.0]: https://github.com/automattic/jetpack-forms/compare/v7.3.0...v7.4.0
[7.3.0]: https://github.com/automattic/jetpack-forms/compare/v7.2.0...v7.3.0
[7.2.0]: https://github.com/automattic/jetpack-forms/compare/v7.1.0...v7.2.0
[7.1.0]: https://github.com/automattic/jetpack-forms/compare/v7.0.0...v7.1.0
[7.0.0]: https://github.com/automattic/jetpack-forms/compare/v6.22.0...v7.0.0
[6.22.0]: https://github.com/automattic/jetpack-forms/compare/v6.21.2...v6.22.0
[6.21.2]: https://github.com/automattic/jetpack-forms/compare/v6.21.1...v6.21.2
[6.21.1]: https://github.com/automattic/jetpack-forms/compare/v6.21.0...v6.21.1
[6.21.0]: https://github.com/automattic/jetpack-forms/compare/v6.20.0...v6.21.0
[6.20.0]: https://github.com/automattic/jetpack-forms/compare/v6.19.0...v6.20.0
[6.19.0]: https://github.com/automattic/jetpack-forms/compare/v6.18.0...v6.19.0
[6.18.0]: https://github.com/automattic/jetpack-forms/compare/v6.17.0...v6.18.0
[6.17.0]: https://github.com/automattic/jetpack-forms/compare/v6.16.0...v6.17.0
[6.16.0]: https://github.com/automattic/jetpack-forms/compare/v6.15.0...v6.16.0
[6.15.0]: https://github.com/automattic/jetpack-forms/compare/v6.14.0...v6.15.0
[6.14.0]: https://github.com/automattic/jetpack-forms/compare/v6.13.0...v6.14.0
[6.13.0]: https://github.com/automattic/jetpack-forms/compare/v6.12.0...v6.13.0
[6.12.0]: https://github.com/automattic/jetpack-forms/compare/v6.11.0...v6.12.0
[6.11.0]: https://github.com/automattic/jetpack-forms/compare/v6.10.0...v6.11.0
[6.10.0]: https://github.com/automattic/jetpack-forms/compare/v6.9.0...v6.10.0
[6.9.0]: https://github.com/automattic/jetpack-forms/compare/v6.8.0...v6.9.0
[6.8.0]: https://github.com/automattic/jetpack-forms/compare/v6.7.0...v6.8.0
[6.7.0]: https://github.com/automattic/jetpack-forms/compare/v6.6.0...v6.7.0
[6.6.0]: https://github.com/automattic/jetpack-forms/compare/v6.5.1...v6.6.0
[6.5.1]: https://github.com/automattic/jetpack-forms/compare/v6.5.0...v6.5.1
[6.5.0]: https://github.com/automattic/jetpack-forms/compare/v6.4.0...v6.5.0
[6.4.0]: https://github.com/automattic/jetpack-forms/compare/v6.3.0...v6.4.0
[6.3.0]: https://github.com/automattic/jetpack-forms/compare/v6.2.0...v6.3.0
[6.2.2]: https://github.com/automattic/jetpack-forms/compare/v6.2.1...v6.2.2
[6.2.1]: https://github.com/automattic/jetpack-forms/compare/v6.2.0...v6.2.1
[6.2.0]: https://github.com/automattic/jetpack-forms/compare/v6.1.0...v6.2.0
[6.1.0]: https://github.com/automattic/jetpack-forms/compare/v6.0.0...v6.1.0
[6.0.0]: https://github.com/automattic/jetpack-forms/compare/v5.5.0...v6.0.0
[5.5.0]: https://github.com/automattic/jetpack-forms/compare/v5.4.0...v5.5.0
[5.4.0]: https://github.com/automattic/jetpack-forms/compare/v5.3.0...v5.4.0
[5.3.0]: https://github.com/automattic/jetpack-forms/compare/v5.2.0...v5.3.0
[5.2.0]: https://github.com/automattic/jetpack-forms/compare/v5.1.0...v5.2.0
[5.1.0]: https://github.com/automattic/jetpack-forms/compare/v5.0.0...v5.1.0
[5.0.0]: https://github.com/automattic/jetpack-forms/compare/v4.0.1...v5.0.0
[4.0.1]: https://github.com/automattic/jetpack-forms/compare/v4.0.0...v4.0.1
[4.0.0]: https://github.com/automattic/jetpack-forms/compare/v3.1.0...v4.0.0
[3.1.0]: https://github.com/automattic/jetpack-forms/compare/v3.0.0...v3.1.0
[3.0.0]: https://github.com/automattic/jetpack-forms/compare/v2.1.0...v3.0.0
[2.1.0]: https://github.com/automattic/jetpack-forms/compare/v2.0.1...v2.1.0
[2.0.1]: https://github.com/automattic/jetpack-forms/compare/v2.0.0...v2.0.1
[2.0.0]: https://github.com/automattic/jetpack-forms/compare/v1.3.0...v2.0.0
[1.3.0]: https://github.com/automattic/jetpack-forms/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/automattic/jetpack-forms/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/automattic/jetpack-forms/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/automattic/jetpack-forms/compare/v0.56.0...v1.0.0
[0.56.0]: https://github.com/automattic/jetpack-forms/compare/v0.55.0...v0.56.0
[0.55.0]: https://github.com/automattic/jetpack-forms/compare/v0.54.0...v0.55.0
[0.54.0]: https://github.com/automattic/jetpack-forms/compare/v0.53.0...v0.54.0
[0.53.0]: https://github.com/automattic/jetpack-forms/compare/v0.52.0...v0.53.0
[0.52.0]: https://github.com/automattic/jetpack-forms/compare/v0.51.0...v0.52.0
[0.51.0]: https://github.com/automattic/jetpack-forms/compare/v0.50.0...v0.51.0
[0.50.0]: https://github.com/automattic/jetpack-forms/compare/v0.49.0...v0.50.0
[0.49.0]: https://github.com/automattic/jetpack-forms/compare/v0.48.0...v0.49.0
[0.48.0]: https://github.com/automattic/jetpack-forms/compare/v0.47.0...v0.48.0
[0.47.0]: https://github.com/automattic/jetpack-forms/compare/v0.46.0...v0.47.0
[0.46.0]: https://github.com/automattic/jetpack-forms/compare/v0.45.0...v0.46.0
[0.45.0]: https://github.com/automattic/jetpack-forms/compare/v0.44.0...v0.45.0
[0.44.0]: https://github.com/automattic/jetpack-forms/compare/v0.43.0...v0.44.0
[0.43.0]: https://github.com/automattic/jetpack-forms/compare/v0.42.1...v0.43.0
[0.42.1]: https://github.com/automattic/jetpack-forms/compare/v0.42.0...v0.42.1
[0.42.0]: https://github.com/automattic/jetpack-forms/compare/v0.41.0...v0.42.0
[0.41.0]: https://github.com/automattic/jetpack-forms/compare/v0.40.0...v0.41.0
[0.40.0]: https://github.com/automattic/jetpack-forms/compare/v0.39.0...v0.40.0
[0.39.0]: https://github.com/automattic/jetpack-forms/compare/v0.38.0...v0.39.0
[0.38.0]: https://github.com/automattic/jetpack-forms/compare/v0.37.1...v0.38.0
[0.37.1]: https://github.com/automattic/jetpack-forms/compare/v0.37.0...v0.37.1
[0.37.0]: https://github.com/automattic/jetpack-forms/compare/v0.36.0...v0.37.0
[0.36.0]: https://github.com/automattic/jetpack-forms/compare/v0.35.1...v0.36.0
[0.35.1]: https://github.com/automattic/jetpack-forms/compare/v0.35.0...v0.35.1
[0.35.0]: https://github.com/automattic/jetpack-forms/compare/v0.34.6...v0.35.0
[0.34.6]: https://github.com/automattic/jetpack-forms/compare/v0.34.5...v0.34.6
[0.34.5]: https://github.com/automattic/jetpack-forms/compare/v0.34.4...v0.34.5
[0.34.4]: https://github.com/automattic/jetpack-forms/compare/v0.34.3...v0.34.4
[0.34.3]: https://github.com/automattic/jetpack-forms/compare/v0.34.2...v0.34.3
[0.34.2]: https://github.com/automattic/jetpack-forms/compare/v0.34.1...v0.34.2
[0.34.1]: https://github.com/automattic/jetpack-forms/compare/v0.34.0...v0.34.1
[0.34.0]: https://github.com/automattic/jetpack-forms/compare/v0.33.8...v0.34.0
[0.33.8]: https://github.com/automattic/jetpack-forms/compare/v0.33.7...v0.33.8
[0.33.7]: https://github.com/automattic/jetpack-forms/compare/v0.33.6...v0.33.7
[0.33.6]: https://github.com/automattic/jetpack-forms/compare/v0.33.5...v0.33.6
[0.33.5]: https://github.com/automattic/jetpack-forms/compare/v0.33.4...v0.33.5
[0.33.4]: https://github.com/automattic/jetpack-forms/compare/v0.33.3...v0.33.4
[0.33.3]: https://github.com/automattic/jetpack-forms/compare/v0.33.2...v0.33.3
[0.33.2]: https://github.com/automattic/jetpack-forms/compare/v0.33.1...v0.33.2
[0.33.1]: https://github.com/automattic/jetpack-forms/compare/v0.33.0...v0.33.1
[0.33.0]: https://github.com/automattic/jetpack-forms/compare/v0.32.16...v0.33.0
[0.32.16]: https://github.com/automattic/jetpack-forms/compare/v0.32.15...v0.32.16
[0.32.15]: https://github.com/automattic/jetpack-forms/compare/v0.32.14...v0.32.15
[0.32.14]: https://github.com/automattic/jetpack-forms/compare/v0.32.13...v0.32.14
[0.32.13]: https://github.com/automattic/jetpack-forms/compare/v0.32.12...v0.32.13
[0.32.12]: https://github.com/automattic/jetpack-forms/compare/v0.32.11...v0.32.12
[0.32.11]: https://github.com/automattic/jetpack-forms/compare/v0.32.10...v0.32.11
[0.32.10]: https://github.com/automattic/jetpack-forms/compare/v0.32.9...v0.32.10
[0.32.9]: https://github.com/automattic/jetpack-forms/compare/v0.32.8...v0.32.9
[0.32.8]: https://github.com/automattic/jetpack-forms/compare/v0.32.7...v0.32.8
[0.32.7]: https://github.com/automattic/jetpack-forms/compare/v0.32.6...v0.32.7
[0.32.6]: https://github.com/automattic/jetpack-forms/compare/v0.32.5...v0.32.6
[0.32.5]: https://github.com/automattic/jetpack-forms/compare/v0.32.4...v0.32.5
[0.32.4]: https://github.com/automattic/jetpack-forms/compare/v0.32.3...v0.32.4
[0.32.3]: https://github.com/automattic/jetpack-forms/compare/v0.32.2...v0.32.3
[0.32.2]: https://github.com/automattic/jetpack-forms/compare/v0.32.1...v0.32.2
[0.32.1]: https://github.com/automattic/jetpack-forms/compare/v0.32.0...v0.32.1
[0.32.0]: https://github.com/automattic/jetpack-forms/compare/v0.31.4...v0.32.0
[0.31.4]: https://github.com/automattic/jetpack-forms/compare/v0.31.3...v0.31.4
[0.31.3]: https://github.com/automattic/jetpack-forms/compare/v0.31.2...v0.31.3
[0.31.2]: https://github.com/automattic/jetpack-forms/compare/v0.31.1...v0.31.2
[0.31.1]: https://github.com/automattic/jetpack-forms/compare/v0.31.0...v0.31.1
[0.31.0]: https://github.com/automattic/jetpack-forms/compare/v0.30.18...v0.31.0
[0.30.18]: https://github.com/automattic/jetpack-forms/compare/v0.30.17...v0.30.18
[0.30.17]: https://github.com/automattic/jetpack-forms/compare/v0.30.16...v0.30.17
[0.30.16]: https://github.com/automattic/jetpack-forms/compare/v0.30.15...v0.30.16
[0.30.15]: https://github.com/automattic/jetpack-forms/compare/v0.30.14...v0.30.15
[0.30.14]: https://github.com/automattic/jetpack-forms/compare/v0.30.13...v0.30.14
[0.30.13]: https://github.com/automattic/jetpack-forms/compare/v0.30.12...v0.30.13
[0.30.12]: https://github.com/automattic/jetpack-forms/compare/v0.30.11...v0.30.12
[0.30.11]: https://github.com/automattic/jetpack-forms/compare/v0.30.10...v0.30.11
[0.30.10]: https://github.com/automattic/jetpack-forms/compare/v0.30.9...v0.30.10
[0.30.9]: https://github.com/automattic/jetpack-forms/compare/v0.30.8...v0.30.9
[0.30.8]: https://github.com/automattic/jetpack-forms/compare/v0.30.7...v0.30.8
[0.30.7]: https://github.com/automattic/jetpack-forms/compare/v0.30.6...v0.30.7
[0.30.6]: https://github.com/automattic/jetpack-forms/compare/v0.30.5...v0.30.6
[0.30.5]: https://github.com/automattic/jetpack-forms/compare/v0.30.4...v0.30.5
[0.30.4]: https://github.com/automattic/jetpack-forms/compare/v0.30.3...v0.30.4
[0.30.3]: https://github.com/automattic/jetpack-forms/compare/v0.30.2...v0.30.3
[0.30.2]: https://github.com/automattic/jetpack-forms/compare/v0.30.1...v0.30.2
[0.30.1]: https://github.com/automattic/jetpack-forms/compare/v0.30.0...v0.30.1
[0.30.0]: https://github.com/automattic/jetpack-forms/compare/v0.29.2...v0.30.0
[0.29.2]: https://github.com/automattic/jetpack-forms/compare/v0.29.1...v0.29.2
[0.29.1]: https://github.com/automattic/jetpack-forms/compare/v0.29.0...v0.29.1
[0.29.0]: https://github.com/automattic/jetpack-forms/compare/v0.28.0...v0.29.0
[0.28.0]: https://github.com/automattic/jetpack-forms/compare/v0.27.0...v0.28.0
[0.27.0]: https://github.com/automattic/jetpack-forms/compare/v0.26.0...v0.27.0
[0.26.0]: https://github.com/automattic/jetpack-forms/compare/v0.25.0...v0.26.0
[0.25.0]: https://github.com/automattic/jetpack-forms/compare/v0.24.2...v0.25.0
[0.24.2]: https://github.com/automattic/jetpack-forms/compare/v0.24.1...v0.24.2
[0.24.1]: https://github.com/automattic/jetpack-forms/compare/v0.24.0...v0.24.1
[0.24.0]: https://github.com/automattic/jetpack-forms/compare/v0.23.1...v0.24.0
[0.23.1]: https://github.com/automattic/jetpack-forms/compare/v0.23.0...v0.23.1
[0.23.0]: https://github.com/automattic/jetpack-forms/compare/v0.22.6...v0.23.0
[0.22.6]: https://github.com/automattic/jetpack-forms/compare/v0.22.5...v0.22.6
[0.22.5]: https://github.com/automattic/jetpack-forms/compare/v0.22.4...v0.22.5
[0.22.4]: https://github.com/automattic/jetpack-forms/compare/v0.22.3...v0.22.4
[0.22.3]: https://github.com/automattic/jetpack-forms/compare/v0.22.2...v0.22.3
[0.22.2]: https://github.com/automattic/jetpack-forms/compare/v0.22.1...v0.22.2
[0.22.1]: https://github.com/automattic/jetpack-forms/compare/v0.22.0...v0.22.1
[0.22.0]: https://github.com/automattic/jetpack-forms/compare/v0.21.0...v0.22.0
[0.21.0]: https://github.com/automattic/jetpack-forms/compare/v0.20.1...v0.21.0
[0.20.1]: https://github.com/automattic/jetpack-forms/compare/v0.20.0...v0.20.1
[0.20.0]: https://github.com/automattic/jetpack-forms/compare/v0.19.11...v0.20.0
[0.19.11]: https://github.com/automattic/jetpack-forms/compare/v0.19.10...v0.19.11
[0.19.10]: https://github.com/automattic/jetpack-forms/compare/v0.19.9...v0.19.10
[0.19.9]: https://github.com/automattic/jetpack-forms/compare/v0.19.8...v0.19.9
[0.19.8]: https://github.com/automattic/jetpack-forms/compare/v0.19.7...v0.19.8
[0.19.7]: https://github.com/automattic/jetpack-forms/compare/v0.19.6...v0.19.7
[0.19.6]: https://github.com/automattic/jetpack-forms/compare/v0.19.5...v0.19.6
[0.19.5]: https://github.com/automattic/jetpack-forms/compare/v0.19.4...v0.19.5
[0.19.4]: https://github.com/automattic/jetpack-forms/compare/v0.19.3...v0.19.4
[0.19.3]: https://github.com/automattic/jetpack-forms/compare/v0.19.2...v0.19.3
[0.19.2]: https://github.com/automattic/jetpack-forms/compare/v0.19.1...v0.19.2
[0.19.1]: https://github.com/automattic/jetpack-forms/compare/v0.19.0...v0.19.1
[0.19.0]: https://github.com/automattic/jetpack-forms/compare/v0.18.0...v0.19.0
[0.18.0]: https://github.com/automattic/jetpack-forms/compare/v0.17.0...v0.18.0
[0.17.0]: https://github.com/automattic/jetpack-forms/compare/v0.16.0...v0.17.0
[0.16.0]: https://github.com/automattic/jetpack-forms/compare/v0.15.0...v0.16.0
[0.15.0]: https://github.com/automattic/jetpack-forms/compare/v0.14.1...v0.15.0
[0.14.1]: https://github.com/automattic/jetpack-forms/compare/v0.14.0...v0.14.1
[0.14.0]: https://github.com/automattic/jetpack-forms/compare/v0.13.0...v0.14.0
[0.13.0]: https://github.com/automattic/jetpack-forms/compare/v0.12.0...v0.13.0
[0.12.0]: https://github.com/automattic/jetpack-forms/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/automattic/jetpack-forms/compare/v0.10.2...v0.11.0
[0.10.2]: https://github.com/automattic/jetpack-forms/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/automattic/jetpack-forms/compare/v0.10.0...v0.10.1
[0.10.0]: https://github.com/automattic/jetpack-forms/compare/v0.9.0...v0.10.0
[0.9.0]: https://github.com/automattic/jetpack-forms/compare/v0.8.0...v0.9.0
[0.8.0]: https://github.com/automattic/jetpack-forms/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/automattic/jetpack-forms/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/automattic/jetpack-forms/compare/v0.5.1...v0.6.0
[0.5.1]: https://github.com/automattic/jetpack-forms/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/automattic/jetpack-forms/compare/v0.4.0...v0.5.0
[0.4.0]: https://github.com/automattic/jetpack-forms/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/automattic/jetpack-forms/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/automattic/jetpack-forms/compare/v0.1.0...v0.2.0
