# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.2] - 2026-11-16
### Changed
- Internal updates.

## [0.3.1] - 2026-10-26
### Changed
- Internal updates.

## [0.3.0] - 2026-09-01
### Removed
- Minimum supported PHP version is now 7.4. [#51515]

## [0.2.5] - 2026-06-08
### Changed
- Internal updates.

## [0.2.4] - 2026-05-19
### Changed
- Internal updates.

## [0.2.3] - 2026-05-04
### Changed
- Internal: No longer require automattic/jetpack-changelogger as a per-project dev dependency. [#48225]

## [0.2.2] - 2025-12-08
### Fixed
- Ensure proper flags are used with `json_encode()`. [#46092]

## [0.2.1] - 2025-08-04
### Changed
- Internal updates.

## [0.2.0] - 2025-07-28
### Added
- Make it possible to decode data as array. [#44399]

## 0.1.0 - 2025-07-21
### Added
- Initial version. [#43692]

[0.3.2]: https://github.com/automattic/jetpack-jwt/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/automattic/jetpack-jwt/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/automattic/jetpack-jwt/compare/v0.2.5...v0.3.0
[0.2.5]: https://github.com/automattic/jetpack-jwt/compare/v0.2.4...v0.2.5
[0.2.4]: https://github.com/automattic/jetpack-jwt/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/automattic/jetpack-jwt/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/automattic/jetpack-jwt/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/automattic/jetpack-jwt/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/automattic/jetpack-jwt/compare/v0.1.0...v0.2.0
