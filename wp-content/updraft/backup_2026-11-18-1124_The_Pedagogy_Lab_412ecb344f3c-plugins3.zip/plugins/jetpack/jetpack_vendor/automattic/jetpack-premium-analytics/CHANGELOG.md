# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.18.0] - 2026-11-16
### Added
- Add Download CSV to the Devices and Top platforms cards. [#54843]
- Add Download CSV to the post, video and email detail cards. [#54849]
- Add Download CSV to the Traffic summary card. [#54842]
- Add Download CSV to the Views over years, Monthly posting activity, Shares and Subscriber summary cards. [#54848]
- Dashboard: Add an Arrange tabs option to the page options menu, to reorder the tabs and choose the one that opens first. [#54806]
- Date controls: Add a Last 3 years period to the date menu, charted by years, so traffic can be compared year by year without picking a custom range. [#54667]
- Date controls: Offer a yearly chart interval on any date range that covers three calendar years. [#54667]
- Single-report pages: Serve the author page from /report/author/<id>, rendered from its registered record; the old /author/<id> address redirects. [#54184]
- Single-report pages: Serve the post page from /report/post/<id>, rendered from its registered record with its three sections; the old /post/<id> address redirects. [#54183]
- Widget SDK: add `useOpenChartBucket`, which opens a clicked chart bucket, from either period, as the dashboard period (2.4.0). [#54573]

### Changed
- Dashboard: Preload the open screen's code and the first REST responses, so the first widgets appear sooner. [#54730]
- Dashboard: Request the dashboard sections and widget types while the page is still loading the site details, instead of after. [#54784]
- Dashboard: Start loading stats without waiting for the site settings when the dashboard opens with no dates in its URL. [#54775]
- Date controls: Simplify how a period a widget sets is signalled to the date control. [#54727]
- Date filters: Measure a comparison with one implementation for reading and writing the URL. [#54723]
- Draw the text inside dashboard widgets at 14px, as classic Stats did, with headline figures in bold, so lists and figures are easier to read. [#54977]
- Make view counts easier to compare across the heatmaps, so quiet periods can be told apart instead of sharing one pale shade, and mark months the data does not yet fill. [#54838]
- Settings: Move the Stats settings from a dashboard tab to their own page, reached from the page options menu. [#54801]
- Show the view options of Top pages, Top platforms, Latest emails sent, All-time traffic and Views over years as one-click toggles instead of a dropdown. [#54927]
- Single-report pages: Let the VideoPress package register the video page instead of registering it here. [#54185]
- Single-report pages: Open on the date range of the page that linked to them, instead of All time. [#54783]
- Stats: Leave a bar chart column empty when its value is zero, instead of drawing a thin bar that looks like a small count. [#54850]
- Top locations: Show Countries, Regions and Cities as one-click toggles instead of a dropdown. [#54803]
- Update package dependencies. [#54703]

### Removed
- Dashboard: Remove the Site overview, Post traffic activity, Total views, Total visitors, Popular days, Popular hours and Hello World widgets, which no layout or widget picker offered. [#54921]

### Fixed
- Arrange tabs: Keep the place of a tab that is hidden when the order is saved. [#54868]
- Charts: Let a percentage axis grow with the data once a value passes 100%, so a video's retention rate above 100% stays inside the chart. [#54937]
- Charts: Stop hourly charts from showing a clickable cursor when a click opens nothing. [#54573]
- Dates: Keep the month in month labels for Japanese, Chinese and Korean sites, which showed a day marker instead (2021年1日 rather than 2021年1月). [#54793]
- Dates: Use the locale's default date format when the site's Date Format setting lacks a day, month or year, so chart labels and the date selector stay unambiguous. [#54793]
- Improve page transitions between reports and detail views. [#54614]
- Keep the widget title from being cut off beside a toggle, so the toggle folds into the widget controls menu at the same width whichever way the widget is resized. [#54927]
- Metric tiles: Pick the layout from the size of the tiles' own box, so highlights stay in columns after switching dashboard tabs. [#54683]
- Open the dashboard for `admin.php?page=stats` on WordPress 7.2, which reports an unregistered page as not found instead of denied. [#54800]
- Shorten the breadcrumb trail and hide the Customizing badge on phones, instead of letting them cover the header buttons. [#54844]
- Show metric cards as a list when the card is too narrow for every metric to fit side by side, instead of cutting off the figures. [#54923]
- Single-report pages: Name an untitled post, author or video in the last breadcrumb as the header does. [#54928]
- Single-report pages: Show the Jetpack footer on the video page again. [#54183]
- Stats: Move an old Year to date or All time link to today's window when its saved interval no longer fits, so the address bar matches the charts. [#54722]
- Stats: Move a preset's dates to the new day when a page is left open past midnight, so the numbers and the date controls include today. [#54721]
- Stop a long post title from widening the page on desktop, so the header buttons stay in view. [#54847]
- Widget header toggles: Keep the side padding on the longer of two options, such as Posts & pages on the Top pages card. [#54942]

## [0.17.0] - 2026-11-09
### Added
- Offer a quarterly interval in the Traffic summary and the WooCommerce tab on ranges of a year or longer. [#54455]
- Single-report pages: Serve the video page from /report/video/<id>, rendered from its registered record; the old /video/<id> address redirects. [#54173]
- Stats: Add previous and next arrows beside the date range picker that step the range by its own length, as classic Stats does. [#54327]
- Top UTM: Open the Build URL dialog from a post row in the Top UTM card and on the UTM report page, with the post URL and the row's UTM values already filled in. [#54254]

### Changed
- Dashboard: give each default tile the height its content needs; the Traffic lists open tall enough for their ten entries. [#54603]
- Dashboard: Let the number of columns follow the width of the page, up to six, and let the full-width rows of the default layouts span every column. [#54427]
- Dashboard: Stop offering feedback (banner, page options menu item and tour step) once the classic Stats page is retired. [#54678]
- Metric cards: Draw the cards on their own tabs primitive, taking the design system’s hover, selected and focus states. [#54468]
- Post detail: Name the traffic tab and the highlights and views cards for the content type, such as Product traffic. [#54395]
- Register the post and author detail page widget types in PHP, in place of client-side aliases. [#54182]
- Reports: Load a report's page only when it opens, so the route guards no longer bundle every report page. [#54512]
- Settings: Explain in the Visitor consent card that views may drop once Stats follows visitor consent. [#54398]
- Stats links: Open the dashboard on the section and the days a link names, so the admin bar's "View all stats" shows the 7 days its chart does. [#54234]
- Traffic summary: Save the chart type its switch picks where Stats v1 saved it, so the Stats widget on the wp-admin dashboard draws bars or lines as this chart does. [#54456]
- Update package dependencies. [#54512]
- Use the design system tooltip for abbreviated values and earnings statuses. [#54512]
- When a date range allows only one chart interval, open its menu anyway and say how a longer range adds more. [#54020]
- Widgets: Load the All-time stats and Most popular day widgets faster by skipping the share counts they never show. [#54528]
- Widgets: Name each chart after its widget title by default, so the title is translated once. [#54513]

### Removed
- Remove the include guards and stubs kept for a second copy of the package loading in the same request; the autoloader now serves one copy per request. [#54402]

### Fixed
- Boot Stats v2 on a site with no connection once classic Stats is retired, so it replaces the pre-connection Stats page. [#54342]
- Dashboard: Stop screen readers from announcing widget content as dimmed outside edit mode. [#54512]
- Fix Jetpack icon alignment and spacing in page headers. [#54610]
- Metric cards: Remove the grey box that appears inside a metric card on hover when a newer version of the WordPress UI library is loaded. [#54385]
- Report params field: Reopen the period menu on the calendar when the applied range is custom. [#54173]
- Settings: Reset the Reader views setting to its default on a null write, instead of turning it off. [#54448]
- Stats: Keep the dashboard under My Home in the admin menu on WordPress.com, where it had dropped below Hosting and Upgrades. [#54626]
- Stats: List Stats v2 in the WordPress.com sidebar, and once the classic Stats page is retired, open Stats v2 from old Stats links and stop offering to switch back to classic Stats. [#54451]
- Stats: Read a preset as the window it names today in the date controls, the interval menu and the comparison, as the widgets do, so a bookmark with older dates no longer names last week in the date tooltip and the calendar, or compares this week against the wrong one. [#54545]
- Stop long row names in cards such as Top UTM from running under the views count on hover, and give drill-down rows with an action their full width when not hovered. [#54511]
- Store: Stop money charts repeating y-axis labels, such as $1, $1, $2, when the store shows fewer decimals than its amounts carry. [#54399]
- WooCommerce reports: Keep widgets loading while WordPress.com creates a new store's analytics tables, instead of showing an error, and say when a report waits for the store's next sync. [#54524]

## [0.16.0] - 2026-11-02
### Added
- Dashboard: Invite sites whose cookie banner Stats cannot read yet to finish the Visitor consent setup in Settings. [#54195]
- Let other plugins ask whether Stats v2 should be on and whether it booted, and share the flag that retires the classic Stats page, which now also replaces the pre-connection Stats page. [#54022]
- Settings: Add a Visitor consent card that shows whether a cookie banner plugin and the WP Consent API are active, and installs the WP Consent API in one click. [#54187]
- Single-report pages: add a registry other plugins can register pages on, published to the client in script data and over REST. [#54119]
- Single-report pages: add the `jpa/report-params` field type to the widget SDK (2.2.0). [#54172]
- Stats: Add a filter that lets the host choose which settings, and whether the visitor consent card, the Settings tab offers, and leave the plan usage card out when the plan has no view limit. [#54258]
- Stats: Offer "Mark as spam" from the Top referrers widget rows, as the Referrers report does. [#54190]
- Top UTM: Offer the Build URL dialog in the card footer and on the UTM report page, so sites with UTM visits can open it too. [#54135]
- Videos: Play the video on its stats report. [#54291]

### Changed
- Section tabs: Show the selected tab in the design system colors instead of the admin theme color. [#54384]
- Show exact figures in single-figure widgets, shortening them only where they would be clipped. [#54337]
- Traffic summary: Draw the previous period only when it is switched on from the chart legend. [#54249]
- Update package dependencies. [#53869]
- Widgets: Let leaderboard charts size their bars and compute percentage changes from the values, so negative values draw below zero in the bars layout and as empty bars in the list layout, a negative previous value gives the right direction of change, and list bars scale to the current period when comparing. [#54251]
- Widgets toolkit: Let the consumer control the previous period in the bar chart legend. [#54328]

### Fixed
- Prevent PHP errors by limiting direct access to files. [#54244]
- Settings: Link the Activation card to the Modules screen on sites where My Jetpack redirects to Stats, so Stats can be switched off there. [#54196]
- Store: Show store money with the store's number of decimals setting, as WooCommerce Analytics does. [#54141]
- Widgets: Line up the column header above leaderboard rows with the row text. [#54193]

## [0.15.0] - 2026-10-28
### Added
- Add an init option that replaces the pre-connection Stats page with this dashboard, and apply options from a later init call. [#54138]
- Offer a yearly interval in the Traffic summary on ranges of three years or longer, and label a first or last month or year that the range cuts by its days. [#53965]
- Show the Personal plan's monthly price in the upgrade prompt that replaces a free WordPress.com site's Insights and Traffic sections. [#54136]
- Show the Stats plan choice on a site that is not connected yet, and connect the site from it. [#53941]
- Stats: Add a "View in new tab" row action that opens the live post, page or email from the Posts & pages and Emails reports. [#54058]
- Stats: Open the live post, page or email in a new tab from its row in a widget, beside the title that opens its stats. [#53996]

### Changed
- Dashboard: Show the notice about a failed refresh at the top of the section, instead of inside the sticky header. [#54139]
- Highlights: Show metric notes in a styled tooltip that also opens on keyboard focus. [#54011]
- Name the chart interval on the year date filter too, and collapse its year pills when the interval's name grows past the room left. [#54019]
- Stats: Offer a referrer's site from a "View in new tab" action beside its name in the Top referrers widget, instead of linking the whole row out. [#54163]

### Fixed
- Conversion funnel: Label the tooltip's rate "Conversion rate", and make screen readers announce what each step's tooltip shows. [#53637]
- CSV export: Name countries in the Store visitors by location export when WooCommerce has no name for them. [#54107]
- Fix hourly Traffic chart times that were an hour off on daylight saving days. [#54015]
- Hide Stats v2 from users who cannot connect the site until it is connected, as the Stats menu does, and send them to the Dashboard if they reload the page. [#54103]
- Recognize the Stats views included in Jetpack Pro on the upgrade page. [#54108]
- Scroll the Jetpack footer with the page on the dashboard, report and detail pages, instead of keeping it pinned to the bottom of the screen. [#54206]
- Traffic summary: Compare each week, month or year with the one covering the same days in the comparison period, instead of the one in the same position. [#53965]

## [0.14.0] - 2026-10-26
### Added
- Add an upgrade page with a pricing slider to pick a Stats tier, and open it from the upgrade links on Jetpack sites. [#53724]
- Keep the reports and post stats pages opened from the Traffic tab within the plan's dates. [#53767]
- Let free WordPress.com sites resize the Traffic views chart with Customize. [#53963]
- Limit the Traffic tab's dates and chart grouping to what the site's plan includes, such as the last 7 days on a free plan. [#53695]
- Offer a paid Stats plan to free sites 30 days after their first visit, and show one Stats notice at a time. [#53647]
- Offer daily intervals on long date ranges in the Traffic summary line chart. [#53966]
- SDK: Share the Button, ButtonLink, Progress, Text and VisuallyHidden primitives with widgets. [#53887]
- Show one upgrade prompt in place of Insights, and of Traffic below the chart, on free WordPress.com sites. [#53709]
- Show the chart groupings the site's plan locks in the chart interval menu, with an upgrade link. [#53769]
- Show the Jetpack footer at the bottom of every Stats page, like other Jetpack screens. [#53969]
- Stats links: Open the dashboard from old Stats page links once no plugin registers the classic Stats page. [#53914]
- Widgets: let a chart type option name its icon as a `jpa/<name>` reference, the form a widget.json can carry. [#53771]

### Changed
- Hide Stats CSV exports on plans that do not include them, and lock a post's all-time traffic on free plans. [#53766]
- Link to a post's public page when the reader cannot open its details, and name a product as a product on its detail page. [#54017]
- Name the selected chart interval in the dashboard header instead of showing a bar chart icon. [#54016]
- Page options: offer switching the dashboard off only while the site still has a classic Stats page to return to. [#53792]
- Show every row on Stats report pages on one page, instead of splitting them into pages of 10. [#53964]
- Stop the tour from offering period comparison on a free plan, which covers only the last 7 days. [#53832]
- Sync: Move the store analytics sync opt-in and the lookup data backfill to the WooCommerce Stats package, and record the first full-sync start separately for each analytics module. [#53282]
- Traffic summary: Draw visitors inside the views bar in bar charts, as Jetpack Stats v1 does, with the previous period in gray beside them. [#53836]
- Update package dependencies. [#53951] [#54003]
- Widgets: Show the View all link and the CSV download in the card footer. [#53881]

### Removed
- Remove the inline widget footer: WidgetFooter, ReportLink, ExporterCsvDownloadButton and the Leaderboard footer prop. A widget declares its footer with useReportActions; widget contract 2.0.0. [#53885]

### Fixed
- Fix post, video and author stats pages that could crash with "Something went wrong" right after opening. [#53834]
- Match the Jetpack logo position and header height on Stats pages to the other Jetpack pages. [#54021]
- Widget titles, descriptions, help notes and settings labels declared in widget.json reach the translation catalog. [#53850]
- WooCommerce tab: Resend order history once on stores that synced it through the WooCommerce Analytics plugin, so product, tax and coupon reports include past orders. [#53728]

## [0.13.0] - 2026-10-19
### Added
- Add All time to the report date menu, covering everything since the site's stats began. [#53275]
- Add the date limits each Stats plan sets, for the dashboard to apply. [#53700]
- Dashboard: Accept a chart title on the Columns, Donut, Funnel, Leaderboard, Locations and MetricTabsChart widget components through the SDK; the widget contract is 1.13.0. [#53333]
- Dashboard: add the Columns widget kind, which the revenue by customer type, sales by device, total returns and sales by coupon widgets draw with. [#53464]
- Dashboard: add the Locations widget kind, which Visitors by location draws with. [#53533]
- Dashboard: expose the Columns widget kind through the SDK; the widget contract is 1.10.0. [#53476]
- Dashboard: expose the Locations widget kind through the SDK; the widget contract is 1.11.0. [#53534]
- Dashboard: Show a notice when the site nears or passes its plan's monthly views limit. [#53401]
- Dashboard: Thank the reader for their Stats purchase when checkout returns to the dashboard. [#53642]
- Dashboard sections: Let a section declare the widget types its inserter offers on top of its default layout, filterable by any plugin. [#53720]
- Dashboard sections: Let a section show a notice above its widgets. [#53602]
- Detect which paid Stats features the site's plan lacks, and let a widget type declare the plan feature it shows. [#53528]
- Offer a Create post action in empty Traffic and Popular post widgets when the site has no published posts. [#53414]
- Offer a URL builder when the selected UTM report has no visits. [#53458]
- Onboarding: Introduce the WooCommerce tab, with a short version for readers who already went through the onboarding. [#53660]
- Show locked periods and an upgrade footer in the date picker when given date limits. [#53701]
- Show paid Stats features as locked, with an upgrade link, on plans that do not include them. [#53584]
- Widgets: Carry the attributes a widget.json declares through the registry to the dashboard. [#53774]

### Changed
- Chart legends: Name each metric's comparison period, such as "Views (Prev. 30 days)", in both line and bar charts. [#53457]
- Charts: Draw tabbed metric charts in the admin color, with the metric paired in the Traffic summary in a darker shade, instead of a different color per metric. [#53453]
- Explain what Tags & categories shows when the plan locks it. [#53641]
- Lighten heatmap colors in cards such as Posting activity and Views over years, while keeping low values distinct from empty cells. [#53450]
- Link a locked feature's WordPress.com support page in the user's language, and fix support links that pointed at sections no longer on the page. [#53643]
- Metric tabs: Spread the cards evenly over their rows, scale the values with the card width, and show full figures when the cards collapse into a dropdown. [#53708]
- Move a Top tags & categories tile a reader placed on a customized Insights layout to their Traffic layout, once. [#53381]
- Open the dashboard on the comparison the reader last applied from the header, including No comparison. [#53591]
- Reports: fold the Archives tab like the other drilldown reports, with a chevron on each archive type and every row at one weight. [#53731]
- Settings: Show plan usage in a taller, brand-colored meter. [#53706]
- Update package dependencies. [#53004] [#53806]
- Widgets: Add a Learn more link to the empty All-time top social media shares widget, and to Subscriber summary when the site has no subscribers yet. [#53541]
- Widgets: Add column headers naming the rows and the metric to the Insights lists, Top tags & categories, Email breakdown and Top viewed posts. [#53698]
- Widgets: Name the rows and what the values count above the Traffic tab lists, following the selected view and each drill-down level. [#53697]
- Widgets: Say that nothing is recorded yet in eight empty Traffic widgets when the site has no views at all, and in Top tags & categories when no post is published, instead of the text about the selected period. [#53542]
- Widgets: Show the search icon in every empty state, including the detail pages and the widgets that had none, and reword the empty text of several widgets. [#53520]
- Widgets: Show what the values count above Top pages and Latest emails sent, and the unit in the tooltip of an abbreviated value. [#53696]

### Removed
- Dashboard: Remove the feature flag that gated adding and removing widgets, which is now always offered. [#53646]
- Dashboard: Remove the store section feature flag; the WooCommerce tab no longer waits for it on a site that opted in. [#53588]
- Remove the WooCommerce columns widgets, now built by the WooCommerce Stats package. [#53477]
- Remove the WooCommerce report client and the store gating: the WooCommerce Stats package owns them. [#53540]
- Remove the WooCommerce Store visitors by location widget, now built by the WooCommerce Stats package. [#53536]

### Fixed
- Charts: Paint donut and semi-circle chart tooltips above the center total. [#53449]
- Charts: Set wrapped legend rows closer together, and space legend items the same way in every chart. [#53703]
- Fields: Keep text labels of the toggle group on one line. [#53555]
- Give map, leaderboard and conversion funnel charts an accessible name and role for screen readers. [#53516]
- Keep a deep link's day interval and date label when its ISO offsets were pasted with an unencoded plus, which the querystring reads as a space. [#53580]
- Keep conversion funnel bars and empty-state messages visible in one-row widgets. [#53554]
- Leave averages and the store conversion rate empty in CSV exports for a period without orders or sessions, and let a metric show no value when its report has none. [#53707]
- Load the author page on sites that block the WordPress users endpoint. [#53473]
- Metric charts: Hide redundant labels from single-metric widgets whose titles already identify the metric. [#53719]
- Name each widget chart after its widget, so screen readers can tell the charts on a dashboard apart. [#53333]
- Show the author's name in the author page breadcrumb. [#53468]
- Show the new plan and fresh Stats data on the first dashboard load after a Stats purchase. [#53644]
- WooCommerce tab: Treat a store whose analytics data already finished syncing as synced, instead of reporting a sync error. [#53650]

## [0.12.0] - 2026-10-12
### Added
- Add a Mark as spam action, with Undo, to the Referrers report. [#53277]
- Add a Settings tab to the dashboard, where site owners can see their plan usage and change the Stats settings. [#53357]
- Add likes, comments and an all-time traffic table to the author detail page, and count an author's views even when they rank below the top 20 authors. [#53292]
- Dashboard: add the bars variant of the Leaderboard widget kind, which draws both periods as bars under a period legend; the widget contract is 1.7.0. [#53398]
- Dashboard: add the Funnel widget kind, which the conversion rate widgets draw with. [#53460]
- Dashboard: add the half-ring variant of the Donut widget kind, which Devices and Sessions by device draw with; the widget contract is 1.8.0. [#53429]
- Dashboard: Expose the Donut widget kind and the shared WidgetStatus type through the SDK; the widget contract is 1.5.0. [#53309]
- Dashboard: expose the Funnel widget kind through the SDK; the widget contract is 1.9.0. [#53461]
- Dashboard: Resolve the icon a widget.json names, under the `jpa` collection; the widget contract is 1.6.0. [#53355]
- Link author names in Popular authors and the Authors report to the author's page. [#53455]
- Link the Videos report thumbnails to the video detail page, let video leaderboard rows show a linked poster, and mark the video detail poster with a play icon. [#53011]
- Show hours watched and retention rate on the Videos report, and name the Videos, Clicks, Authors and Locations columns as in Stats. [#53205]
- Widget SDK: Add `useReport` and `toBucketStamp`, so a package that extends the dashboard can run its own report queries and feed the dashboard time series. [#53234]
- Widgets toolkit: Add a Donut component that renders a breakdown with its total, legend, deltas and states; the five WooCommerce donut widgets use it. [#53305]

### Changed
- Cap the cards on report pages at a centered 1440px column on wide screens, so each row's label and numbers stay close enough to read together. [#53139]
- Charts: Draw chart tooltips with dark text on the light chart surface. [#53184]
- Charts: Use a 2px corner radius on chart bars. [#53132]
- Chart tooltips: Head the rows with the date once, read each as value then metric, and list the comparison period in a second column. [#53147]
- Dashboard: Move the WooCommerce tab to the WooCommerce stats package and rename it from Store to WooCommerce, including its URL. [#53157]
- Date controls: Compare with the previous period by default. [#53273]
- Label store visitor counts as Store visitors in the Store performance widget, the location map, and CSV exports, so they aren't confused with Jetpack Stats visitors. [#53345]
- Make the days in Monthly posting activity larger, growing with the card and wrapping the months onto two rows in the default layout. [#53341]
- Move the Top tags & categories widget from Insights to Traffic, where it and its report follow the date picker instead of a fixed seven days. [#53299]
- Open the dashboard from the admin bar Stats links and the newsletter action bar post stats link when it is enabled. [#52905]
- Open the dashboard on the last 7 days, or on the range the reader last applied here or in Jetpack Stats, and remember a range applied from the header. [#53276]
- Open the dashboard to anyone with a section available to them, so shop managers reach the WooCommerce tab, and keep Stats tabs, widgets and feedback to readers who can view Stats. [#53290]
- Reports: Rename the Videos, Clicks, Authors and Locations CSV headers to match the report table columns. [#53271]
- Show the empty-cell color at the start of heatmap legends such as Posting activity. [#53338]
- Traffic: Move the chart interval control from the page header into the Traffic summary widget, which saves its own interval. [#53140]
- Widgets toolkit: Move the remaining report and widget links onto the shared ExternalLink and InternalLink components; the Comments Subscribers and File downloads report links now open in a new tab with the outbound marker. [#53136]
- WordAds data: Flag today's day bucket as pending and read its values as null, as WordAds counts nightly; chart tooltips can carry a note for a bucket with no reading. [#53229]

### Removed
- Remove the Store performance widget, now built by the WooCommerce Stats package. [#53427]
- Remove the WooCommerce breakdown widgets, now built by the WooCommerce Stats package. [#53311]
- Remove the WooCommerce conversion rate widgets, now built by the WooCommerce Stats package. [#53462]
- Remove the WooCommerce leaderboard widgets, now built by the WooCommerce Stats package. [#53404]
- Remove the WooCommerce Sessions by device widget, now built by the WooCommerce Stats package. [#53454]
- Remove the WooCommerce time series widgets, now built by the WooCommerce Stats package. [#53291]

### Fixed
- Charts: Draw a summary chart too short for its axes as a sparkline without axes, so its tooltip can be reached. [#53206]
- Charts: Paint the metric tabs chart's tooltip above the metric tabs. [#53135]
- Date controls: Compare Last 30 days and custom ranges starting mid-month with the same number of days right before them. [#53272]
- Draw attention to the date control when a click on the Traffic summary chart sets the period. [#53142]
- Drop the URL column from the comment authors CSV, since its links only worked on the site and could expose guest commenters' email addresses. [#53138]
- Label a partial first or last week on the Traffic, Subscribers, and ads charts with the selected range's own start or end date. [#53137]
- Make donut and semi-circle chart widgets such as Devices reachable by keyboard, and name them for screen readers. [#53274]
- Make low values in heatmaps such as Posting activity easier to tell apart from empty cells, and show zero counts as empty. [#53085]
- Pair each week with its matching week in a year-ago weekly comparison, and show the days each week covers in the Traffic and ads chart tooltips. [#53207]
- Reports: show the Referrers, Clicks, Authors and UTM tables at one weight on every row, so the chevron alone marks a row that expands. [#53306]
- Show a video watched for a few minutes as "< 0.1" hours, not 0.0, on the Videos report and video detail page. [#53269]
- Store: Show store revenue and other money values in the store's currency instead of always US dollars. [#53350]
- Store performance: Use sentence case in the Store visitors chart tooltip, like the other count labels. [#53346]
- Store reports: Follow the WooCommerce Analytics date type setting instead of always using the order creation date. [#53347]
- Widgets toolkit: Leaderboard draws a negative value as an empty bar instead of a negative width. [#53319]

## [0.11.0] - 2026-10-05
### Added
- Add a Download CSV action to more widgets that saves the full report for the selected dates. [#52969] [#53017] [#53019] [#53079]
- Add video thumbnails to the Videos report. [#52908]
- Dashboard: Expose the CSV download action of the linked report through the SDK; the widget contract is 1.3.0. [#52909]
- Dashboard: Expose the Leaderboard component, the error mapper and the video plays hook through the SDK; the widget contract is 1.2.0. [#52885]
- Dashboard: Let a widget type declare its former names, so layouts saved before a rename keep rendering it; the widget contract is 1.1.0. [#52874]
- Date controls: Add the weekly chart interval to year-long date ranges such as Last 12 months, next to the monthly default. [#52978]
- Locations: Add drill-down from a region to its cities. [#52911]
- Top pages widget: Add the download to the Archives view. [#52966]
- Widgets toolkit: Add a Leaderboard component that renders ranked rows with their states, shares and deltas; Top videos, Search terms and Most commented authors use it. [#52965]

### Changed
- Charts: Give every chart tooltip the same box, with no tooltip padding, shadow or font size of its own. [#53072]
- Charts: Show tooltips on the shared dark chart tooltip surface. [#52850]
- Dashboard: Turn on adding and removing widgets by default. [#52826]
- Locations: Keep the previous list on screen, dimmed, while a drill-down loads, and move the map to the picked country straight away. [#53083]
- Open post and video details on All time, return to the previous date range from the breadcrumbs, and rearrange the Email clicks tab to match the design. [#52960]
- Reports: Drop "report" from headings and label the export button "Download CSV". [#52908]
- Show load errors and missing items on author, post, and video details in a notice, and stop offering Retry when access is denied. [#53086] [#53141]
- Show Posts & Pages and Videos report titles in bold beside a fixed-size thumbnail. [#52958]
- Top pages widget: Download the full report for the selected dates instead of the rows on screen. [#52966]
- Traffic chart: Default to the chart type Jetpack Stats v1 saved in this browser, else bars. [#52899]
- Widgets toolkit: Keep the hover underline on the ReportLink text when it renders text with a badge beside it. [#52752]
- Widgets toolkit: Share the internal and external link markup between components, and stop setting rel on links that open in a new tab. [#53043]

### Removed
- Dashboard: Move the Top videos widget to the VideoPress package, which registers it and seeds it into the Traffic section. [#52909]

### Fixed
- Dashboard: Open the date menus on the applied option instead of the first one. [#53081]
- Date controls: Use the default chart interval when switching to a different preset, instead of keeping the previous preset's. [#52897]
- Fix the Latest comments widget counting pingbacks and trackbacks in its remaining comments count. [#52964]
- Fix the post comments count, the most popular time, and unnamed countries showing wrong values when Stats has no data for them. [#52902]
- Reports: Show the "No data found" state on every report with no rows, and stop the table search and settings from showing while an empty report loads. [#52900]
- Show report load errors in a notice across the report, without Retry when access is denied. [#53141]
- Traffic chart: Show views per visitor and the number of posts published in the tooltip. [#52957]

## [0.10.0] - 2026-09-29
### Changed
- Dashboard: Offer in the widget picker only the widgets the current tab shows by default. [#52922]
- Dashboard: Show every section a site qualifies for instead of a fixed preview list, with the Store tab off unless the site opts in. [#52865]
- Dashboard: Show the no-results message in chart widgets for a period with no data, instead of a flat zero line. [#52868]
- Locations: Show each city as a marker on the map when Cities is selected. [#52859]
- Refresh Stats data automatically every 30 minutes while the tab stays open, except for date ranges that ended before today. [#52898]
- Traffic summary: Show Visitors on the chart alongside Views by default. [#52896]
- Update package dependencies. [#52757]

### Fixed
- Reports: Give report cards a raised background so charts no longer sit in a lighter box on the page. [#52852]
- Traffic summary: Show the day totals for visitors, likes, and comments when the chart shows hours. [#52858]

## [0.9.0] - 2026-09-28
### Added
- Add a "Manage subscribers" link to the Latest subscribers widget, opening the Newsletter subscribers screen in wp-admin. [#52604]
- Add additional analytics to dashboard customizing and feedback. [#52627] [#52824]
- Add additional analytics to the date range controls. [#52693]
- Add the `jetpack_premium_analytics_register_dashboard_sections` action, so a plugin can register a dashboard section. [#52454]
- Add the `jetpack_premium_analytics_register_widget_types` action, `register_widget_types_from_manifest()` and `WIDGET_API_VERSION`, so a plugin can register its dashboard widget types. [#52568] [#52634] [#52866]
- Ads: Note in the Earnings History widget when the site has adjustments, linking to the Adjustments history tab of the Earnings report. [#52526]
- Charts: Add a "Comparison period" legend item to line charts that show a previous period. [#52423]
- Dashboard: Add a feature flag that shows every section of a preview-limited dashboard. [#52549]
- Dashboard: Register the SDK as the `@automattic/jetpack-premium-analytics-sdk` script module. [#52635]
- Dashboard: Show the Ads tab in the customer preview on sites that use WordAds. [#52864]
- Dashboard: Show the Subscribers tab in the customer preview. [#52768]
- Date comparison: Add options that line up the same weekdays of the previous period and the previous year. [#52598]
- Post detail: Show the Email opens and Email clicks tabs for every post, with a "This post hasn’t been sent as a newsletter" state for a post that was never sent. [#52801]
- Reports: Replace the records table with a "No data found" state when the selected period has no rows. [#52792]
- Subscriber highlights: Describe the 30, 60 and 90 days ago and Social followers counts on hover and for screen readers. [#52747]
- Subscriber highlights: Show the change since 30 days ago on the all-time, paid and free subscriber counts for sites with paid subscribers. [#52741]

### Changed
- Ads: Adjust the Period column appearance in the Earnings report. [#52714]
- Ads: Show payment status as a badge in the Earnings History widget, and shorten the pending statuses to "Pending" with the reason beside them. [#52565] [#52687]
- Ads: Stop showing negative amounts in red in the Earnings History widget. [#52565]
- Ads: Title the tab "Ads performance" and reword the three WordAds widget tips, adding a "Learn more" link. [#52714]
- Charts: Start line chart value axes at zero, and pad the Subscribers chart's axis a little below its data instead. [#52600]
- Charts: Use square legend swatches in bar mode. [#52423]
- Chart tooltips: Lead each row with the value, then the metric as its unit, then the date. [#52527]
- Dashboard: Call the preview the new Stats in its welcome, feedback and switch-off copy. [#52722]
- Dashboard: Keep a chart widget's tabs at zero and show the no-results message inside the chart for a period with no data. [#52795]
- Dashboard: Leave registering the Ads tab to the WordAds module and WordPress.com, so it no longer appears on sites without WordAds. [#52455]
- Dashboard: Refuse to register a section whose slug another section already uses. [#52455]
- Dashboard: Show one generic “no results for this time period” state in list widgets that have no data for the selected period. [#52791]
- Dashboard: Show the empty state in chart widgets for a period with only zero or missing values. [#52795]
- Dashboard: Show the generic “no results for this time period” state in chart widgets that have no data for the selected period. [#52794]
- Dashboard: Show zeros or placeholders in highlight and Insights widgets for a period with no data, instead of an empty message. [#52795]
- Date controls: Adjust the date triggers' appearance, and match the widget header's date range control to the other header controls. [#52500]
- Latest subscribers: Open a subscriber on the Newsletter Subscribers page in wp-admin. [#52848]
- Locations: Draw disputed borders on the map as the viewer's country shows them. [#52805]
- Sync: Use the shared WooCommerce Analytics module from the jetpack-sync package, and sync store analytics whether or not WooCommerce order attribution is enabled. [#50851]

### Removed
- Ads: Remove the "Metrics" dropdown from the All-time balance card, so it always shows every amount. [#52700]
- Ads: Remove the Ads Served note above the Earnings report table. [#52714]
- Dashboard: Move the Ads widgets and their default layout to the Ads package, which registers them with the section. [#52635]

### Fixed
- Ads: Leave Average CPM empty instead of showing $0.00 in the Ads chart for periods with no ads served. [#52690]
- Ads: Show a dash instead of zero in the Earnings report when a period has no Ads Served count. [#52510]
- Authors: Stop listing an author's post that only appears in the comparison period as 0 (-100%). [#52678]
- Charts: Draw the Visitors legend swatch solid in the Traffic summary to match its line, and keep the selected metric's legend item from being hidden. [#52423]
- Charts: Show "1 Subscriber" rather than "1 Subscribers" in tooltips, using each language's plural rules. [#52683]
- Dashboard: Show the date menus opened from a widget's controls above the controls popover. [#52751]
- Email stats: Leave unknown rates blank in the Emails export. [#52684]
- Email stats: Show a sent but unopened email's open and click rates as 0% instead of a dash. [#52684]
- Email stats: Show readable link names in an email's Top links list, and list the links clicked inside the post instead of dropping them. [#52685]
- Email stats: Show the email tabs for emails whose sends went unrecorded. [#52684]
- Return the Stats breadcrumb to the dashboard tab a report or detail page was opened from, instead of always to Traffic. [#52862]
- Search terms: Stop treating a comparison list capped at 500 terms as complete. [#52678]
- Subscriber summary: Leave the months before a site launched or turned on subscriptions empty in the chart, with a "No data" tooltip, instead of showing zero. [#52523]

## [0.8.0] - 2026-09-21
### Added
- Add an author detail page with the author's views, popular and latest posts, and top viewed posts. [#52312]
- Add post thumbnails to the Posts & Pages report. [#52384]
- Ads: Add a line or bar chart toggle to the WordAds chart. [#52483]
- Ads: Link the Earnings History widget to its full report. [#52327]
- Ads: Show sponsored content and adjustment earnings on the Earnings history report, each on its own tab. [#52437]
- Dashboard widgets: Carry declarative actions and icon references from the widget manifest to the registry and the widget-modules REST record. [#51925]

### Changed
- Ads: Add a payment status filter to the Earnings history report. [#52389]
- Ads: Explain Ads Served on the Earnings history report. [#52389]
- Ads: Group the WordAds chart by the selected period instead of a separate grouping control. [#52483]
- Ads: Label WordAds earnings history periods by month and year, such as "August 2026". [#52327]
- Ads: Rename the WordAds widgets to Ads summary, All-time balance and WordAds earnings, and give each its own icon. [#52511]
- Ads: Show payment status as a badge on the Earnings history report. [#52437]
- Ads: Show the Earnings History widget as a compact list without in-widget pagination. [#52327]
- Ads: Show unpaid and negative amounts in red on the Earnings History widget. [#52389]
- Dashboard: Show opens and clicks beside their rates in Latest emails sent. [#52256]
- Dashboard: Show the Insights tab beside Traffic while the site is running the customer preview, and name both tabs in the preview's welcome, feedback and switch-off copy. [#52525]
- Draw attention to the date control, and read the new period out, when a card or a table cell sets the period rather than the reader. [#52255]
- Insights: Align the Most popular post and Latest post cards with the design: regular-weight stat labels and a grey ground behind the featured image. [#52319]
- Insights: Replace the daily Traffic views activity heatmap with a "Views over years" table of monthly views. [#52311] [#52364]
- Insights: Use the page icon for the Posts metric in the All-time stats widget. [#52373]
- Leaderboard widgets: Adjust row appearance in Top tags & Categories and its report. [#52317]
- Let dashboard sections declare their default widget layout when they register, and pass that layout and the section id to the `jetpack_premium_analytics_dashboard_default_layout` filter. [#52452]
- Let hosts show or hide the Analytics sidebar entry. [#52351]
- Open the exact-figure tooltip below compact values instead of above them. [#52374]
- Post detail: Bring the page back to the top when a month in All-time traffic sets the period. [#52320]
- Posting activity: Show the last 12 months as one mini calendar per month. [#52265]
- Rename the Subscribers summary widget to Subscriber summary. [#52413]
- Show the heatmap tooltips in the dark style, the daily ones titled with the date, and draw the Views over years and All-time traffic cells as flush bands under a continuous scale. [#52369]
- Subscribers: Move the date range control off the tab header and onto the Subscriber summary chart; the tab no longer offers a previous-period comparison. [#52421]
- Subscribers: Rename the first Subscriber highlights tile to All-time subscribers. [#52310]
- Subscribers: Show subscriber counts from 30, 60, and 90 days ago, and social followers, on the Subscriber highlights card. [#52310]
- Update package dependencies. [#52187] [#52401] [#52402]

### Removed
- Ads: Remove the Sponsored Content History and Adjustments History widgets. [#52420]
- Remove the unused `dashboards/{name}/default-layout` REST route. [#52451]
- Subscribers: Remove the Metrics control from the Subscriber highlights card. [#52310]

### Fixed
- Ads: Open the WordAds chart on the last 7 days rather than a single day on a site launched today. [#52421]
- Keep the first partial week or month bucket of a period list report when the date range starts mid-period. [#52366]
- Keep the keyboard-selected cell of the Views over years and All-time traffic heatmaps in view, clear of the month and year labels, when the grid scrolls. [#52259]
- Keep the originating report in post detail breadcrumbs when opening a post from a dashboard widget. [#52430]
- Keep the year column and month labels of the Views over years and All-time traffic heatmaps fully opaque while the grid scrolls. [#52309]

## [0.7.0] - 2026-09-15
### Added
- Add a dismissible feedback banner above the dashboard widgets. [#52325]
- Ads: Add an earnings history report page, showing every period with its earnings, ads served, and payment status. [#52323]
- Date picker: Add the "Month to date" and "Year to date" periods. [#52088]
- Locations: Add a map of views by location to the report, with an option to hide it. [#51808]
- Post detail: Add a "Totals" column to the "All-time traffic" card, with month labels that stay in view as the history scrolls. [#52137]
- Post detail: Add a "Total views" / "Daily average" switch to the "All-time traffic" card. [#52127]
- Traffic: Note in the widget help that the "Visitors" total is a per-period sum. [#52085]

### Changed
- Add feedback and the preview opt-out to the page options menu on post and video detail pages, and a "Reset to default" button while customizing. [#52190]
- Ads: Rearrange the default widgets for the three-column grid, with the chart first, then the balance, then the three history tables side by side. [#52232]
- Ads: Show ads served, average CPM and revenue together in the chart tooltip, whichever tab is selected. [#52262]
- Build the custom date range calendar on the WordPress design system calendar. [#52090]
- Dashboard: Ask the same readiness question when switching the new "Traffic" tab off, and point to the "Modules Visibility" setting to switch it back on. [#52186]
- Dashboard: Ask whether the new "Traffic" tab is ready to replace the old one, instead of how it compares with the old one. [#52109]
- Dashboard: Hide the date controls while customizing the layout, instead of disabling them. [#52176]
- Dashboard: Move "Customize" into the page options menu, and offer "Reset to default" beside "Cancel" and "Done" while customizing. [#52192]
- Date picker: Offer common periods, removing "Last 90 days", "Last 365 days" and "Last year" from the menu. [#52124]
- Date range: Measure day boundaries in the site's time zone and report no period length when a range ends before it starts. [#52065]
- Draw the "Post views" and "Video performance" charts as bars by default on post and video detail pages. [#52174]
- Feedback: Tell readers where their feedback went and that they can send more, instead of a one-line thank you. [#52107]
- Highlight widgets: Arrange metric tiles as a list in a one-column widget, or as a single row or two-column grid in a wider widget. [#52258]
- Insights: Align the widget help text and the "Year in review" and "All-time stats" header icons with the design. [#52253]
- Insights: Always show every total on the "All-time stats" card, and remove its "Metrics" control. [#52261]
- Insights: Label the "Tags & categories" widget with its 7-day window, and the most commented and shares widgets as all-time. [#52308]
- Insights: Lay out the default widgets on the three-column grid in the design's order. [#52253]
- Insights: Remove "Total views", "Total visitors", "Popular days" and "Popular hours" from the default layout, and hold the four widgets back from every widget picker for now. [#52216]
- Insights: Remove the year filter and interval dropdown from the section header. [#52175]
- Insights: Rename the section title to "Site insights". [#52314]
- Insights: Show "All-time stats" totals as compact figures, with the exact total in a tooltip. [#52306]
- Insights: Show the "Most popular time" and "Most popular day" highlights side by side, stacking them only on a narrow tile. [#52219]
- Keep the custom range calendar's "Cancel" and "Apply" buttons at the bottom of the period menu. [#52116]
- Onboarding: Show the "Skip tour" button on every step of the spotlight tour. [#52140]
- Pin and condense the post and video detail headers on scroll, as on the dashboard, with the tabs scrolling away, the subtitle folding and the media shrinking to the title row. [#52149]
- Pin the section header on the report pages, as on the dashboard. [#52142]
- Popular post: Retitle the card to "Most popular in the last year". [#52254]
- Post All-time traffic: Share the monthly heatmap through the widgets toolkit and let translators order the month and year in its tooltip. [#52223]
- Post detail: Replace the daily "Traffic activity" heatmap with an "All-time traffic" table of monthly views, and picking a month applies it as the page's period. [#52118] [#52214]
- Report date filters: Stage a date range through one shared bounds helper in both pickers. [#52064]
- Show the exact number on hover behind abbreviated figures, and abbreviate with one decimal where it fits (1.2K, 54.3K, 234K). [#52177]
- Subscribers: Show "Subscriber highlights" by default and rearrange the widgets for the three-column grid. [#52231]
- Update package dependencies. [#52162] [#52200] [#52297]

### Removed
- Remove the arrows that stepped the date range back and forward a period. [#52108]

### Fixed
- Anchor the activity heatmaps' window fallback on the site's today instead of the viewer's. [#52173]
- Calendar heatmap: Show the weekday, month and tooltip labels in the site's language. [#52115]
- Date comparison: Keep the same calendar dates for a range starting on the 1st, so "Year to date" in a leap year compares against 1 January of the previous year rather than 31 December. [#52215]
- Dialogs: Keep the comment field's focus ring from being clipped by the dialog footer. [#52110]
- Most commented authors: Link WordPress.com commenters to the comment screen filtered to their comments, as guest commenters already are. [#52291]
- Offer every period the dashboard's date picker does, plus a custom range, on post, page and video detail pages. [#52087]
- Onboarding: Keep the welcome modal open on a click outside it, so the tour can still be started. [#52095]
- Stop the first and last dates on a chart's horizontal axis from being cut off. [#52112]
- Year in review: Match the metric tile icons to the design, and add space between the tiles and the footer link. [#52307]

## [0.6.1] - 2026-09-09
### Changed
- Internal updates.

## [0.6.0] - 2026-09-08
### Added
- Add an "Any feedback?" action to the dashboard header. [#51870]
- Dashboard: Add a page option that switches the new Traffic tab off, asks why on the way out, and returns to classic Stats. [#52025]
- Dashboard: Show the onboarding again to a reader who switches the new Traffic tab back on. [#52038]
- Date controls: Add a dropdown for common periods and a calendar for custom ranges. [#51835]
- Detail pages: Add a page options menu with a Customize action to the post, email, and video detail pages; card arrangement persists per page and tab. [#51772]
- Expose the dashboard opt-in as a site setting. [#51864]
- Onboarding: Add the welcome modal shell. [#51938]
- Onboarding: Add the widget grid animation for the welcome modal. [#51934]
- Onboarding: Follow the welcome modal with a three-step spotlight tour of the customization menu, the date controls and the widgets. [#51949]
- Onboarding: Open the welcome modal the first time a reader reaches the dashboard. [#51948]
- Send dashboard feedback on to Jetpack support, so it is not lost when analytics are blocked. [#51921]

### Changed
- Comparison control: Mark an active comparison with a "vs" prefix, and name the compared window in the trigger's tooltip. [#51820]
- Dashboard: Disable the date controls while customizing the layout. [#52024]
- Dashboard: Hide the report pages behind tabs the dashboard does not show. [#51983]
- Dashboard: Limit customization to moving and resizing widgets. [#51986]
- Dashboard: Move the feedback action into a page options menu. [#52023]
- Date controls: Pick the period from a dropdown instead of a row of buttons, with the calendar beside it on Custom range. [#51842]
- Detail pages: Even out the header spacing on the post page to match the video page. [#51875]
- Detail pages: Lay out post and video widgets on the dashboard's three-column grid. [#52044]
- Detail pages: Match the post and video page headers to the layout used across the rest of Analytics. [#51875]
- Display the dashboard on a three-column grid and rearrange the default Traffic widgets. [#51873]
- Feedback modal: Render with the design system Dialog and TextareaControl. [#51968]
- Match the Jetpack logo in the Stats header to the 20px size used by the other Jetpack admin pages. [#52060]
- Onboarding: Revise the welcome modal copy and reorder the tour to start from the widgets and end on the page options menu. [#52025]
- Reports: Open the Authors, Clicks and UTM reports folded to their top-level groups, and move the drill-down control to the right of the row title. [#51806]
- Update package dependencies. [#51701] [#51853]

### Removed
- Plan usage: Remove the widget and its upgrade link from the dashboard. [#51834]
- Remove the segmented date preset control, replaced by the period dropdown. [#51881]

### Fixed
- Comparison control: Stop showing a comparison as active when there is no window behind it. [#51820]
- Dashboard: Keep the four-column layout regardless of a stored columns preference. [#51939]
- Dashboard sections: Stop requiring `Enablement_Setting` by path, which caused errors on sites that include this package in more than one plugin. [#52029]
- Date controls: Include the current day in last-N-day ranges and calculate 12-month ranges in whole calendar months. [#51428]
- Insights: Collapse the year buttons into a select as soon as they stop fitting, instead of letting them run past the edge on a phone. [#51882]
- Keep the date picker on the range a chart drill-down applies. [#51924]
- Onboarding: Keep keyboard focus inside the tour card and let screen reader users skip the tour. [#51975]
- Posting activity: Count published posts by the site's calendar day rather than the UTC one. [#51878]
- Show chart dates in the site's timezone and locale, and name the hour on hourly charts. [#51814]
- Show published dates in the site's language and date format. [#51967]

## [0.5.0] - 2026-09-01
### Added
- Add a year dropdown to the Year in review (Highlights) widget header, defaulting to the current year, and drop its metric selector so the card always shows posts, words, likes, and comments. [#51638]
- Annual insights: Add total and per-post image counts to the report. [#51747]
- Insights: Add the All-time stats widget to the default layout. [#51635]
- Insights: Add the Most popular day widget to the default layout, and say in its help note that its figures are all-time. [#51645]
- Insights: Add the Most popular time card to the default layout. [#51636]
- Traffic chart: Click a point on the chart to narrow the dashboard to that period. [#51544]

### Changed
- Ads: Move the date range into the WordAds card's own header, and drop the section header's date filter. [#51543]
- Chart interval control: Name the active interval in the button's tooltip, and give its menu a heading. [#51770]
- Charts: Take the series palette from the charts package instead of seeding it locally. [#51535]
- CSV export will now handle `\"` sequences per RFC 4180. [#51572]
- Date controls: Build the comparison menu from the applied range and restore the same-period-last-week option. [#51779]
- Date controls: Turn the period comparison off by default. [#51771]
- Date filters: Share one staged-value controller between the URL-backed and widget-backed surfaces, and resolve the chart interval against the same range on both. [#51644]
- Date range control: Name a custom range covering a whole month or year by that period, and spell the dates out in the button's tooltip. [#51817]
- Divide a widget's metrics with lines instead of boxing each one. [#51749]
- Insights: Retitle the Popular post card to "Most popular post in the last 12 months" and pin it to the last 12 months. [#51649]
- Insights: Shorten the Popular post card title so it survives a narrow dashboard cell. [#51746]
- Leaderboards: Give shared rows one row height, bar radius, and link hover. [#51595]
- Leaderboards: Match the Most viewed and Videos row labels to the other leaderboard widgets. [#51599]
- Leaderboards: Match the remaining row labels to the other leaderboard widgets. [#51602]
- Leaderboards: Tighten the spacing between rows. [#51540]
- Post and video details: lead the date presets with All time (from the publish date), drop the custom range, period arrows, and interval dropdown per the design, and highlight the selected preset in the brand color. [#51533]
- Post detail: Remove the settings drawer from the Email highlights and Email breakdown cards; their metric and view are fixed by the tab layout. [#51659]
- Post detail: The email tabs' opens and clicks timelines cover the first 30 days after the send instead of the page date filter, which no longer shows there; the other email cards stay all-time. [#51547]
- Subscriber list: Match the row height, avatar size, and footer type to the design. [#51597]
- Top locations: Add breathing room above and below the map. [#51593]
- Top pages: Rename the CSV comparison column to "Views (Previous Period)" and move it after the primary columns. [#51705]
- Traffic summary: Follow the page chart interval control instead of a widget-level Group by. [#51532]
- Update package dependencies. [#51303] [#51802]
- Video details: Fold the highlight metrics into the Video performance chart as selectable tabs. [#51501]
- Widget skeletons: Stop exposing the loading placeholder as a status region. [#51753]

### Removed
- Minimum supported PHP version is now 7.4. [#51515]
- Remove the date configuration subtitle from the section header. [#51707]
- Remove the page descriptions from the dashboard and report pages. [#51707]
- Remove the unused granularity attribute from the default WordAds chart widget instance. [#51585]

### Fixed
- Ads: Drop the Last 24 hours range from the WordAds card, which has no hourly data to chart. [#51633]
- Ads: Include the last day of the selected range in the WordAds card. [#51751]
- Ads: Stop the chart interval menu offering buckets the WordAds chart cannot draw. [#51639]
- Align title link styling across widgets: external video rows gain the standard outbound marker, long titles no longer clip it, and hover underlines cover only the title text. [#51534]
- Annual insights: Keep the Year in review report link reachable. [#51747]
- Annual insights: Print the words-per-post average whole, as the old Stats report does. [#51747]
- Charts: Remove the quarterly interval option, which never changed the chart. [#51631]
- Date filters: Keep the custom range Apply button disabled when re-selecting "No comparison". [#51764]
- Decode HTML entities in post titles, author names, and other Stats labels. [#51632]
- Emails: Decode HTML entities in email subject lines. [#51596]
- Email timeline: Request the smallest hourly window the endpoint can serve and trim the chart and totals to the selected window. [#51588]
- Insights: Show the Most popular time day and hour in the site's locale. [#51636]
- Most popular day: Give the Day and Views labels the weight the design has them at and the heading structure a screen reader can navigate, state a share of views only when there is an all-time total to take it from, and drop the Retry a reader without stats access cannot use. [#51645]
- Most popular day: Show the whole card on a short tile instead of clipping it. [#51645]
- Post detail: Stop the Post traffic layout from flashing when an email tab is opened directly, and show placeholder lines in the header while the title loads. [#51805]
- Referrers: Treat a group with an empty results list as an external-link row. [#51757]
- Show a notice when a refresh fails, instead of silently leaving the previous numbers on screen. [#51383]
- Subscriber list: Link a subscriber's name to their subscriber details page. [#51634]
- Subscriber list: Order subscribers by subscription date instead of by subscriber type. [#51598]
- Subscribers summary: Fix the help text to describe the cumulative subscriber total the chart plots, not new subscribers. [#51697]
- Tables: Fall back to the last page instead of reporting no results when a date range returns fewer rows than the current page. [#51755]
- Tags & categories: Print view counts in full, and list far more rows in the report. [#51646]

## [0.4.0] - 2026-08-25
### Added
- Add an Ads dashboard section showing WordAds earnings and performance. [#51422]
- Charts: Name each legend item by metric, folding a metric's two periods into one item. Traffic summary: add the paired metric to the chart, hidden until revealed from the legend. [#51468]
- Insights: Add a Popular hours widget and show it instead of Most popular day by default. [#51239]
- Link the post list table's views column to the post detail page. [#51357]
- Locations: Name the regions behind each country total in the Regions map tooltip. [#51312]
- Page the calendar heatmaps through weeks that do not fit the tile with floating hover arrows, replacing the post detail header pager and the Insights heatmaps' silent clipping. [#51437]
- Referrers report: Add referrer groups that open folded and expand on demand. [#51465]

### Changed
- Chart widgets: Follow the page chart interval control instead of a per-widget Group by. [#51278]
- Latest emails sent: Drop the bar behind each row and show the subject and rate as a plain list. [#51425]
- Leaderboard: Replace the deprecated `--a8c--charts--leaderboard--bar--border-radius` variable with `--a8c-charts-border-radius-leaderboard-bar`. [#51308]
- Name comparison dates in the dashboard header, omit weekdays from ranges longer than a week, and omit the year when it matches the current range. [#51420]
- Traffic: Offer only the groupings the selected date range supports in the chart's Group by control. [#51446]

### Fixed
- Apply the first widget section flex-column workaround to the post and video detail routes too. [#51434]
- Charts: Label chart points by the bucket they name rather than by the viewer's time zone, and format axis ticks and tooltips at the series' declared bucket size. [#51445]
- Date comparison: End a sub-day previous period immediately before the reference window instead of one instant inside it. [#51374]
- Date filters: Compute day boundaries and daylight-saving wall times in the site's timezone instead of the visitor's browser timezone. [#51419]
- Fix charts getting stuck on their loading skeleton after switching a control that turns one of the underlying requests off. [#51443]
- Insights: Scope the calendar heatmaps to the selected period, so the card no longer draws and reports on years outside it. [#51385]
- Label Subscribers chart and email timeline points by the bucket they name rather than by the viewer's time zone. [#51499]
- Show only the rows that fit the tile for Latest subscribers, Latest likes, and Latest comments, while keeping the "N more" footer visible. [#51379]
- Show the dashboard right away instead of a sync screen, and flag the Store section's numbers as incomplete while store data is still syncing. [#51279]
- Stats: Compare a date range against a previous month or year of the same length, unless the range is whole calendar months. [#51469]
- Stats: Stamp bucket dates as timezone-naive site-local wall times, fixing report dates that could read a day off for sites away from UTC. [#51499]
- Traffic: Start the chart's Group by control from the dashboard's interval, and replace Auto with hourly grouping. [#51446]

## [0.3.0] - 2026-08-20
### Added
- Date controls: Let each dashboard section declare whether its header offers the period-over-period comparison control. [#51230]
- Date controls: Offer an hourly view for multi-day ranges under a week, keeping days as the default. [#51118]
- Date controls: Step the active window backward or forward by its length. [#51118]
- Detail pages: Give the post views, video views and email timeline charts the metric total headline and the chart-type control, sharing one chart-display attribute definition across the chart widgets. [#51198]
- Insights: Add a calendar heatmap of daily site views with centered loading and error states. [#51139]
- Insights: Add a Popular days widget showing the busiest day of the week and how views are distributed across the week. [#51140]
- Post detail: Give the email tabs an email header identity — envelope tile and the email sent date. [#51260]
- Top locations: Offer Regions in the widget's "View by" control. [#51267]

### Changed
- Charts: Derive series colors from the theme accent instead of a fixed palette, so neighbouring categories stay distinguishable. [#51356]
- Chart widgets: Pick the chart type from an icon toggle instead of a dropdown. [#51337]
- Chart widgets: Remove the Metrics selector from Traffic summary, Subscribers summary, WordAds, and Store performance — the metric tabs already choose what the chart plots. [#51163]
- Dashboard: Fade the section header subtitle out as the widgets scroll. [#51232]
- Dashboard: Give each section its own heading and description. [#51092]
- Dashboard: Hide the Subscribers tab on sites where the Jetpack subscriptions module is turned off. [#51242]
- Dashboard: Keep the section title and date controls in view while the widgets scroll. [#51232]
- Date controls: Clarify comparison and interval controls and shorten custom-range labels. [#51231]
- Date filters: Drop the "Last" prefix from the 7-day, 30-day, and 12-month preset labels. [#51340]
- Detail pages: Match the dashboard's tightened widget Card padding. [#51199]
- Detail pages: Stretch the post highlights row full-width and label video dates as upload dates. [#51257]
- Email clicks: Restore the country map beside the Locations leaderboard. [#51258]
- Highlights: Follow the section's all-time and yearly date selection instead of always showing the most recent year, and show every metric on a dashboard whose layout carries no metric selection. [#51084]
- Insights: Give the Traffic views activity heatmap two rows by default, so each day shows its view count. [#51240]
- Metric tabs: Improve card layout and render a single metric as a static headline. [#51142]
- Posting activity: Show more history, larger cells, and a count-first tooltip, and drop the Fewer/More posts legend. [#51161]
- Post traffic activity: Show more weeks per page in the views heatmap. [#51201]
- Reports: Name a report and the records it is showing separately, so the breadcrumb reads "All pages" where the heading reads "Posts & pages report". [#51309]
- Reports: Remove unsupported period-over-period comparison controls while preserving the dashboard selection. [#51309]
- Reports: Show the report title and the applied date range above the records, matching the dashboard's section header. [#51309]
- Section header: Truncate a long title with an ellipsis instead of wrapping it and compressing the date controls. [#51133]
- Serve the dashboard only from its registered, capability-gated admin page. [#51203]
- Shares: Hide the widget outside WPCOM Simple, where share counts are never recorded. [#51244]
- Show a skeleton placeholder instead of a spinner while widget content loads. [#51202]
- Show content-shaped skeleton placeholders while widget content loads. [#51207] [#51236] [#51237] [#51418]
- VideoPress: Hide video analytics on sites without VideoPress. [#51243]
- Widget copy: Use sentence case for the drill-down back links, and shorten the Popular post description to one sentence. [#51171]
- Widgets: Order the traffic metric tiles Views, Visitors, Comments, Likes, and name the Latest emails sent view selector "By open rate" and "By click rate". [#51206]
- Widgets: Restyle the footer actions to match the dashboard design — a "View all" link and an icon-only CSV download. [#51174]
- Widget settings: Drop the "Number of results" control and request a shared row limit instead; report pages own showing more rows. [#51378]

### Fixed
- Darken and enlarge chart axis labels, and show a tooltip when hovering a Devices chart segment. [#51165]
- Dashboard: Add spacing below the widget grid so the last row no longer sits flush against the end of the page. [#51159]
- Date controls: Reset the custom range when a preset is selected, so the picker no longer shows two different ranges at once. [#51269]
- Date controls: Stop applying hidden date comparisons in dashboard sections that do not offer the control while preserving them when returning to supported sections. [#51381]
- Date controls: Use hourly buckets for day-long ranges. [#51118]
- Date filters panel: Avoid a one-frame flash of mismatched labels while resizing. [#51133]
- Date filters panel: Recover the full preset labels when space returns in the dashboard section header, instead of staying abbreviated. [#51133]
- Fix report dates shifting by a day on sites west of UTC, and stop the date picker briefly using the visitor's timezone on load. [#51205]
- Keep widget numbers on screen while unchanged data is refreshed in the background. [#51384]
- Post traffic activity: Fit the heatmap cells to the tile height so the month labels are no longer clipped. [#51214]
- Remove the duplicate padding around the chart-tab widgets. [#51175]
- Reports: Hide unexplained period-over-period deltas while preserving the dashboard comparison selection. [#51341]
- Section header: Describe an hour-snapped window by its full length and name a rolling day window by its end day. [#51118]
- Show an error when dashboard components are unavailable. [#51141]
- Stats: Align the post activity heatmap with the design: draw the current week only through today, and lead the cell tooltip with the view count. [#51181]
- Subscribers: Fix the chart legend rendering its date range reversed. [#51277]

## [0.2.0] - 2026-08-10
### Added
- Add Total views and Total visitors dashboard widgets. [#51055]
- Add translated DateFiltersPanel stories (Russian, Dutch, German) that render the date bar at several container widths, so the layout is reviewed against real language packs rather than English only. [#50906]
- Date controls: Add a chart interval control that sets the bucket size for every chart on the page. [#51112]
- Detail pages: Show the report the visitor came from in the breadcrumb. [#50956]
- Insights: Add an all-time and yearly date selection, configurable per dashboard section. [#50930]
- Insights: Add a Popular post widget, and adapt the single-post highlight card to both the width and the height of its dashboard cell. [#50931]
- Publish the dashboard page slug, capability, and site timezone in Jetpack script data, so other Jetpack surfaces can link to the dashboard. [#50926]
- Summary charts: Add a Chart type control to switch between lines and bars. [#51089]
- Video detail: Restore the date filter presets now that the preset measurement rework has landed, and keep comparison params from reaching the page's widgets. [#51082]

### Changed
- Dashboard: Tighten widget Card padding to fit the screen better. [#51101]
- Date controls: Abbreviate the month on the custom-range trigger, e.g. "Aug 2 – 9, 2025", so a long range costs the row less width. [#51094]
- Date controls: Keep the date presets as a row of pills at every width, abbreviating their labels in a narrow row rather than collapsing the choice into a dropdown. [#51094]
- Date controls: Make comparison an additive control that shows as a + button until a period is picked, then collapses into a labelled trigger. [#51094]
- Date controls: Name the active comparison preset on the picker, e.g. "Prev. period", instead of the dates it resolves to. [#51094]
- Date filters panel: Allow measuring an external container with a reserved share, so the panel's responsive layout works in shrink-to-fit slots. [#51088]
- Date filters panel: Shorten preset labels before collapsing into a select, measuring from the active language's own labels and from the panel itself, so callers no longer pass a container element. [#50906]
- Highlights: Always show the most recent year, fit the full metrics at the minimum widget height, tighten metric tile spacing in wide short widgets, and show every metric when none is saved. [#51052]
- Insights: Reorder and resize the default widgets so each row fills the grid, and add Popular post, Total views, and Total visitors to the defaults. [#51024]
- Load the dashboard assets only on requests that render an admin screen, so front-end page views no longer parse them. [#50890]
- Name the dashboard "Stats" in its header and breadcrumbs, and mark the header with the Jetpack logo. [#51022]
- Post detail page: Apply the video-page parity fixes — inline date filters on the title row with row-width degradation and no comparison, long-title overflow and featured-image sizing fixes, and the post-views day-shift fix. [#50971]
- Rename the "Most commented posts" and "Most commented authors" widgets to "Top commented posts" and "Top commented authors". [#51090]
- Route the ui, fields, and icons packages through the externals script module so shared third-party libraries are no longer duplicated across their bundles. [#50964]
- Section header: Wrap the subtitle before shortening the date preset labels, and stack the title and the controls onto separate rows once the header is too narrow to hold them side by side. [#51094]
- Subscribers: Drop Subscriber highlights from the default widgets so the board opens on the chart. [#51025]
- Traffic: Reorder and resize the default widgets so each row fills the grid, rename Summary to Traffic summary, and drop Plan usage from the defaults. [#51023]
- Update package dependencies. [#50509]
- Video detail page: Align the composition with the design mock by adding range-scoped highlight metrics, a Views performance chart, a poster thumbnail, and the renamed "Used on posts & pages" card. [#50970]
- Widgets: Update dashboard widget icons to match the design reference. [#51087]

### Removed
- Date controls: Drop the "Previous week" comparison preset, leaving the previous period, month and year. [#51094]

### Fixed
- Dashboard: Fix the dashboard opening as an empty edit-mode canvas when a post or video detail page was loaded first. [#51033]
- Dashboard: Make the first widget section a flex column so stacked chrome content lays out correctly until the upstream Gutenberg fix lands. [#51070]
- Date controls: Shorten the preset labels before the comparison control runs out of room, rather than after it has already overflowed the header, and keep its label on one line. [#51094]
- Detail highlights: Scroll the stacked tiles at narrow widths instead of clipping the bottom tile out of reach. [#51108]
- Restore PHP 7.2 compatibility for the Premium Analytics admin page. [#51078]
- Stats: Keep the "Last 24 hours" range aligned to whole hours so identical widget requests share one cached fetch. [#50916]
- Stats: Send the full site-local date/time to Stats endpoints now that the API resolves it correctly, instead of trimming to a bare calendar day. [#50916]
- Stats breadcrumbs: Fix a long unbroken crumb widening the page into horizontal scrolling instead of truncating. [#51085]

## 0.1.0 - 2026-08-03
### Added
- Add a post and page detail view with its own traffic, email, and interaction widgets. [#50096] [#50457]
- Add connection-aware `/connect` and `/syncing` routes, and track the analytics initial full-sync milestone for the dashboard. [#49211] [#49650]
- Add CSV export across report pages and widgets, delivered as a download or by email. [#50329] [#50330] [#50716]
- Add report pages for posts and pages, clicks, referrers, UTM, locations, search terms, videos, downloads, top authors, emails, and insights. [#50305] [#50561]
- Add the internal `ui`, `data`, `datetime`, `formatters`, `icons`, `routing`, `fields`, and `widgets-toolkit` packages, ported from next-woocommerce-analytics. [#49263] [#49422]
- Add the WooCommerce Analytics front-end tracker and an interim port of the `woocommerce_analytics` Sync module. [#49652] [#50202]
- Allow users with the `view_stats` capability to open the Analytics dashboard, and shop managers to read the store reports. [#50889]
- Dashboard: Add a section-based layout of configurable widgets, with a date-range picker and period-over-period comparison shared by every widget. [#49572] [#50167]
- Email: Add opens and clicks totals, a breakdown by country, device, client and link, a performance time series, and an Emails report page. [#50307] [#50572]
- Enable Jetpack Stats page-view tracking when Premium Analytics is active. [#50524]
- Initial version. [#48085]
- Insights: Add widgets for posting activity, most popular day and time, annual highlights, tags and categories, comments, and UTM traffic breakdowns. [#50034] [#50151]
- Render report links only when their URL scheme is http(s). [#50610]
- REST: Add one endpoint-agnostic proxy to WordPress.com under `jetpack-premium-analytics/v1`, plus dashboard notices and cached responses. [#49571] [#49645]
- Stats data layer: Add proxy query definitions, report hooks, and response normalizers. [#49777] [#49778] [#49779]
- Store: Add a WooCommerce dashboard section with widgets for sales, orders, conversion rate, coupons, customer type, bookings, and visitors. [#49422] [#50364]
- Subscribers: Add highlights, latest subscribers, and a growth chart with a previous-period overlay. [#50064] [#50299]
- Traffic: Add widgets for site overview, all-time stats, top posts and pages, authors, referrers, locations, search terms, devices and platforms, clicks, file downloads, and shares. [#49568] [#50302]
- VideoPress: Add a video detail page with plays leaderboard, video highlights, and embed locations. [#50311] [#50536]
- WordAds: Add widgets for ads served, average CPM and revenue over time, all-time earnings highlights, and earnings, sponsored content and adjustments history. [#50314] [#50490]

[0.18.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.17.0...0.18.0
[0.17.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.16.0...0.17.0
[0.16.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.15.0...0.16.0
[0.15.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.14.0...0.15.0
[0.14.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.13.0...0.14.0
[0.13.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.12.0...0.13.0
[0.12.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.11.0...0.12.0
[0.11.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.10.0...0.11.0
[0.10.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.9.0...0.10.0
[0.9.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.8.0...0.9.0
[0.8.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.7.0...0.8.0
[0.7.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.6.1...0.7.0
[0.6.1]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.6.0...0.6.1
[0.6.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.5.0...0.6.0
[0.5.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.4.0...0.5.0
[0.4.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.3.0...0.4.0
[0.3.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.2.0...0.3.0
[0.2.0]: https://github.com/Automattic/jetpack-premium-analytics/compare/0.1.0...0.2.0
