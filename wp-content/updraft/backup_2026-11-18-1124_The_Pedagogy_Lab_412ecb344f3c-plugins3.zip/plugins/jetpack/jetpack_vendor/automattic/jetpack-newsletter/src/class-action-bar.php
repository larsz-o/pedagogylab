<?php
/**
 * WordPress.com Action Bar.
 *
 * The floating bar in the bottom corner of a site's front end. Visitors can subscribe, comment,
 * reblog and report from it; site members get Edit and Stats shortcuts.
 *
 * @package automattic/jetpack-newsletter
 */

namespace Automattic\Jetpack\Newsletter;

use Automattic\Jetpack\Assets;
use Automattic\Jetpack\Status;
use Automattic\Jetpack\Status\Host;

/**
 * The floating Action Bar on the front end of WordPress.com Simple sites. Ported from wpcom `wp-content/mu-plugins/actionbar.php`.
 */
class Action_Bar {
	/**
	 * Transient caching whether the site has published enough posts to show Subscribe.
	 *
	 * @var string
	 */
	const ENOUGH_POSTS_TRANSIENT = 'jetpack_action_bar_has_enough_posts';

	/**
	 * Whether the class has been initialized.
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Queue the Action Bar to load once all plugins are available.
	 *
	 * Simple only for now. Yields to the copy wpcom still ships in mu-plugins, so the two never load together.
	 *
	 * @since 0.17.0
	 */
	public static function init() {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		if ( ! ( new Host() )->is_wpcom_simple() ) {
			return;
		}

		// A callback added to the hook that is currently running never fires.
		if ( did_action( 'plugins_loaded' ) ) {
			self::load();
		} else {
			add_action( 'plugins_loaded', array( __CLASS__, 'load' ) );
		}
	}

	/**
	 * Register the bar's hooks unless wpcom's mu-plugin copy is loaded.
	 *
	 * @since 0.17.0
	 */
	public static function load() {
		if ( function_exists( 'wpcom_actionbar_enqueue_scripts' ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ), 101 );
		add_action( 'admin_init', array( __CLASS__, 'settings_field' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'flush_published_posts_count' ), 10, 3 );

		add_action( 'wp_ajax_fold_actionbar', array( __CLASS__, 'fold' ) );
		add_action( 'wp_ajax_nopriv_fold_actionbar', array( __CLASS__, 'fold' ) );
		add_action( 'wp_ajax_unfold_actionbar', array( __CLASS__, 'unfold' ) );
		add_action( 'wp_ajax_nopriv_unfold_actionbar', array( __CLASS__, 'unfold' ) );
		add_action( 'wp_ajax_actionbar_stats', array( __CLASS__, 'ajax_stats' ) );
		add_action( 'wp_ajax_nopriv_actionbar_stats', array( __CLASS__, 'ajax_stats' ) );
	}

	/**
	 * Decide whether the bar renders on this request and, if so, queue its data and footer output.
	 */
	public static function enqueue_scripts() {
		if ( get_option( 'wpcom_hide_action_bar' ) ) {
			return;
		}

		$current_user = wp_get_current_user();

		/**
		 * Filters whether the Action Bar loads on this request.
		 *
		 * WordPress.com hooks this to keep the bar off its internal sites and off sites marked deleted, spam, archived, or parked.
		 *
		 * @since 0.17.0
		 *
		 * @param bool $enabled Whether to load the bar. Default true.
		 */
		if ( ! apply_filters( 'jetpack_action_bar_enabled', true ) ) {
			return;
		}

		$site_id = get_current_blog_id();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only checks on preview query args.
		// Don't show on theme previews and block patterns source sites.
		$is_theme_demo = function_exists( 'wpcom_is_theme_demo_site' ) && wpcom_is_theme_demo_site();
		// @phan-suppress-next-line PhanUndeclaredFunction -- Defined by jetpack-mu-wpcom, which is not a dependency; guarded by function_exists().
		$is_pattern_source = function_exists( 'wpcom_has_blog_sticker' ) && wpcom_has_blog_sticker( 'block-patterns-source-site', $site_id );
		if ( isset( $_GET['theme'] ) || $is_theme_demo || $is_pattern_source ) {
			return;
		}

		// Don't show on Customizer previews.
		if ( isset( $_GET['customize_theme'] ) || isset( $_GET['customize_changeset_uuid'] ) ) {
			return;
		}
		// phpcs:enable

		// Don't show on WordPress mobile apps.
		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( $user_agent && preg_match( '/wp-(android|iphone)/', $user_agent ) ) {
			return;
		}

		// Don't show on Landpack blogs, unless user is a member of the blog.
		if ( defined( 'WPCOM_LANDPACK_BLOG_IDS' ) && in_array( $site_id, (array) WPCOM_LANDPACK_BLOG_IDS, true ) && ! is_user_member_of_blog( $current_user->ID, $site_id ) ) {
			return;
		}

		// Render this in the user's language.
		self::switch_to_user_locale();

		$status_message    = false;
		$status_subscribed = false;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Status flag set by the subscribe.wordpress.com redirect.
		$blogsub = isset( $_GET['blogsub'] ) ? sanitize_key( wp_unslash( $_GET['blogsub'] ) ) : '';
		switch ( $blogsub ) {
			case 'confirming':
				$status_subscribed = true;
				$status_message    = '<h3>' . __( 'Thanks', 'jetpack-newsletter' ) . '</h3>';
				$status_message   .= '<div>' .
					wp_kses(
						sprintf(
							/* translators: %s is the URL of the support contact page. */
							__( 'You’ll get an email with a link to confirm your subscription. If it doesn’t arrive, please <a href="%s">contact us</a>.', 'jetpack-newsletter' ),
							esc_url( self::localized_url( 'https://wordpress.com/support/contact/' ) )
						),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					) .
					'</div>';
				break;
			case 'subscribed':
				$status_subscribed = true;
				$status_message    = '<div>' . __( 'You’re already subscribed to this site!', 'jetpack-newsletter' ) . '</div>';
				break;
			case 'flooded':
				$status_message =
					'<div>' .
					sprintf(
						/* translators: %s is a link with its text (Subscription Manager) translated separately */
						__( 'You already have several pending email subscriptions. Approve or delete a few through your %s before attempting to subscribe to more blogs.', 'jetpack-newsletter' ),
						'<a href="https://subscribe.wordpress.com/" target="_blank" rel="noopener noreferrer">' . __( 'Subscription Manager', 'jetpack-newsletter' ) . '</a>'
					) .
					'</div>';
				break;
			case 'pending':
				$status_subscribed = true;
				$status_message    = '<div>' . __( 'You already have a pending subscription, we just sent you another email, click the link or <a href="https://en.support.wordpress.com/contact/">contact us</a> if you don’t get it', 'jetpack-newsletter' ) . '</div>';
				break;
			case 'confirmed':
				$status_subscribed = true;
				$status_message    = '<div>' . __( 'Congrats, you’re subscribed! You’ll get an email with the details of your subscription and an unsubscribe link', 'jetpack-newsletter' ) . '</div>';
				break;
		}

		// VIP: Disable functionality on sites that have logged_out follow set to false.
		if ( ! is_user_logged_in() && self::logged_out_follow_disabled() ) {
			self::restore_locale();
			return;
		}

		$http_host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';

		// Data to pass to the JS.
		$actionbar_info = array(
			'siteID'           => $site_id,
			'postID'           => is_singular() ? get_the_ID() : 0,
			'siteURL'          => get_option( 'home' ),
			'xhrURL'           => esc_url_raw( ( is_ssl() ? 'https://' : 'http://' ) . $http_host . '/wp-admin/admin-ajax.php' ),
			'nonce'            => wp_create_nonce( 'manage_subscription' ),
			'isLoggedIn'       => is_user_logged_in(),
			'statusMessage'    => $status_message,
			'statusSubscribed' => $status_subscribed,
			'subsEmailDefault' => self::email_default( $current_user ),
			'proxyScriptUrl'   => 'https://s0.wp.com/wp-content/js/wpcom-proxy-request.js?ver=20211021',
		);

		if ( is_singular() ) {
			$actionbar_info['shortlink'] = wp_get_shortlink( get_the_ID() );
		}

		$actionbar_info['i18n'] = array(
			'followedText'    => __( 'New posts from this site will now appear in your <a href="https://wordpress.com/reader">Reader</a>', 'jetpack-newsletter' ),
			'foldBar'         => __( 'Collapse this bar', 'jetpack-newsletter' ),
			'unfoldBar'       => __( 'Expand this bar', 'jetpack-newsletter' ),
			'shortLinkCopied' => __( 'Copied to clipboard.', 'jetpack-newsletter' ),
		);

		// Switch back to site language.
		self::restore_locale();

		// An alias handle with no src, so wp_localize_script() prints the data without a script tag.
		// phpcs:disable WordPress.WP.EnqueuedResourceParameters.MissingVersion
		wp_register_script( 'wpcom-actionbar-placeholder', '', array(), null, false );
		wp_localize_script( 'wpcom-actionbar-placeholder', 'actionbardata', $actionbar_info );
		wp_enqueue_script( 'wpcom-actionbar-placeholder' );
		// phpcs:enable

		// Defer loading the actionbar resources.
		add_action( 'wp_footer', array( __CLASS__, 'footer' ) );
	}

	/**
	 * Print the bar's markup, then a loader that appends its CSS and JS after DOMContentLoaded.
	 */
	public static function footer() {
		$is_rtl = function_exists( 'wpcom_is_locale_rtl' ) ? wpcom_is_locale_rtl( get_user_locale() ) : is_rtl();
		self::html( $is_rtl );

		$asset_path = dirname( __DIR__ ) . '/build/action-bar.asset.php';
		$asset_file = file_exists( $asset_path ) ? include $asset_path : array();
		$version    = is_array( $asset_file ) && ! empty( $asset_file['version'] ) ? $asset_file['version'] : Settings::PACKAGE_VERSION;

		// One stylesheet for both directions: it uses logical properties and the bar carries its own dir attribute.
		$css_url = wp_json_encode( add_query_arg( 'ver', $version, plugins_url( '../build/action-bar.css', __FILE__ ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
		$js_url  = wp_json_encode( add_query_arg( 'ver', $version, plugins_url( '../build/action-bar.js', __FILE__ ) ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

		wp_print_inline_script_tag(
			'window.addEventListener( "DOMContentLoaded", function () {
				var link = document.createElement( "link" );
				link.href = ' . $css_url . ';
				link.rel = "stylesheet";
				document.head.appendChild( link );

				var script = document.createElement( "script" );
				script.src = ' . $js_url . ';
				document.body.appendChild( script );
			} );'
		);
	}

	/**
	 * Where the bar's post stats link goes.
	 *
	 * @param int    $post_id           The post.
	 * @param int    $site_id           The site's blog ID.
	 * @param string $site_slug         The site slug in Calypso URLs.
	 * @param bool   $use_calypso_links Whether the site links to Calypso instead of wp-admin.
	 * @return string
	 */
	private static function get_post_stats_url( $post_id, $site_id, $site_slug, $use_calypso_links ) {
		$url = $use_calypso_links
			? sprintf( 'https://wordpress.com/stats/post/%d/%s', $post_id, $site_slug )
			: admin_url( sprintf( 'admin.php?page=stats#!/stats/post/%d/%d', $post_id, $site_id ) );

		/** This filter is documented in projects/packages/stats-admin/src/class-admin-bar.php */
		return apply_filters(
			'jetpack_stats_url',
			$url,
			array(
				'view' => 'post',
				'id'   => $post_id,
			)
		);
	}

	/**
	 * Whether this is a WordPress.com VIP site. False anywhere the wpcom helper is missing.
	 *
	 * @return bool
	 */
	private static function is_vip() {
		return function_exists( 'wpcom_is_vip' ) && wpcom_is_vip();
	}

	/**
	 * Localize a WordPress.com URL for the current user where wpcom can; otherwise return it as is.
	 *
	 * @param string $url A wordpress.com URL.
	 * @return string
	 */
	private static function localized_url( $url ) {
		return function_exists( 'localized_wpcom_url' ) ? localized_wpcom_url( $url ) : $url;
	}

	/**
	 * Whether the user collapsed the bar. A wpcom user attribute on Simple, user meta elsewhere.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function is_folded( $user_id ) {
		if ( function_exists( 'get_user_attribute' ) ) {
			return (bool) get_user_attribute( $user_id, 'is_actionbar_folded' );
		}
		return (bool) get_user_meta( $user_id, 'is_actionbar_folded', true );
	}

	/**
	 * Remember or forget that the user collapsed the bar.
	 *
	 * @param int  $user_id User ID.
	 * @param bool $folded  Whether the bar is collapsed.
	 */
	private static function set_folded( $user_id, $folded ) {
		if ( function_exists( 'update_user_attribute' ) && function_exists( 'delete_user_attribute' ) ) {
			if ( $folded ) {
				update_user_attribute( $user_id, 'is_actionbar_folded', 1 );
			} else {
				delete_user_attribute( $user_id, 'is_actionbar_folded' );
			}
			return;
		}
		if ( $folded ) {
			update_user_meta( $user_id, 'is_actionbar_folded', 1 );
		} else {
			delete_user_meta( $user_id, 'is_actionbar_folded' );
		}
	}

	/**
	 * Whether logged-out visitors should get no bar and no follow actions.
	 *
	 * @return bool
	 */
	private static function logged_out_follow_disabled() {
		$settings = get_option( 'subscription_options' );
		$disabled = self::is_vip() && ( ! isset( $settings['loggedoutfollow'] ) || 'off' === $settings['loggedoutfollow'] );

		/**
		 * Filters whether logged-out visitors get the bar and its follow actions.
		 *
		 * @since 0.17.0
		 *
		 * @param bool $disabled Whether to disable. Defaults to true on VIP sites with logged-out follow off.
		 */
		return (bool) apply_filters( 'wpcom_disable_logged_out_follow', $disabled );
	}

	/**
	 * Whether the site has published enough posts for a Subscribe button to make sense.
	 *
	 * @return bool
	 */
	private static function has_enough_posts() {
		$has_enough_posts = get_transient( self::ENOUGH_POSTS_TRANSIENT );
		if ( false === $has_enough_posts ) {
			// Stored as 1/0: a cached false would read as a cache miss.
			$has_enough_posts = (int) wp_count_posts( 'post' )->publish >= 2 ? 1 : 0;
			set_transient( self::ENOUGH_POSTS_TRANSIENT, $has_enough_posts, DAY_IN_SECONDS );
		}

		return (bool) $has_enough_posts;
	}

	/**
	 * Clear the cached Subscribe answer when a post enters or leaves the published state.
	 *
	 * @since 0.17.2
	 *
	 * @param string         $new_status New post status.
	 * @param string         $old_status Old post status.
	 * @param \WP_Post|mixed $post Post object.
	 */
	public static function flush_published_posts_count( $new_status, $old_status, $post ) {
		if ( ! $post instanceof \WP_Post ) {
			// Some callers fire the action without a populated post object (e.g. failed get_post lookups).
			return;
		}

		if (
			'post' === $post->post_type
			&& $new_status !== $old_status
			&& ( 'publish' === $new_status || 'publish' === $old_status )
		) {
			delete_transient( self::ENOUGH_POSTS_TRANSIENT );
		}
	}

	/**
	 * Switch to the current user's locale, if logged in.
	 */
	private static function switch_to_user_locale() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		if ( function_exists( 'wpcom_switch_to_user_locale' ) ) {
			wpcom_switch_to_user_locale( get_current_user_id() );
		} else {
			switch_to_user_locale( get_current_user_id() );
		}
	}

	/**
	 * Undo switch_to_user_locale().
	 */
	private static function restore_locale() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		if ( function_exists( 'wpcom_restore_current_locale' ) ) {
			wpcom_restore_current_locale();
		} else {
			restore_previous_locale();
		}
	}

	/**
	 * The email delivery frequency a new subscription defaults to for this user.
	 *
	 * @param \WP_User $current_user The current user.
	 * @return string One of instantly, daily, weekly, never.
	 */
	private static function email_default( $current_user ) {
		if ( ! empty( $current_user->subs_email_default ) ) {
			return $current_user->subs_email_default;
		}
		if ( function_exists( 'wpcom_subs_get_subscription_delivery_email_default' ) ) {
			return wpcom_subs_get_subscription_delivery_email_default();
		}
		return 'instantly';
	}

	/**
	 * Markup for one of the WordPress icons the bar uses, inlined from @wordpress/icons.
	 *
	 * Icons inherit their color from CSS `color`, like the library's own Icon component.
	 *
	 * @param string $name Icon name from the WordPress icon library.
	 * @param int    $size Rendered width and height in pixels.
	 * @return string Empty for an unknown name.
	 */
	private static function icon_markup( $name, $size = 24 ) {
		$fill_icons = array(
			'bell'            => '<path fill-rule="evenodd" clip-rule="evenodd" d="M17 11.5c0 1.353.17 2.368.976 3 .266.209.602.376 1.024.5v1H5v-1c.422-.124.757-.291 1.024-.5.806-.632.976-1.647.976-3V9c0-2.8 2.2-5 5-5s5 2.2 5 5v2.5ZM15.5 9v2.5c0 .93.066 1.98.515 2.897l.053.103H7.932a4.018 4.018 0 0 0 .053-.103c.449-.917.515-1.967.515-2.897V9c0-1.972 1.528-3.5 3.5-3.5s3.5 1.528 3.5 3.5Zm-5.492 9.008c0-.176.023-.346.065-.508h3.854A1.996 1.996 0 0 1 12 20c-1.1 0-1.992-.892-1.992-1.992Z"/>',
			'copy'            => '<path fill-rule="evenodd" clip-rule="evenodd" d="M5 4.5h11a.5.5 0 0 1 .5.5v11a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V5a.5.5 0 0 1 .5-.5ZM3 5a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5Zm17 3v10.75c0 .69-.56 1.25-1.25 1.25H6v1.5h12.75a2.75 2.75 0 0 0 2.75-2.75V8H20Z"/>',
			'external'        => '<path d="M19.5 4.5h-7V6h4.44l-5.97 5.97 1.06 1.06L18 7.06v4.44h1.5v-7Zm-13 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3H17v3a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h3V5.5h-3Z"/>',
			'comment'         => '<path d="M18 4H6c-1.1 0-2 .9-2 2v12.9c0 .6.5 1.1 1.1 1.1.3 0 .5-.1.8-.3L8.5 17H18c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm.5 11c0 .3-.2.5-.5.5H7.9l-2.4 2.4V6c0-.3.2-.5.5-.5h12c.3 0 .5.2.5.5v9z"/>',
			'more-horizontal' => '<path d="M11 13h2v-2h-2v2zm-6 0h2v-2H5v2zm12-2v2h2v-2h-2z"/>',
			'pencil'          => '<path d="m19 7-3-3-8.5 8.5-1 4 4-1L19 7Zm-7 11.5H5V20h7v-1.5Z"/>',
			'reusable-block'  => '<path d="M7 7.2h8.2L13.5 9l1.1 1.1 3.6-3.6-3.5-4-1.1 1 1.9 2.3H7c-.9 0-1.7.3-2.3.9-1.4 1.5-1.4 4.2-1.4 5.6v.2h1.5v-.3c0-1.1 0-3.5 1-4.5.3-.3.7-.5 1.2-.5zm13.8 4V11h-1.5v.3c0 1.1 0 3.5-1 4.5-.3.3-.7.5-1.3.5H8.8l1.7-1.7-1.1-1.1L5.9 17l3.5 4 1.1-1-1.9-2.3H17c.9 0 1.7-.3 2.3-.9 1.5-1.4 1.5-4.2 1.5-5.6z"/>',
			'shield'          => '<path fill-rule="evenodd" clip-rule="evenodd" d="M12 3.176l6.75 3.068v4.574c0 3.9-2.504 7.59-6.035 8.755a2.283 2.283 0 01-1.43 0c-3.53-1.164-6.035-4.856-6.035-8.755V6.244L12 3.176zM6.75 7.21v3.608c0 3.313 2.145 6.388 5.005 7.33.159.053.331.053.49 0 2.86-.942 5.005-4.017 5.005-7.33V7.21L12 4.824 6.75 7.21z"/>',
		);
		// These are drawn with strokes, not fills, in the library.
		$stroke_icons = array(
			'chart-bar' => '<path d="M6.75 20V10M12 20V5M17.25 20V14" vector-effect="non-scaling-stroke"/>',
			'check'     => '<path d="M7 12L10 15L17 8" vector-effect="non-scaling-stroke"/>',
		);

		if ( isset( $fill_icons[ $name ] ) ) {
			$attributes = 'fill="currentColor"';
			$markup     = $fill_icons[ $name ];
		} elseif ( isset( $stroke_icons[ $name ] ) ) {
			$attributes = 'style="fill: none" stroke="currentColor" stroke-width="1.5"';
			$markup     = $stroke_icons[ $name ];
		} else {
			return '';
		}

		return sprintf(
			'<svg class="actnbr-icon actnbr-icon-%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" %3$s>%4$s</svg>',
			esc_attr( $name ),
			(int) $size,
			$attributes,
			$markup
		);
	}

	/**
	 * Print one of the bar's icons.
	 *
	 * @param string $name Icon name from the WordPress icon library.
	 * @param int    $size Rendered width and height in pixels.
	 */
	private static function icon( $name, $size = 24 ) {
		echo self::icon_markup( $name, $size ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Static SVG markup, name escaped in the builder.
	}

	/**
	 * Markup for one item of the ⋯ menu.
	 *
	 * @param array $args Item arguments: href, label, class (stats hook), icon (right-edge icon name), blank (open in a new tab), before (trusted markup before the label), role (defaults to menuitem).
	 * @return string
	 */
	private static function menu_item( $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'href'   => '',
				'label'  => '',
				'class'  => '',
				'icon'   => '',
				'blank'  => false,
				'before' => '',
				'role'   => 'menuitem',
			)
		);

		return sprintf(
			'<a%1$s class="actnbr-menu__item %2$s" href="%3$s"%4$s>%5$s<span class="actnbr-menu__label">%6$s</span>%7$s</a>',
			$args['role'] ? ' role="' . esc_attr( $args['role'] ) . '"' : '',
			esc_attr( $args['class'] ),
			esc_url( $args['href'] ),
			$args['blank'] ? ' target="_blank" rel="noopener noreferrer"' : '',
			$args['before'], // Caller-built markup, escaped at the source.
			esc_html( $args['label'] ),
			$args['icon'] ? '<span class="actnbr-menu__icon">' . self::icon_markup( $args['icon'], 18 ) . '</span>' : ''
		);
	}

	/**
	 * Print a menu group if it has any items.
	 *
	 * @param string[] $items Rendered items; empty strings are skipped.
	 */
	private static function menu_group( array $items ) {
		$items = array_filter( $items );
		if ( ! $items ) {
			return;
		}
		echo '<div class="actnbr-menu__group" role="group">' . implode( '', $items ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Items are escaped where built.
	}

	/**
	 * The site's blavatar image markup, or an empty string.
	 *
	 * @return string
	 */
	private static function blavatar() {
		if ( ! function_exists( 'get_blavatar' ) ) {
			return '';
		}
		$blavatar_img = get_blavatar( get_option( 'siteurl' ), 50, Assets::staticize_subdomain( 'https://en.wordpress.com/i/logo/wpcom-gray-white.png' ) ); // phpcs:ignore WPCOM.I18nRules.LocalizedUrl.UnlocalizedUrl
		if ( str_starts_with( $blavatar_img, '<img alt' ) ) {
			$blavatar_img = "<img loading='lazy' alt" . substr( $blavatar_img, 8 );
		}
		return $blavatar_img;
	}

	/**
	 * Print the site title row at the top of the Subscribe popover.
	 *
	 * @param string $site_url  Site home URL.
	 * @param string $site_name Site title.
	 * @param string $blavatar  Blavatar image markup, or empty.
	 */
	private static function site_title( $site_url, $site_name, $blavatar ) {
		$item = self::menu_item(
			array(
				'href'   => $site_url,
				'label'  => $site_name,
				'class'  => 'actnbr-sitename',
				'before' => $blavatar,
				'role'   => '',
			)
		);
		echo '<div class="actnbr-panel__group">' . $item . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped where built.
	}

	/**
	 * Print the Subscribe and Subscribed links; only one is visible at a time.
	 *
	 * @param bool $is_following Whether the current user already subscribes to this site.
	 */
	private static function follow_links( $is_following ) {
		?>
			<a class="actnbr-action actnbr-actn-follow <?php echo $is_following ? ' no-display' : ''; ?>" href="" role="button" aria-haspopup="dialog" aria-expanded="false">
				<?php self::icon( 'bell', 20 ); ?>
				<span><?php esc_html_e( 'Subscribe', 'jetpack-newsletter' ); ?></span>
			</a>
			<a class="actnbr-action actnbr-actn-following <?php echo $is_following ? '' : ' no-display'; ?>" href="" role="button">
				<?php self::icon( 'check', 20 ); ?>
				<span><?php esc_html_e( 'Subscribed', 'jetpack-newsletter' ); ?></span>
			</a>
		<?php
	}

	/**
	 * Print the bar's markup. Hidden inline until the JS reveals it.
	 *
	 * @param bool $is_rtl Whether to render right-to-left.
	 */
	private static function html( $is_rtl ) {
		$current_user = wp_get_current_user();
		$site_id      = get_current_blog_id();

		global $current_blog;

		$is_logged_in = is_user_logged_in();
		$is_member    = $is_logged_in && is_user_member_of_blog( $current_user->ID, $site_id );

		// Render this in the user's language.
		self::switch_to_user_locale();

		$is_suspended = function_exists( 'is_suspended' ) && is_suspended( $site_id );

		/*
		 * Follow actions are dropped only on a "static" site (front page set, under two posts) viewed by
		 * someone who is not a member. Deleted, spam and archived sites never reach this function.
		 */
		$can_follow = true;
		if (
			! $is_suspended &&
			! in_array( $site_id, (array) apply_filters( 'loggedout_follow_disabled_blog_id', array( 1 ) ), true ) &&
			! apply_filters( 'loggedout_follow_disabled', false ) &&
			! self::logged_out_follow_disabled() &&
			( ! $is_member || function_exists( 'is_automattician' ) && is_automattician( $current_user->ID ) ) &&
			( 'page' === get_option( 'show_on_front' ) && get_option( 'post_count' ) < 2 )
		) {
			$can_follow = false;
		}

		$login_url = add_query_arg( 'redirect_to', get_permalink(), 'https://wordpress.com/log-in' );
		$login_url = add_query_arg( 'signup_flow', 'account', $login_url );
		if (
			! empty( $current_blog->primary_redirect )
			&& ! str_contains( $current_blog->primary_redirect, '.wordpress.com' )
		) {
			// phpcs:ignore WPCOM.I18nRules.LocalizedUrl.UnlocalizedUrl
			$redirect_to = add_query_arg( 'back', rawurlencode( get_permalink() ? get_permalink() : home_url() ), 'https://r-login.wordpress.com/remote-login.php?action=link' );
			$login_url   = add_query_arg( 'redirect_to', rawurlencode( $redirect_to ), 'https://wordpress.com/log-in' );
		}

		$site_name          = get_option( 'blogname' );
		$site_url           = get_option( 'home' );
		$site_host          = wp_parse_url( $site_url, PHP_URL_HOST );
		$site_slug          = ( new Status() )->get_site_suffix();
		$can_customize_site = $is_member && current_user_can( 'edit_theme_options' );
		$subscription_id    = function_exists( 'wpcom_subs_is_subscribed' ) ? wpcom_subs_is_subscribed(
			array(
				'user_id' => get_current_user_id(),
				'blog_id' => $site_id,
			)
		) : false;
		$is_following       = $subscription_id ? true : false;
		$signup_url         = 'https://wordpress.com/start/';
		$theme_slug         = get_stylesheet();
		$theme_url          = function_exists( 'wpcom_get_theme_showcase_url' ) ? wpcom_get_theme_showcase_url( $theme_slug ) : 'https://wordpress.com/theme/' . $theme_slug;
		$is_singular        = false;
		$is_folded          = $is_logged_in && self::is_folded( $current_user->ID );
		$feed_id            = false;
		if ( class_exists( 'FeedBag' ) ) {
			$feed_id = \FeedBag::get_feed_id_for_blog_id( $site_id );
		}
		$gdpr_applies = self::gdpr_applies();

		// Fall back to the site's domain if the title is empty.
		if ( empty( $site_name ) ) {
			$site_name = function_exists( 'get_primary_redirect' ) ? get_primary_redirect() : $site_host;
		}

		$post_id       = 0;
		$shortlink     = '';
		$edit_link     = '';
		$stats_link    = '';
		$can_edit_post = false;
		if ( is_singular() ) {
			$is_singular   = true;
			$post_id       = get_the_ID();
			$shortlink     = wp_get_shortlink( $post_id );
			$can_edit_post = $is_member && current_user_can( 'edit_post', $post_id );

			/*
			 * Use the wp admin editor for VIPs (since they have custom editor
			 * plugins), or for super admins who are not members of the blog (until
			 * user-switching is implemented in Calypso).
			 */
			$edit_link = add_query_arg(
				array(
					'post'   => $post_id,
					'action' => 'edit',
				),
				admin_url( 'post.php' )
			);

			$post_type = get_post_type();

			// @phan-suppress-next-line PhanUndeclaredFunction -- Defined by jetpack-mu-wpcom, which is not a dependency; guarded by function_exists().
			$should_use_calypso_links = empty( $post_type ) || function_exists( 'wpcom_should_disable_calypso_links' ) && ! wpcom_should_disable_calypso_links( 'edit.php?post_type=' . $post_type );

			if ( $should_use_calypso_links && ! self::is_vip() && ( ! is_super_admin() || $is_member ) ) {
				$path_prefix = null;
				if ( in_array( $post_type, array( 'post', 'page' ), true ) ) {
					$path_prefix = $post_type;
				} elseif ( in_array( $post_type, apply_filters( 'rest_api_allowed_post_types', array( 'post', 'page', 'revision' ) ), true ) ) {
					$path_prefix = sprintf( 'edit/%s', $post_type );
				}

				if ( $path_prefix ) {
					$edit_link = sprintf( 'https://wordpress.com/%s/%s/%d', $path_prefix, $site_slug, $post_id );
				}
			}

			$stats_link = self::get_post_stats_url( $post_id, $site_id, $site_slug, $should_use_calypso_links );
		}

		$referer = '';
		if ( isset( $_SERVER['HTTP_HOST'] ) && isset( $_SERVER['REQUEST_URI'] ) ) {
			$referer = ( is_ssl() ? 'https' : 'http' ) . '://' . sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) . sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		}

		$can_comment           = is_single() && ! post_password_required( $post_id ) && comments_open( $post_id );
		$can_reblog            = is_single() && self::can_reblog( $site_id, $post_id );
		$can_edit_current_view = $can_edit_post || $can_customize_site;
		$show_follow           = $can_follow && ! $can_edit_current_view && self::has_enough_posts();

		$followers = '';
		if ( $show_follow && ! $is_logged_in ) {
			$subscribers_total = function_exists( 'wpcom_subs_total_for_blog' ) ? wpcom_subs_total_for_blog() : 0;
			if ( ! empty( $subscribers_total ) && $subscribers_total > 24 ) {
				/* translators: %s: number of subscribers */
				$followers = sprintf( _n( 'Join %s other subscriber', 'Join %s other subscribers', $subscribers_total, 'jetpack-newsletter' ), number_format_i18n( $subscribers_total ) );
			}
		}

		$blavatar = self::blavatar();

		$classes = 'actnbr-' . str_replace( '/', '-', $theme_slug );
		if ( $is_folded ) {
			$classes .= ' actnbr-folded';
		}

		$dir = $is_rtl ? 'rtl' : 'ltr';

		?>
			<div id="actionbar" dir="<?php echo esc_attr( $dir ); ?>" style="display: none;"
				class="<?php echo esc_attr( $classes ); ?>" role="region" aria-label="<?php esc_attr_e( 'Site actions', 'jetpack-newsletter' ); ?>">
			<span class="actnbr-live" aria-live="polite"></span>
			<ul>
				<?php
				if ( $can_edit_post ) {
					?>
						<li class="actnbr-btn actnbr-edit">
							<a href="<?php echo esc_url( $edit_link ); ?>">
								<?php self::icon( 'pencil', 20 ); ?>
								<span><?php esc_html_e( 'Edit', 'jetpack-newsletter' ); ?></span>
							</a>
						</li>
						<li class="actnbr-btn actnbr-stats">
							<a href="<?php echo esc_url( $stats_link ); ?>">
								<?php self::icon( 'chart-bar', 20 ); ?>
								<span><?php esc_html_e( 'Stats', 'jetpack-newsletter' ); ?></span>
							</a>
						</li>
					<?php
				}

				if ( $can_comment && ! $can_edit_current_view ) {
					?>
						<li class="actnbr-btn">
							<a class="actnbr-action actnbr-actn-comment" href="<?php echo esc_url( get_comments_link( $post_id ) ); ?>">
								<?php self::icon( 'comment', 20 ); ?>
								<span><?php esc_html_e( 'Comment', 'jetpack-newsletter' ); ?>
							</span>
							</a>
						</li>
					<?php
				}

				if ( $can_reblog && ! $can_edit_current_view ) {
					?>
						<li class="actnbr-btn">
							<a class="actnbr-action actnbr-actn-reblog" href="" role="button">
								<?php self::icon( 'reusable-block', 20 ); ?><span><?php esc_html_e( 'Reblog', 'jetpack-newsletter' ); ?></span>
							</a>
						</li>
					<?php
				}

				if ( $show_follow ) {
					?>
						<li class="actnbr-btn actnbr-hidden">
							<?php self::follow_links( $is_following ); ?>
							<div class="actnbr-popover actnbr-panel actnbr-notice" id="follow-bubble" role="dialog" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: site name */ __( 'Subscribe to %s', 'jetpack-newsletter' ), $site_name ) ); ?>">
								<div class="actnbr-follow-bubble">
								<?php self::site_title( $site_url, $site_name, $blavatar ); ?>
								<?php
								if ( $is_logged_in ) {
									?>
									<div class="actnbr-panel__group actnbr-site-settings">
										<div class="actnbr-message no-display" aria-live="polite"></div>
										<div class="actnbr-site-settings__setting">
											<span class="actnbr-site-settings__toggle">
												<input class="actnbr-site-settings__toggle__input" id="toggle-input-notify-posts" type="checkbox" role="switch" />
												<span class="actnbr-site-settings__toggle__track"></span>
												<span class="actnbr-site-settings__toggle__thumb"></span>
											</span>
											<label for="toggle-input-notify-posts" class="components-toggle-control__label">
												<?php esc_html_e( 'Notify me of new posts', 'jetpack-newsletter' ); ?>
											</label>
										</div>
										<p class="actnbr-site-settings__details">
											<?php esc_html_e( 'Receive web and mobile notifications for new posts from this site.', 'jetpack-newsletter' ); ?>
										</p>
										<div class="actnbr-site-settings__setting">
											<span class="actnbr-site-settings__toggle">
												<input class="actnbr-site-settings__toggle__input" id="toggle-input-email-posts" type="checkbox" role="switch" />
												<span class="actnbr-site-settings__toggle__track"></span>
												<span class="actnbr-site-settings__toggle__thumb"></span>
											</span>
											<label for="toggle-input-email-posts" class="components-toggle-control__label">
												<?php esc_html_e( 'Email me new posts', 'jetpack-newsletter' ); ?>
											</label>
										</div>
										<div class="actnbr-site-settings__details" id="email-new-posts-details">
											<ul class="segmented-control" role="radiogroup" aria-label="<?php esc_attr_e( 'Email frequency', 'jetpack-newsletter' ); ?>">
												<li class="segmented-control__item">
													<a class="segmented-control__link frequency-instantly" data-frequency="instantly" role="radio" aria-checked="false" tabindex="0"><?php esc_html_e( 'Instantly', 'jetpack-newsletter' ); ?></a>
												</li>
												<li class="segmented-control__item">
													<a class="segmented-control__link frequency-daily" data-frequency="daily" role="radio" aria-checked="false" tabindex="0"><?php esc_html_e( 'Daily', 'jetpack-newsletter' ); ?></a>
												</li>
												<li class="segmented-control__item">
													<a class="segmented-control__link frequency-weekly" data-frequency="weekly" role="radio" aria-checked="false" tabindex="0"><?php esc_html_e( 'Weekly', 'jetpack-newsletter' ); ?></a>
												</li>
											</ul>
										</div>
										<div class="actnbr-site-settings__setting">
											<span class="actnbr-site-settings__toggle">
												<input class="actnbr-site-settings__toggle__input" id="toggle-input-email-comments" type="checkbox" role="switch" />
												<span class="actnbr-site-settings__toggle__track"></span>
												<span class="actnbr-site-settings__toggle__thumb"></span>
											</span>
											<label for="toggle-input-email-comments" class="components-toggle-control__label">
												<?php esc_html_e( 'Email me new comments', 'jetpack-newsletter' ); ?>
											</label>
										</div>
									</div>
									<?php
								} else {
									?>
									<div class="actnbr-panel__group">
										<div class="actnbr-message no-display" aria-live="polite"></div>
										<form method="post" action="https://subscribe.wordpress.com" accept-charset="utf-8" class="no-display">
											<?php
											if ( $followers ) {
												?>
												<div class="actnbr-follow-count"><?php echo esc_html( $followers ); ?></div>
												<?php
											}
											?>
											<input type="email" name="email" placeholder="<?php esc_attr_e( 'Want updates? Enter your email', 'jetpack-newsletter' ); ?>" class="actnbr-email-field" aria-label="<?php esc_attr_e( 'Email address', 'jetpack-newsletter' ); ?>" />
											<input type="hidden" name="action" value="subscribe" />
											<input type="hidden" name="blog_id" value="<?php echo esc_attr( (string) $site_id ); ?>" />
											<input type="hidden" name="source" value="<?php echo esc_url( $referer ); ?>" />
											<input type="hidden" name="sub-type" value="actionbar-follow" />
											<?php wp_nonce_field( 'blogsub_subscribe_' . $site_id, '_wpnonce', false, true ); ?>
											<button type="submit" class="actnbr-button"><?php esc_html_e( 'Sign me up', 'jetpack-newsletter' ); ?></button>
										</form>
										<p class="actnbr-login-nudge">
											<?php
											echo wp_kses(
												/* translators: %s is a URL */
												sprintf( __( 'Have a WordPress.com account? <a href="%s">Log in now.</a>', 'jetpack-newsletter' ), esc_url( $login_url ) ),
												array(
													'a' => array(
														'href' => array(),
													),
												)
											);
											?>
										</p>
									</div>
									<?php
								}
								?>
								</div>
							</div>
						</li>
					<?php
				}

				/*
				 * The privacy/GDPR button is special as it relies on window.__tcfapi being in the browser window object as well.
				 * no-display is removed by JS if window.__tcfapi is present.
				 */
				if ( $gdpr_applies ) {
					?>
						<li class="actnbr-btn no-display" onclick="javascript:__tcfapi( 'showUi' );">
							<a class="actnbr-action actnbr-actn-privacy" href="#" role="button">
								<?php self::icon( 'shield', 20 ); ?>
								<span><?php esc_html_e( 'Privacy', 'jetpack-newsletter' ); ?>
							</span>
							</a>
						</li>
					<?php
				}
				?>
				<li class="actnbr-ellipsis actnbr-hidden">
					<button type="button" class="actnbr-more-toggle" aria-haspopup="true" aria-expanded="false" aria-label="<?php esc_attr_e( 'More options', 'jetpack-newsletter' ); ?>">
						<?php self::icon( 'more-horizontal', 24 ); ?>
					</button>
					<div class="actnbr-popover actnbr-menu" role="menu" aria-label="<?php esc_attr_e( 'Site options', 'jetpack-newsletter' ); ?>">
						<?php
						// Site.
						self::menu_group(
							array(
								self::menu_item(
									array(
										'href'   => $site_url,
										'label'  => $site_name,
										'class'  => 'actnbr-sitename',
										'before' => $blavatar,
									)
								),
							)
						);

						// This post or site.
						$items = array();
						if ( $is_singular ) {
							$items[] = sprintf(
								'<a role="menuitem" class="actnbr-menu__item actnbr-shortlink" href="%1$s"><span class="actnbr-menu__label actnbr-shortlink__text">%2$s</span><span class="actnbr-menu__icon actnbr-shortlink__icon">%3$s</span><span class="actnbr-menu__icon actnbr-shortlink__icon-copied">%4$s</span></a>',
								esc_url( $shortlink ),
								esc_html__( 'Copy shortlink', 'jetpack-newsletter' ),
								self::icon_markup( 'copy', 18 ),
								self::icon_markup( 'check', 18 )
							);
						}
						if ( $can_follow && $is_singular ) {
							$items[] = self::menu_item(
								array(
									'href'  => 'https://wordpress.com/reader/blogs/' . (int) $site_id . '/posts/' . (int) $post_id,
									'label' => __( 'View post in Reader', 'jetpack-newsletter' ),
									'class' => 'actnbr-reader',
								)
							);
						}
						if ( $can_follow && ! $is_singular ) {
							$items[] = self::menu_item(
								array(
									'href'  => 'https://wordpress.com/reader/' . ( $feed_id ? 'feeds/' . (int) $feed_id : 'blogs/' . (int) $site_id ),
									'label' => __( 'View site in Reader', 'jetpack-newsletter' ),
									'class' => 'actnbr-reader',
								)
							);
						}
						if ( $is_logged_in && ! $can_customize_site ) {
							$items[] = self::menu_item(
								array(
									'href'  => $theme_url,
									'label' => __( 'Get theme', 'jetpack-newsletter' ) . ': ' . wp_get_theme()->get( 'Name' ),
									'class' => 'actnbr-theme',
								)
							);
						}
						self::menu_group( $items );

						// Account.
						$items = array();
						if ( $is_logged_in && $is_following ) {
							$items[] = self::menu_item(
								array(
									'href'  => 'https://wordpress.com/read/subscriptions/' . (int) $subscription_id,
									'label' => __( 'Manage subscription', 'jetpack-newsletter' ),
									'class' => 'actnbr-follows',
								)
							);
						}
						if ( $is_logged_in && ! $is_following ) {
							$items[] = self::menu_item(
								array(
									'href'  => 'https://wordpress.com/read/subscriptions?s=' . rawurlencode( (string) $site_host ),
									'label' => __( 'Manage subscriptions', 'jetpack-newsletter' ),
									'class' => 'actnbr-follows',
								)
							);
						}
						if ( ! $is_logged_in ) {
							$items[] = self::menu_item(
								array(
									'href'  => 'https://subscribe.wordpress.com/',
									'label' => __( 'Manage subscriptions', 'jetpack-newsletter' ),
									'class' => 'actnbr-subs',
								)
							);
							$items[] = self::menu_item(
								array(
									'href'  => $signup_url,
									'label' => __( 'Sign up', 'jetpack-newsletter' ),
									'class' => 'actnbr-signup',
								)
							);
							$items[] = self::menu_item(
								array(
									'href'  => $login_url,
									'label' => __( 'Log in', 'jetpack-newsletter' ),
									'class' => 'actnbr-login',
								)
							);
						}
						self::menu_group( $items );

						// Report.
						$items = array();
						if ( ! $can_customize_site ) {
							$report_url = add_query_arg(
								'report_url',
								$is_singular ? get_permalink( $post_id ) : $site_url,
								// phpcs:ignore WPCOM.I18nRules.LocalizedUrl.UnlocalizedUrl
								'https://wordpress.com/abuse/'
							);
							$items[] = self::menu_item(
								array(
									'href'  => $report_url,
									'label' => __( 'Report this content', 'jetpack-newsletter' ),
									'class' => 'flb-report',
									'icon'  => 'external',
									'blank' => true,
								)
							);
						}
						self::menu_group( $items );

						// Bar.
						$items = array();
						if ( $is_logged_in || $can_follow ) {
							$items[] = self::menu_item(
								array(
									'href'  => '',
									'label' => $is_folded ? __( 'Expand this bar', 'jetpack-newsletter' ) : __( 'Collapse this bar', 'jetpack-newsletter' ),
									'class' => 'actnbr-fold',
								)
							);
						}
						if ( current_user_can( 'manage_options' ) ) {
							$items[] = self::menu_item(
								array(
									'href'  => self::localized_url( 'https://wordpress.com/support/action-bar/#show-or-hide-the-action-bar' ),
									'label' => __( 'Turn off this bar', 'jetpack-newsletter' ),
									'class' => 'actnbr-turn-off',
									'icon'  => 'external',
									'blank' => true,
								)
							);
						}
						self::menu_group( $items );
						?>
					</div>
				</li>
			</ul>
		</div>
		<?php

		// Switch back to site language.
		self::restore_locale();
	}

	/**
	 * Whether the post can be reblogged and the viewer is allowed to reblog.
	 *
	 * @param int $site_id Blog ID.
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	private static function can_reblog( $site_id, $post_id ) {
		if ( ! function_exists( 'wpr_can_reblog_post' ) || ! function_exists( 'wpcom_can_user_make_a_reblog' ) ) {
			return false;
		}
		$post_ok = (bool) wpr_can_reblog_post( $site_id, $post_id );
		$user_ok = (bool) wpcom_can_user_make_a_reblog();
		return $post_ok && $user_ok;
	}

	/**
	 * Whether the WordAds consent manager is on and the visitor is in a GDPR region.
	 *
	 * @return bool
	 */
	private static function gdpr_applies() {
		if ( ! class_exists( 'WordAds_Consent_Management_Provider' ) && defined( 'WP_CONTENT_DIR' ) ) {
			$provider_file = WP_CONTENT_DIR . '/blog-plugins/wordads-classes/class-wordads-consent-management-provider.php';
			if ( file_exists( $provider_file ) ) {
				require_once $provider_file;
			}
		}
		if ( ! class_exists( 'WordAds_Consent_Management_Provider' ) ) {
			return false;
		}
		// @phan-suppress-next-line PhanUndeclaredClassMethod -- wpcom-only class, guarded by class_exists above.
		return \WordAds_Consent_Management_Provider::is_feature_enabled() && \WordAds_Consent_Management_Provider::does_gdpr_apply();
	}

	/**
	 * Bump one of the whitelisted action bar stats.
	 *
	 * Logged-in clicks land in the `actionbar` MC stat, logged-out clicks in `actionbar_logged_out`.
	 *
	 * @param string $stat_value The stat to bump.
	 */
	private static function bump_stat( $stat_value ) {
		$whitelist = array(
			'clicked_login_link',
			'clicked_login_nudge',
			'clicked_manage_subs_link',
			'clicked_signup_link',
			'clicked_site_title',
			'clicked_stats',
			'copied_shortlink',
			'customized',
			'edited',
			'expanded',
			'explored_theme',
			'folded',
			'followed',
			'managed_following',
			'privacy_clicked',
			'reported_content',
			'show_follow_form',
			'show_more_menu',
			'submit_follow_form',
			'unfollowed',
			'view_reader',
			'comment_clicked',
		);

		if ( ! in_array( $stat_value, $whitelist, true ) ) {
			return;
		}

		if ( ! function_exists( 'bump_stats_extras' ) ) {
			return;
		}

		$stat_name = 'actionbar';

		if ( ! is_user_logged_in() ) {
			$stat_name .= '_logged_out';
		}

		bump_stats_extras( $stat_name, $stat_value );
	}

	/*
	 * The three ajax handlers below deliberately skip nonce verification, as the wpcom original did.
	 * Batcache can serve a logged-in visitor a page whose localized nonce was minted for user 0, so a
	 * check would reject the request and the folded state would never save. The writes are limited to
	 * the caller's own fold flag and anonymous counters.
	 */

	/**
	 * Ajax: remember that the user collapsed the bar.
	 *
	 * @return never
	 */
	public static function fold() {
		self::bump_stat( 'folded' );

		if ( is_user_logged_in() ) {
			self::set_folded( get_current_user_id(), true );
		}

		die;
	}

	/**
	 * Ajax: forget that the user collapsed the bar.
	 *
	 * @return never
	 */
	public static function unfold() {
		self::bump_stat( 'expanded' );

		if ( is_user_logged_in() ) {
			self::set_folded( get_current_user_id(), false );
		}

		die;
	}

	/**
	 * Ajax: bump a click stat sent by the JS.
	 *
	 * @return never
	 */
	public static function ajax_stats() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Whitelisted counter bump; see the note above.
		$stat_value = isset( $_REQUEST['stat'] ) ? sanitize_key( wp_unslash( $_REQUEST['stat'] ) ) : '';

		self::bump_stat( $stat_value );

		die;
	}

	/**
	 * Add the Action Bar visibility setting to the General settings page.
	 *
	 * Stored in the `wpcom_hide_action_bar` option.
	 */
	public static function settings_field() {
		add_settings_field( 'wpcom_hide_action_bar', __( 'Action Bar visibility', 'jetpack-newsletter' ), array( __CLASS__, 'settings_field_display' ), 'general', 'default', array( 'label_for' => 'wpcom_hide_action_bar' ) );

		register_setting( 'general', 'wpcom_hide_action_bar' );
	}

	/**
	 * Render the `wpcom_hide_action_bar` checkbox.
	 */
	public static function settings_field_display() {
		?>
		<input type="checkbox" id="wpcom_hide_action_bar" name="wpcom_hide_action_bar" value="1" <?php checked( 1, get_option( 'wpcom_hide_action_bar' ) ); ?> />

		<?php esc_html_e( 'Hide the Action Bar on the front end of the site.', 'jetpack-newsletter' ); ?>

		<p class="description"><a href="<?php echo esc_url( self::localized_url( 'https://wordpress.com/support/action-bar/' ) ); ?>" data-target="wpcom-help-center"><?php esc_html_e( 'Learn more about the Action Bar', 'jetpack-newsletter' ); ?></a>.</p>
		<?php
	}
}
