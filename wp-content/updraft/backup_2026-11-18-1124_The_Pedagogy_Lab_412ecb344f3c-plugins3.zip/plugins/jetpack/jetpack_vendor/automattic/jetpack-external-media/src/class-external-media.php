<?php
/**
 * Register the external media to both WP Admin and Editor.
 *
 * @package automattic/jetpack-external-media
 */

namespace Automattic\Jetpack\External_Media;

use Automattic\Jetpack\Assets;
use Automattic\Jetpack\Connection\Initial_State as Connection_Initial_State;
use Automattic\Jetpack\Constants;
use Automattic\Jetpack\External_Connections;
use Automattic\Jetpack\Status\Host;
use Jetpack_Options;

/**
 * Class External_Media
 */
class External_Media {
	const PACKAGE_VERSION = '0.9.14';
	const BASE_DIR        = __DIR__ . '/';
	const BASE_FILE       = __FILE__;

	private const EDITOR_HANDLE = 'jetpack-external-media-editor';

	/**
	 * Add hooks and filters.
	 */
	public static function init() {
		// Load external media import page on WordPress.com sites first.
		// We will continue to enable the feature on all sites.
		$host = new Host();
		if ( $host->is_wpcom_platform() ) {
			require_once __DIR__ . '/features/admin/external-media-import.php';
		}

		// Only the stylesheet goes into the iframed canvas: loading the script there hurt site editor performance. See pdWQjU-1rA-p2.
		add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'enqueue_block_editor_assets' ) );
		add_action( 'enqueue_block_assets', array( __CLASS__, 'enqueue_block_canvas_styles' ) );

		External_Connections::add_settings_for_service(
			'media',
			array(
				'service'      => 'google_photos',
				'title'        => __( 'Google Photos', 'jetpack-external-media' ),
				'description'  => __( 'Access photos stored in your Google Photos library.', 'jetpack-external-media' ),
				'support_link' => array(
					'wpcom'   => 'https://wordpress.com/support/google-photos/',
					'jetpack' => 'using-your-google-photos-with-jetpack/',
				),
			)
		);
	}

	/**
	 * Enqueue block editor assets.
	 */
	public static function enqueue_block_editor_assets() {
		self::register_editor_assets();
		Assets::enqueue_script( self::EDITOR_HANDLE );

		wp_add_inline_script(
			self::EDITOR_HANDLE,
			sprintf( 'var JetpackExternalMediaData = %s;', wp_json_encode( self::get_data(), JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) ),
			'before'
		);

		Connection_Initial_State::render_script( self::EDITOR_HANDLE );
	}

	/**
	 * Enqueue the editor stylesheet in the iframed editor canvas, where block placeholders render the media buttons.
	 *
	 * @since 0.9.5
	 */
	public static function enqueue_block_canvas_styles() {
		// Skip the front end, and the editor's parent document, where the editor script already brings the stylesheet.
		if ( ! is_admin() || wp_style_is( self::EDITOR_HANDLE ) ) {
			return;
		}

		self::register_editor_assets();
		$style = wp_styles()->query( self::EDITOR_HANDLE );
		if ( $style ) {
			// A separate handle drops the script-derived deps, which would load the editor UI styles into every canvas.
			wp_enqueue_style( self::EDITOR_HANDLE . '-canvas', $style->src, array(), $style->ver );
		}
	}

	/**
	 * Register the editor script and its stylesheet.
	 */
	private static function register_editor_assets() {
		Assets::register_script(
			self::EDITOR_HANDLE,
			'build/' . self::EDITOR_HANDLE . '/' . self::EDITOR_HANDLE . '.js',
			self::BASE_FILE,
			array(
				'textdomain' => 'jetpack-external-media',
			)
		);
	}

	/**
	 * Get the initial state data.
	 *
	 * @return array
	 */
	private static function get_data() {
		$host = new Host();
		if ( $host->is_wpcom_simple() ) {
			$blog_id = get_current_blog_id();
		} else {
			$blog_id = Jetpack_Options::get_option( 'id', 0 );
		}

		$jetpack_ai_enabled = false;
		if ( $host->is_wpcom_platform() ) {
			$jetpack_ai_enabled = true;
		}

		return array(
			'wpcomBlogId'    => $blog_id,
			'pluginBasePath' => plugins_url( '', Constants::get_constant( 'JETPACK__PLUGIN_FILE' ) ),
			'ai-assistant'   => array(
				'is-enabled' => apply_filters( 'jetpack_ai_enabled', $jetpack_ai_enabled ),
			),
		);
	}

	/**
	 * Check whether the environment supports the newer default size of elements, gradually introduced starting with WP 6.4.
	 *
	 * @since jetpack-14.0
	 * @deprecated since 0.8.0
	 * @return bool
	 */
	public static function site_supports_next_default_size() {
		_deprecated_function( __METHOD__, 'jetpack-external-media-0.8.0' );
		return true;
	}
}
